#include "bsp_rs004.h"
#include "drv_board.h"
#include "drv_uart.h"
#include "lcd.h"

/**
 * ��������IO��Ϊ�����
 */
void MCUAllIOSetLow(void)
{
    PU0 = 0x00;
    PIM0 = 0x00;
    POM0 = 0x00;
    PM0 = 0x00;
    P0  = 0x00;
    PU1 = 0x00;
    PIM1 = 0x00;
    POM1 = 0x00;
    PMC1 = 0x00;
    PM1 = 0x00;
    P1  = 0x00;
    PU2 = 0x00;
    PMC2 = 0x00;
    PM2 = 0x00;
    P2  = 0x00;
    PU3 = 0x00;
    PIM3 = 0x00;
    POM3 = 0x00;
    PM3 = 0x00;
    P3  = 0x00;
    PU4 = 0x00;
    PIM4 = 0x00;
    POM4 = 0x00;
    PMC4 = 0x00;
    PM4 = 0x00;
    P4  = 0x00;
    PU5 = 0x00;
    PIM5 = 0x00;
    POM5 = 0x00;
    PM5 = 0x00;
    P5  = 0x00;
    PM6 = 0x00;
    P6  = 0x00;
    PU7 = 0x00;
    PM7 = 0x00;
    P7  = 0x00;
    PU12 = 0x00;
    PM12 = 0x00;
    P12  = 0x00;
    PU13 = 0x00;
    POM13 = 0x00;
    PM13 = 0x00;
    P13  = 0x00;
    PFSEG0 = 0x00;
    PFSEG1 = 0x00;
    PFSEG2 = 0x00;
    PFSEG3 = 0x00;
    PFSEG4 = 0x00;
    PFSEG5 = 0x00;
    PFSEG6 = 0x00;
}
/**
 * MCU�͹�������
 */
void MCULowConsumeConfig(void)
{
    IO_TOOL_DIR_IN;
    USBSetDirIn();
//    LEDOff(COM_Baud2400);
//    LEDOff(COM_Baud9600);
//    LEDOff(COM_FIR);
    CloseNIRUart();
    CloseFIRUart();
    CloseDebugUart();
    SetNIRPower(1);//�رս������Դ
}
