
#include "bsp_rs004.h"
#include "config.h"
#include "drv_uart.h"
#include "main.h"
#include "TaskTimer.h"
#include "timer_manage.h"
#include "string.h"

DebugUart_ST DebugUart;
IRUart_ST IRUart;

unsigned char   TxDataBuff[DebugUartRecvBufSize];       //����
unsigned short  TxDataBuffLen = 0;
extern unsigned short Time;
extern void DebugUartDealProcess(void);
extern void SendData(unsigned char *buf, unsigned short len);



/************************DEBUG************************/

/*
 * ���Դ��ڽ������ݳ�ʱ����
 */
void DebugUartRecvTimer(void)
{
    if(DebugUart.RecvOverTime)
    {
        DebugUart.RecvOverTime--;
    }
    else
    {
        DebugUart.RecvStart = 0;
        SendData(DebugUart.RxDataBuff, DebugUart.pRxDataWrite);
        
        memset(TxDataBuff,0x0, DebugUartRecvBufSize);
        memcpy(TxDataBuff, DebugUart.RxDataBuff, DebugUart.pRxDataWrite);
        TxDataBuffLen = DebugUart.pRxDataWrite;

        memset(DebugUart.RxDataBuff, 0x0, DebugUartRecvBufSize);
        DelayMs(2);
        DebugUart.pRxDataWrite = 0;
        User_CloseTime(Timer_DebugUartRcv);
//        User_CloseTime(Timer_DebugUartProcess);
//        PIOR |= 0x1 << 4;
//        EnableINT7;
    }
}

/*
 * Debug���ڽ����жϷ������ӿ�
 */
void Interrupt_DebugUartRcv(unsigned char rxd)
{ 
    DebugUart.RxDataBuff[DebugUart.pRxDataWrite] = rxd;
    DebugUart.pRxDataWrite++;
    if(DebugUart.pRxDataWrite >= DebugUartRecvBufSize) 
    {
        DebugUart.pRxDataWrite  =0;
    }
    
    DebugUart.RecvOverTime      = 2;
    User_StartTime(MAINTIMER, Timer_DebugUartRcv, 50, DebugUartRecvTimer);    //50ms*2 = 0.1s������Debug���ڽ��ճ�ʱ��ʱ  
}

void DebugUartIntWake(void)
{
    DisableINT7;
    DebugUart.RecvOverTime      = 2;
    User_StartTime(MAINTIMER, Timer_DebugUartRcv, 500, DebugUartRecvTimer);
//    User_StartTime(MAINTIMER, Timer_DebugUartProcess, 10, DebugUartDealProcess); 
}

/*
 * ��Debug����
 */
void OpenDebugUart(void)
{
    CloseUsart(DEBUG_COM);
    UsartConfig(DEBUG_COM, UartBaud9600, Interrupt_DebugUartRcv, PARITY_NONE);
    OpenUsart(DEBUG_COM);
}

/*
 * �ر�Debug����
 */
void CloseDebugUart(void)
{
    CloseUsart(DEBUG_COM);
    SetUsartIoTxOut((USART_TypeDef)DEBUG_COM, 1);
    SetUsartIoRxOut((USART_TypeDef)DEBUG_COM, 1);
}

/*
 * ��Debug���ڷ�������
 */
unsigned char DebugSendData(unsigned char *buf, unsigned short len)
{
    unsigned char ret;
    SRMK2 = 1U;    /* disable INTSR2 interrupt */
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
    ret = UsartSendData(DEBUG_COM, buf, len);
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
    SRMK2 = 0U;    /* enable INTSR2 interrupt */
    return ret;
}

/************************INFRARED***********************/
/*
 * ����������ݳ�ʱ����
 */
unsigned char data[1536] = {0};
unsigned short a = 0;

void IRUartRecvTimer(void)
{
    if(IRUart.RecvOverTime)
    {
        IRUart.RecvOverTime--;
    }
    else
    {
        Uart3ReceiveDisable();
        if(IRUart.pRxDataWrite > IRUart.pRxDataRead)
        {
            a = IRUart.pRxDataWrite - IRUart.pRxDataRead;
            memcpy(data, &IRUart.RxDataBuff[IRUart.pRxDataRead], a);
            IRUart.pRxDataRead = IRUart.pRxDataWrite;
        }
        else
        {
            a = 1536 - IRUart.pRxDataRead;
            memcpy(data, &IRUart.RxDataBuff[IRUart.pRxDataRead], a);
            memcpy(&data[a], &IRUart.RxDataBuff[0], IRUart.pRxDataWrite);
            a += IRUart.pRxDataWrite;
            IRUart.pRxDataRead = IRUart.pRxDataWrite;
        }
        
        if(((data[0] == 0x68) && (data[7] == 0x68)) || ((data[0]==0x68) && (data[1] == 0xab) && (data[2]== 0x57)&&(data[3]==0x58)))
        {
            DebugSendData(data, a);
        }
        
        
        Uart3ReceiveEnable();
        User_CloseTime(Timer_IRUartRcv);
    }
}

/*
 * ���⴮�ڽ����жϷ������ӿ�
 */
void Interrupt_IRUartRcv(unsigned char rxd)
{
    IRUart.RxDataBuff[IRUart.pRxDataWrite] = rxd;
    IRUart.pRxDataWrite++;
    if(IRUart.pRxDataWrite >= IRUartRecvBufSize) 
    {
        IRUart.pRxDataWrite  =0;
    }
    
    IRUart.RecvOverTime      = 2;
    User_StartTime(MAINTIMER, Timer_IRUartRcv, 10, IRUartRecvTimer);    //10ms*2 = 20ms 
}

/*
 * Զ���⴮�ڽ����жϷ������ӿ�
 */
void Interrupt_FIRUartRcv(unsigned char rxd)
{
    IRUart.RxDataBuff[IRUart.pRxDataWrite] = rxd;
    IRUart.pRxDataWrite++;
    if(IRUart.pRxDataWrite >= IRUartRecvBufSize) 
    {
        IRUart.pRxDataWrite  =0;
    }
    
    IRUart.RecvOverTime      = 2;
    User_StartTime(MAINTIMER, Timer_IRUartRcv, 250, IRUartRecvTimer);    //250ms*2 = 500ms 
}

/*
 * �򿪽����⴮��
 */
void OpenNIRUart(UartBaud Band)
{
    CloseUsart(NIR_COM);
    UsartConfig(NIR_COM,Band, Interrupt_IRUartRcv, PARITY_NONE);
    OpenUsart(NIR_COM);
}

/*
 * �رս����⴮��
 */
void CloseNIRUart(void)
{
    SetNIRPower(1);
    CloseUsart(NIR_COM);
    SetUsartIoTxOut((USART_TypeDef)NIR_COM, 1);
    SetUsartIoRxOut((USART_TypeDef)NIR_COM, 1);
}

void NIRUartIntWake(void)
{
    DisableINT3;
    IRUart.RecvOverTime      = 2;
    User_StartTime(MAINTIMER, Timer_IRUartRcv, 10, IRUartRecvTimer);    //10ms*2 = 20ms 
}

unsigned char NIRSendData(unsigned char *buf, unsigned short len)
{
    unsigned char ret;
    SRMK3 = 1U;    /* disable INTSR3 interrupt */
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
    ret = UsartSendData(NIR_COM, buf, len);
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
    SRMK3 = 0U;    /* enable INTSR3 interrupt */
    return ret;
}

/*
 * ��Զ���⴮��
 */
void OpenFIRUart(unsigned char parity)
{
    CloseUsart(FIR_COM);
    UsartConfig(FIR_COM,UartBaud1200, Interrupt_FIRUartRcv, parity);
    OpenUsart(FIR_COM);
}

/*
 * �ر�Զ���⴮��
 */
void CloseFIRUart(void)
{
    SetFIRPower(1);
    CloseUsart(FIR_COM);
    SetUsartIoTxOut((USART_TypeDef)FIR_COM, 1);
    SetUsartIoRxOut((USART_TypeDef)FIR_COM, 0);
}

void FIRUartIntWake(void)
{
    DisableINT5;
    IRUart.RecvOverTime      = 20;
    User_StartTime(MAINTIMER, Timer_IRUartRcv, 10, IRUartRecvTimer);    //10ms*20 = 200ms 
}

void SendPreamble(void)
{
    unsigned char preamble[600];
    unsigned char property[5];
    memset(property, 0xFE, 5);
    memset(preamble, 0x55, 600);
//    MCU_TimerStart(PortVmNum1);
//    do{
        Uart3SendData((unsigned char *)&preamble,600);
//    }while(Time < 2000);//ǰ���뷢��2s
    Uart3SendData((unsigned char *)&property,5);
//    MCU_TimerStop(PortVmNum1);
//    Time = 0;
}

unsigned char FIRSendData(unsigned char *buf, unsigned short len)
{
    unsigned char ret;
    SRMK0 = 1U;    /* disable INTSR0 interrupt */
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
    ret = UsartSendData(FIR_COM, buf, len);
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
    SRMK0 = 0U;    /* enable INTSR0 interrupt */
    return ret;
}
