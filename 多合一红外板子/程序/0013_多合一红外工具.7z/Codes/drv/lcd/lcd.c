/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
//#include "lib_rs004.h" 
#include "lcd.h"
#include "stdio.h"

/***********************************************************************************************************************
 Extern
***********************************************************************************************************************/
extern void LcdWriteReg(unsigned char Seg, unsigned char Reg);
extern unsigned char LcdReadReg(unsigned char Seg);
extern void LcdAllSet(void);
extern void LcdInit(void);
extern void LcdOn(void);
extern void LcdOff(void);
/***********************************************************************************************************************
 Pre
***********************************************************************************************************************/
void LcdWriteBuf(unsigned char index, unsigned char buf);

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/**
 * ��ʾ���ݻ���
 * 
 * @author Zzzzz (2014-11-09)
 */
unsigned char LcdDataBuf[21];

/**
 * ������ֵ��
 *
 * @author Zzzzz (2014-11-09)
 */
const char LcdDigit[] =
{
    //����
    0xAF,   //"0" 
    0xA0,   //"1"
    0xCB,   //"2"
    0xE9,   //"3"
    0xE4,   //"4"
    0x6D,   //"5"
    0x6F,   //"6"
    0xA8,   //"7"
    0xEF,   //"8"
    0xED,   //"9"
    //�ַ�
    0x40,   //"-"  10
    0xEE,   //"A"  11
    0xEF,   //"B"  12
    0x67,   //"b"  13
    0x0F,   //"C"  14
    0x43,   //"c"  15
    0xE3,   //"d"  16
    0x4F,   //"E"  17
    0x4E,   //"F"  18
    0xE6,   //"H"  19
    0x66,   //"h"  20
    0x07,   //"L"  21
    0xAE,   //"N"  22
    0x62,   //"n"  23
    0xAF,   //"O"  24
    0x63,   //"o"  25
    0xCE,   //"P"  26
    0x42,   //"r"  27
    0x47,   //"t"  28
    0xED,   //"g"  29
    0xA7,   //"U"  30
    0x23,   //"u"  31
    0x02,   //"i"  32
    0x2F,   //"G"  33
    0x00,   //"Blank" 34
    0xA1,   //"J"  35
};

/**
 * д�Ĵ�����λ
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param index 
 *          �Ĵ������
 * @param buf
 *           
 */
void LcdWriteBuf(unsigned char index, unsigned char buf)
{
    LcdDataBuf[index] &= 0xf0;
    LcdDataBuf[index] |= buf & 0x0f;
    // LcdDataBuf[index] = buf;
    LcdWriteReg(index, LcdDataBuf[index]);//WriteLcdReg(index, LcdDataBuf[index]);
}

/**
 * д�Ĵ�����λ
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param index
 *          �Ĵ������
 * @param buf 
 */
void LcdWriteBufHi(unsigned char index, unsigned char buf)
{
    LcdDataBuf[index] &= 0x0f;
    LcdDataBuf[index] |= buf << 4;
    LcdDataBuf[index] |= buf & 0x10;
    LcdWriteReg(index, LcdDataBuf[index]);//WriteLcdReg(index, LcdDataBuf[index]);
}

/** 
 * ��λ 
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param index 
 *          �Ĵ������
 * @param bits 
 *          LCD_DISP_BIT_0��LCD_DISP_BIT_7 
 */
void LcdSetBit(unsigned char index,unsigned char bits)
{
    LcdDataBuf[index] |= bits;
    LcdWriteReg(index, LcdDataBuf[index]);//WriteLcdReg(index, LcdDataBuf[index]);
}

/**
 * ��λ
 *
 * @author Zzzzz (2014-11-09)
 * 
 * @param index
 *          �Ĵ������ 
 * @param bits 
 *          LCD_DISP_BIT_0��LCD_DISP_BIT_7
 */
void LcdResetBit(unsigned char index,unsigned char bits)
{
    LcdDataBuf[index] &= ~(bits);
    LcdWriteReg(index, LcdDataBuf[index]);//WriteLcdReg(index, LcdDataBuf[index]);
}

/**
 * ������ʾ��ʶ
 * 
 * @author Zzzzz (2014-11-09)
 *
 * @param MarkIndex 
 *          ��ʶ��� 
 * @param t
 *          0-����ʾ 1-��ʾ 
 */
void OV_LcdDispMark(_EnumMark MarkIndex,char t)
{
    switch(MarkIndex)
    {
    case MARK_REMAIN:
        t?(LcdSetBit(14,LCD_DISP_BIT_0)):(LcdResetBit(14,LCD_DISP_BIT_0));
        break;
    case MARK_AMOUNT:
        t?(LcdSetBit(12,LCD_DISP_BIT_0)):(LcdResetBit(12,LCD_DISP_BIT_0));
        break;
    case MARK_THISTIME:
        t?(LcdSetBit(10,LCD_DISP_BIT_0)):(LcdResetBit(10,LCD_DISP_BIT_0));
        break;
    case MARK_PRICE:
        t?(LcdSetBit(8,LCD_DISP_BIT_0)):(LcdResetBit(8,LCD_DISP_BIT_0));
        break;
    case MARK_TIME:
        t?(LcdSetBit(6,LCD_DISP_BIT_0)):(LcdResetBit(6,LCD_DISP_BIT_0));
        break;
    case MARK_CHANGEBAT:
        t?(LcdSetBit(4,LCD_DISP_BIT_0)):(LcdResetBit(4,LCD_DISP_BIT_0));
        break;
    case MARK_POW1:
        t?(LcdSetBit(19,LCD_DISP_BIT_0)):(LcdResetBit(19,LCD_DISP_BIT_0));
        break;
    case MARK_POW2:
        t?(LcdSetBit(19,LCD_DISP_BIT_1)):(LcdResetBit(19,LCD_DISP_BIT_1));
        break;
    case MARK_POW3:
        t?(LcdSetBit(19,LCD_DISP_BIT_2)):(LcdResetBit(19,LCD_DISP_BIT_2));
        break;
    case MARK_POW4:
        t?(LcdSetBit(19,LCD_DISP_BIT_3)):(LcdResetBit(19,LCD_DISP_BIT_3));
        break;
    case MARK_POW5:
        t?(LcdSetBit(20,LCD_DISP_BIT_3)):(LcdResetBit(20,LCD_DISP_BIT_3));
        break;
    case MARK_CIRCLE:
        t?(LcdSetBit(20,LCD_DISP_BIT_2)):(LcdResetBit(20,LCD_DISP_BIT_2));
        break;
    case MARK_NB:
        t?(LcdSetBit(16,LCD_DISP_BIT_3)):(LcdResetBit(16,LCD_DISP_BIT_3));
        break;
    case MARK_INFRARED:
        t?(LcdSetBit(16,LCD_DISP_BIT_2)):(LcdResetBit(16,LCD_DISP_BIT_2));
        break;
    case MARK_VALVEOPEN:
        t?(LcdSetBit(16,LCD_DISP_BIT_1)):(LcdResetBit(16,LCD_DISP_BIT_1));
        break;
    case MARK_VALVECLOSE:
        t?(LcdSetBit(17,LCD_DISP_BIT_1)):(LcdResetBit(17,LCD_DISP_BIT_1));
        break;
    case MARK_HALLATT:
        t?(LcdSetBit(18,LCD_DISP_BIT_3)):(LcdResetBit(18,LCD_DISP_BIT_3));
        break;
    case MARK_SHORTAGE:
        t?(LcdSetBit(18,LCD_DISP_BIT_2)):(LcdResetBit(18,LCD_DISP_BIT_2));
        break;
    case MARK_ERR:
        t?(LcdSetBit(18,LCD_DISP_BIT_1)):(LcdResetBit(18,LCD_DISP_BIT_1));
        break;
    case MARK_YUAN:
        t?(LcdSetBit(20,LCD_DISP_BIT_1)):(LcdResetBit(20,LCD_DISP_BIT_1));
        break;
    case MARK_BREAK:
        t?(LcdSetBit(20,LCD_DISP_BIT_0)):(LcdResetBit(20,LCD_DISP_BIT_0));
        break;
    case MARK_VOLUME:
        t?(LcdSetBit(18,LCD_DISP_BIT_0)):(LcdResetBit(18,LCD_DISP_BIT_0));
        break;
    case MARK_TWOPOINT:
        t?(LcdSetBit(0,LCD_DISP_BIT_0)):(LcdResetBit(0,LCD_DISP_BIT_0));
        break;
    default:
        break;
    }
}

/**
 * ��ʾС����
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param line 
 * @param dots
 */
// С����λ�ã�4 3 2 1
void LcdSetDots(unsigned int dots)
{
    switch(dots)
    {
    case 1:
        LcdResetBit(17,LCD_DISP_BIT_0);
        LcdResetBit(17,LCD_DISP_BIT_2);
        LcdResetBit(17,LCD_DISP_BIT_3);
        LcdSetBit(2,LCD_DISP_BIT_0);
        break;
    case 2:
        LcdResetBit(17,LCD_DISP_BIT_0);
        LcdResetBit(17,LCD_DISP_BIT_2);
        LcdSetBit(17,LCD_DISP_BIT_3);
        LcdResetBit(2,LCD_DISP_BIT_0);
        break;
    case 3:
        LcdResetBit(17,LCD_DISP_BIT_0);
        LcdSetBit(17,LCD_DISP_BIT_2);
        LcdResetBit(17,LCD_DISP_BIT_3);
        LcdResetBit(2,LCD_DISP_BIT_0);
        break;
    case 4:
        LcdSetBit(17,LCD_DISP_BIT_0);
        LcdResetBit(17,LCD_DISP_BIT_2);
        LcdResetBit(17,LCD_DISP_BIT_3);
        LcdResetBit(2,LCD_DISP_BIT_0);
        break;
    default:
        LcdResetBit(17,LCD_DISP_BIT_0);
        LcdResetBit(17,LCD_DISP_BIT_2);
        LcdResetBit(17,LCD_DISP_BIT_3);
        LcdResetBit(2,LCD_DISP_BIT_0);
        break;
    }
}

void OV_LcdClearValueMark(void)
{
    OV_LcdDispMark(MARK_REMAIN,0);
    OV_LcdDispMark(MARK_AMOUNT,0);
    OV_LcdDispMark(MARK_THISTIME,0);
    OV_LcdDispMark(MARK_PRICE,0);
    OV_LcdDispMark(MARK_TIME,0);
    OV_LcdDispMark(MARK_CHANGEBAT,0);
    OV_LcdDispMark(MARK_POW1,0);
    OV_LcdDispMark(MARK_POW2,0);
    OV_LcdDispMark(MARK_POW3,0);
    OV_LcdDispMark(MARK_POW4,0);
    OV_LcdDispMark(MARK_POW5,0);
    OV_LcdDispMark(MARK_CIRCLE,0);
    OV_LcdDispMark(MARK_NB,0);
    OV_LcdDispMark(MARK_INFRARED,0);
    OV_LcdDispMark(MARK_VALVEOPEN,0);
    OV_LcdDispMark(MARK_VALVECLOSE,0);
    OV_LcdDispMark(MARK_HALLATT,0);
    OV_LcdDispMark(MARK_SHORTAGE,0);
    OV_LcdDispMark(MARK_ERR,0);
    OV_LcdDispMark(MARK_YUAN,0);
    OV_LcdDispMark(MARK_BREAK,0);
    OV_LcdDispMark(MARK_VOLUME,0);
    OV_LcdDispMark(MARK_TWOPOINT,0);
    LcdSetDots(0);
}

/**
 * ��ʾ�ַ�
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param index
 *          �ַ����
 * @param ch 
 *          ��������
 */
void LcdDispChar(unsigned char index, unsigned char ch)
{
    if(index < 8)
    {
        LcdWriteBuf(15 - index * 2, LcdDigit[ch] & 0x0F);
        LcdWriteBuf(14 - index * 2, (LcdDigit[ch] >> 4 ) | (LcdDataBuf[14 - index * 2] & 0x1));	
    }
}

/**
 * ��LcdDispChar������ͬ�Ķ���ӿ�
 *  
 * @author Zzzzz (2014-11-09)
 *
 * @param index 
 * @param ch 
 */
void OV_LcdDispChar(unsigned char index, unsigned char ch)
{
    LcdDispChar(index,ch);
}

/**
 * ��LcdDispChar������ͬ�Ķ���ӿ�
 *  
 * @author Zzzzz (2014-11-09)
 *
 * @param index 
 * @param ch��ASCII������
 */
void OV_LcdDispNum_Ascii(unsigned char index, unsigned char ch)
{
    if((ch >= '0') && (ch <= '9'))
        LcdDispChar(index,ch - '0');
    else
        LcdDispChar(index,LCD_CHAR_SEPARATE);
}

/**
 * ˢ����ʾ
 * 
 * @author Zzzzz (2014-11-09)
 * 
 * @param tLcdDataBuf 
 *          ��ʾ�ļĴ�������
 */
void OV_LcdRefresh(unsigned char *tLcdDataBuf)
{
    unsigned char index;
    for(index=0;index<21;index++)
    {
        LcdWriteReg(index, LcdDataBuf[index]);//WriteLcdReg(index, LcdDataBuf[index]);
    }
}

/**
 * �����Ļ��ʾ
 * 
 * @author Zzzzz (2014-11-09)
 */
void OV_LcdClear(void)
{
     unsigned char i;
    for(i = 0; i < 21; i++)
    {
        LcdDataBuf[i]=0;
        LcdWriteBuf(i, 0);
    }//MCU_LcdAllClr();
}

/**
 * ȫ��
 * 
 * @author Zzzzz (2014-11-09)
 */
void OV_LcdDispAll(void)
{
    unsigned char i;
    
    for(i = 0; i < 21; i++)
    {
        LcdDataBuf[i]=0xff;
        LcdWriteBuf(i, 0xff);
    }
}

/**
 * �����Ļ������
 * 
 * @author Zzzzz (2014-11-09)
 *
 * @param line 
 */
void OV_LcdClearNum()
{
    unsigned char i;
    
        for(i=0;i<8;i++)
        {
            LcdDispChar(i, LCD_CHAR_BLANK);
        }
        LcdResetBit(17,LCD_DISP_BIT_0);
        LcdResetBit(17,LCD_DISP_BIT_2);
        LcdResetBit(17,LCD_DISP_BIT_3);
        LcdResetBit(2,LCD_DISP_BIT_2);
}
/**
 * ��ʾ�ڶ��е�����
 *
 * @author Zzzzz (2014-11-09)
 * 
 * @param num
 * @param forceN 
 */
void LcdDispNumLine2(long num,char forceN)
{
    unsigned char k,DispCH,Mark;
    Mark=0;
    if(num<0)
    {
        num=-num;
        Mark=1;
    }
    num%=100000000;
    k=0;
    DispCH=num/10000000;
    num-=(long)DispCH*10000000;
    if(k>0 || DispCH!=0 || forceN>=8) 
    {
        k=1;
        LcdDispChar(0,DispCH);
    }
    else
    {
        LcdDispChar(0,LCD_CHAR_BLANK);
    }
    
    DispCH=num/1000000;
    num-=(long)DispCH*1000000;
    if(k>0 || DispCH!=0 || forceN>=7) 
    {
        if(k==0)
            k=2;
        LcdDispChar(1,DispCH);
    }
    else
    {
        LcdDispChar(1,LCD_CHAR_BLANK);
    }
    
    DispCH=num/100000;
    num-=(long)DispCH*100000;
    if(k>0 || DispCH!=0 || forceN>=6) 
    {
        if(k==0)
            k=3;
        LcdDispChar(2,DispCH);
    }
    else
    {
        LcdDispChar(2,LCD_CHAR_BLANK);
    }
    
    DispCH=num/10000;
    num-=(long)DispCH*10000;
    if(k>0 || DispCH!=0 || forceN>=5) 
    {
        if(k==0)
            k=4;
        LcdDispChar(3,DispCH);
    }
    else
    {
        LcdDispChar(3,LCD_CHAR_BLANK);
    }
    
    DispCH=num/1000;
    num-=(long)DispCH*1000;
    if(k>0 || DispCH!=0 || forceN>=4) 
    {
        if(k==0)
            k=5;
        LcdDispChar(4,DispCH);
    }
    else
    {
        LcdDispChar(4,LCD_CHAR_BLANK);
    }
    
    DispCH=num/100;
    num-=(long)DispCH*100;
    if(k>0 || DispCH!=0 || forceN>=3) 
    {
        if(k==0)
            k=6;
        LcdDispChar(5,DispCH);
    }
    else
    {
        LcdDispChar(5,LCD_CHAR_BLANK);
    }
    
    DispCH=num/10;
    num-=(long)DispCH*10;
    if(k>0 || DispCH!=0 || forceN>=2)
    {
        if(k==0)
            k=7;
        LcdDispChar(6,DispCH);
    }
    else
    {
        LcdDispChar(6,LCD_CHAR_BLANK);
    }
    
    DispCH=num;
    if(k>0 || DispCH!=0 || forceN>=1)
    {
        if(k==0)
            k=8;
        LcdDispChar(7,DispCH);
    }
    
    if(Mark)
    {
        if(k>=2)
            LcdDispChar(k-2,LCD_CHAR_SEPARATE);
        else
            LcdDispChar(0,LCD_CHAR_SEPARATE);
    }
}

/**
 * ��ʾ��С�������ֵ
 *  
 * @author Zzzzz (2014-11-09)
 * @param num 
 *          ��ֵ
 * @param dots 
 *          С����λ�� 
 */
void OV_LcdDispNumWithDot(long num,char dots)
{
    unsigned char numlen,t=1;
    numlen = dots>>4;
    dots  &= 0x0f;
    while((dots>0) && t)
    {
        if(num%10==0)
        {
            dots-=1;
            num/=10;
        }
        else
        {
            t=0;
        }
    }
    while(num>99999999)
    {
        if(dots>0)
        {
            num/=10;
            dots-=1;
        }
        else
        {
            num=num%100000000;
        }
    }
    LcdSetDots(dots);
    /*if(line==ExtLine)
    {
        LcdDispNumLine1(num,dots+1);
    }
    else 
    */ 
    {
        if(numlen>0)
        {
            LcdDispNumLine2(num,numlen);
        }
        else
        {
            LcdDispNumLine2(num,dots+1);
        }
    }
}
/**
 *��ʾʣ������
 *  
 * num-��ֵ  dots-С����λ��  
*/
void OV_DispRemainGas(long num,char dots)
{   
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_REMAIN),1);
    OV_LcdDispMark((MARK_VOLUME),1);
    OV_LcdDispNumWithDot(num,dots);
   
}
/**
 * ��ʾʣ����
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��  
 */
void OV_DispRemainMoney(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_REMAIN),1);
    OV_LcdDispMark((MARK_YUAN),1);
    OV_LcdDispNumWithDot(num,dots);

}

/**
 * ��ʾ��ֵ����
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��  
 */
void OV_DispChargeGas(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_THISTIME),1);
    OV_LcdDispMark((MARK_VOLUME),1);
    OV_LcdDispNumWithDot(num,dots);
}
/**
 * ��ʾ��ֵ���
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��  
 */
void OV_DispChargeMoney(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_THISTIME),1);
    OV_LcdDispMark((MARK_YUAN),1);
    OV_LcdDispNumWithDot(num,dots);
}
/**
 * ��ʾ�ۻ�����
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��  
 */
void OV_DispAmountGas(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_AMOUNT),1);
    OV_LcdDispMark((MARK_VOLUME),1);
    OV_LcdDispNumWithDot(num,dots);
}
/**
 * ��ʾ�ۻ����
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��  
 */
void OV_DispAmountMoney(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_AMOUNT),1);
    OV_LcdDispMark((MARK_YUAN),1);
    OV_LcdDispNumWithDot(num,dots);
}

/**
 * ��ʾ����
 * 
 * @author Administrator (2014-11-21) 
 * num-��ֵ  dots-С����λ��   
 */
void OV_DispPrice(long num,char dots)
{
    OV_LcdClearValueMark();
    OV_LcdDispMark((MARK_PRICE),1);
    OV_LcdDispMark(( MARK_BREAK),1);
    OV_LcdDispMark((MARK_YUAN),1);
    OV_LcdDispMark((MARK_VOLUME),1);
    OV_LcdDispNumWithDot(num,dots);
}
/**
 * ��ʾ����
 * 
 * @author Administrator (2014-11-21)
 */
void OV_DispErr(void)
{
    OV_LcdDispMark((MARK_ERR),1);
}

/**
 * ����ʾ����
 * 
 * @author Administrator (2014-11-21)
 */
void OV_DispNoErr(void)
{
    OV_LcdDispMark((MARK_ERR),0);
}
/**
 * ��ʱ����״̬
 * 
 * @author Administrator (2014-11-21) 
 * 0-��ʾ���ſ���1-��ʾ���Ź� 
 */
void OV_DispValve(char c)
{   
    if(c)
    {
        OV_LcdDispMark((MARK_VALVECLOSE),1);
        OV_LcdDispMark((MARK_VALVEOPEN),0);
    }
    else
    {
        OV_LcdDispMark((MARK_VALVECLOSE),0);
        OV_LcdDispMark((MARK_VALVEOPEN),1);
    }
}
/**
 * ��ʾ����
 * 
 * @author Administrator (2014-11-21)
 */
void OV_DispBatt(unsigned int i)
{   
    switch(i)
    {   
    case 1:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),0);
           OV_LcdDispMark((MARK_POW2),0);
           OV_LcdDispMark((MARK_POW3),0);
           OV_LcdDispMark((MARK_POW4),0);
           OV_LcdDispMark((MARK_POW5),1);
           break;
    case 2:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),0);
           OV_LcdDispMark((MARK_POW2),0);
           OV_LcdDispMark((MARK_POW3),0);
           OV_LcdDispMark((MARK_POW4),1);
           OV_LcdDispMark((MARK_POW5),1);
           break;
    case 3:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),0);
           OV_LcdDispMark((MARK_POW2),0);
           OV_LcdDispMark((MARK_POW3),1);
           OV_LcdDispMark((MARK_POW4),1);
           OV_LcdDispMark((MARK_POW5),1);
           break;
    case 4:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),0);
           OV_LcdDispMark((MARK_POW2),1);
           OV_LcdDispMark((MARK_POW3),1);
           OV_LcdDispMark((MARK_POW4),1);
           OV_LcdDispMark((MARK_POW5),1);
           break;
    case 5:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),1);
           OV_LcdDispMark((MARK_POW2),1);
           OV_LcdDispMark((MARK_POW3),1);
           OV_LcdDispMark((MARK_POW4),1);
           OV_LcdDispMark((MARK_POW5),1);
           break;

    default:
           OV_LcdDispMark((MARK_CIRCLE),1);
           OV_LcdDispMark((MARK_POW1),0);
           OV_LcdDispMark((MARK_POW2),0);
           OV_LcdDispMark((MARK_POW3),0);
           OV_LcdDispMark((MARK_POW4),0);
           OV_LcdDispMark((MARK_POW5),0);
           break;
    }
}

/**
 * ��ʾNB����״̬
 * 
 * @author Administrator (2014-11-21)
 */
void OV_DispNBFlag(void)
{
    OV_LcdDispMark((MARK_NB),1);
}

/**
 * ����ʾNB����״̬
 * 
 * @author Administrator (2014-11-21)
 */
void OV_UnDispNBFlag(void)
{
    OV_LcdDispMark((MARK_NB),0);
}

/**
 * ��ʾ��������״̬
 * 
 * @author Administrator (2014-11-21)
 */
void OV_DispInFlag(void)
{
    OV_LcdDispMark((MARK_INFRARED),1);
}

/**
 * ����ʾ��������״̬
 * 
 * @author Administrator (2014-11-21)
 */
void OV_UnDispInFlag(void)
{
    OV_LcdDispMark((MARK_INFRARED),0);
}

/**
 * @brief ��ʾ��������4λID
 * 
 * @param num 
 */
void OV_DispAlarmID(unsigned char *num)
{
    OV_LcdClearValueMark();
    OV_LcdDispNum_Ascii(0, LCD_CHAR_SEPARATE);
    OV_LcdDispNum_Ascii(1, LCD_CHAR_SEPARATE);
    OV_LcdDispNum_Ascii(2, num[0]);
    OV_LcdDispNum_Ascii(3, num[1]);
    OV_LcdDispNum_Ascii(4, num[2]);
    OV_LcdDispNum_Ascii(5, num[3]);
    OV_LcdDispNum_Ascii(6, LCD_CHAR_SEPARATE);
    OV_LcdDispNum_Ascii(7, LCD_CHAR_SEPARATE);
}

/**
 * ��ʾʱ�� 00:00:00
 * 
 * @author Administrator (2014-11-24) 
 * a-ʱ b-�� c-��  ʱ�� ��ʽ��XXʱXX��XX��
 */
void OV_DispTime(unsigned int a,unsigned int b,unsigned int c)
{
    OV_LcdClearValueMark();
    
    LcdSetBit(0,LCD_DISP_BIT_0);
    LcdSetBit(17,LCD_DISP_BIT_0);
    LcdSetBit(17,LCD_DISP_BIT_3);

    LcdDispChar(0,LCD_CHAR_BLANK);
    LcdDispChar(1,a/10);
    LcdDispChar(2,a%10);

    LcdDispChar(3,b/10);
    LcdDispChar(4,b%10);

    LcdDispChar(5,c/10);
    LcdDispChar(6,c%10);
    LcdDispChar(7,LCD_CHAR_BLANK);

}

/**
 * ��ʾ����  XXXXXX(��141124)
 * 
 * @author Administrator (2014-11-24) 
 * n-�� m-�� k-��  ��ʽ��XX��XX��XX�� 
 */
void OV_DispDate(unsigned int n,unsigned int m,unsigned int k)
{
    OV_LcdClearValueMark();
        
    LcdDispChar(0,LCD_CHAR_BLANK);
    LcdDispChar(1,LCD_CHAR_BLANK);
    LcdDispChar(2,n/10);
    LcdDispChar(3,n%10);

    LcdDispChar(4,m/10);
    LcdDispChar(5,m%10);

    LcdDispChar(6,k/10);
    LcdDispChar(7,k%10);

}

/**
 * ��ʾ HELLO
 * 
 * @author Administrator (2014-11-24)
 */
void OV_DispHello(void)
{
    OV_LcdClearValueMark();

    OV_LcdDispChar(0,LCD_CHAR_BLANK);        
    OV_LcdDispChar(1,LCD_CHAR_H);
    OV_LcdDispChar(2,LCD_CHAR_E);
    OV_LcdDispChar(3,LCD_CHAR_L);
    OV_LcdDispChar(4,LCD_CHAR_L);
    OV_LcdDispChar(5,LCD_CHAR_O);
    OV_LcdDispChar(6,LCD_CHAR_BLANK);        
}

/**
 * ��ʾEnd
 * 
 * @author Administrator (2014-11-24)
 */
void OV_DispEnd(void)
{
    OV_LcdClearValueMark();
    OV_LcdDispChar(0,LCD_CHAR_BLANK);    
    OV_LcdDispChar(1,LCD_CHAR_BLANK);    
    OV_LcdDispChar(2,LCD_CHAR_E);
    OV_LcdDispChar(3,LCD_CHAR_n);
    OV_LcdDispChar(4,LCD_CHAR_d);
    OV_LcdDispChar(5,LCD_CHAR_BLANK);    
    OV_LcdDispChar(6,LCD_CHAR_BLANK);    
}

/**
 * ��ʾSucc
 * 
 * @author Administrator (2014-11-24)
 */
void OV_DispSucc(void)
{
    OV_LcdClearValueMark();
    
    OV_LcdDispChar(0,LCD_CHAR_BLANK);    
    OV_LcdDispChar(1,LCD_CHAR_S);
    OV_LcdDispChar(2,LCD_CHAR_U);
    OV_LcdDispChar(3,LCD_CHAR_C);
    OV_LcdDispChar(4,LCD_CHAR_C);
    OV_LcdDispChar(5,LCD_CHAR_BLANK);    
    OV_LcdDispChar(6,LCD_CHAR_BLANK);    
}
/**
 * ��ʾFAIL
 * 
 * @author Administrator (2014-11-24)
 */
void OV_DispFail(void)
{
    OV_LcdClearValueMark();
    
    OV_LcdDispChar(0,LCD_CHAR_BLANK);    
    OV_LcdDispChar(1,LCD_CHAR_F);
    OV_LcdDispChar(2,LCD_CHAR_A);
    OV_LcdDispChar(3,LCD_CHAR_I);
    OV_LcdDispChar(4,LCD_CHAR_L);
    OV_LcdDispChar(5,LCD_CHAR_BLANK);    
    OV_LcdDispChar(6,LCD_CHAR_BLANK);    
}

/**
 * LCD��
 * 
 * @author Administrator (2014-11-24)
 */
void OV_LcdOn(void)
{
    LcdOn();
}
/**
 * LCD��
 * 
 * @author Administrator (2014-11-24)
 */
void OV_LcdOff(void)
{
    LcdOff();
}
/**
 * LCD��ʼ��
 * 
 * @author Administrator (2014-11-24)
 */
void OV_LcdInit(void)
{
    LcdInit();
    //OV_DispHello();
}


/**
 * ��ʾ����һ����ĸ�Ĳ���
 * 
 * @author Zzzzz (2014-12-11)
 * 
 * @param ch1 
 *          ������ĸ1 
 * @param num 
 *          ����ֵ 
 *           
 */
void OV_LcdDispPara1(unsigned char ch1,unsigned long num)
{
    OV_LcdClearValueMark();
    OV_LcdDispNumWithDot(num,0);        
    OV_LcdDispChar(0,ch1);    
    OV_LcdDispChar(1,LCD_CHAR_SEPARATE);
}

/**
 * ��ʾ����������ĸ�Ĳ���
 * 
 * @author Zzzzz (2014-12-11)
 * 
 * @param ch1 
 *          ������ĸ1 
 * @param ch2 
 *          ������ĸ2
 * @param num 
 *          ����ֵ 
 *           
 */
void OV_LcdDispPara2(unsigned char ch1,unsigned char ch2,unsigned int num)
{
    OV_LcdClearValueMark();
    OV_LcdDispNumWithDot(num,0);        
    
    OV_LcdDispChar(0,ch1);    
    OV_LcdDispChar(1,ch2);
    OV_LcdDispChar(2,LCD_CHAR_SEPARATE);
}

/**
 * �ֶ���ʾIP��ַ
 * 
 * @author Zzzzz (2014-12-11)
 * 
 * @param c 
 *          c=0 ��ʾ��һ�� �� 192.168.
 *          c=1 ��ʾ�ڶ��� �� 000.001
 * @param ip0 
 *          ipֵ 
 * @param ip1 
 *          ipֵ 
 */
void OV_LcdDispIP(unsigned char c,unsigned char ip0,unsigned char ip1)
{
    OV_LcdClearValueMark();  
    OV_LcdDispChar(0,ip0/100);
    ip0%=100;
    OV_LcdDispChar(1,ip0/10);
    ip0%=10;
    OV_LcdDispChar(2,ip0);
    LcdSetDots(4);
    
    OV_LcdDispChar(3,ip1/100);
    ip1%=100;
    OV_LcdDispChar(4,ip1/10);
    ip1%=10;
    OV_LcdDispChar(5,ip1);
    OV_LcdDispChar(6,LCD_CHAR_BLANK);    
    
    
    if(c==0)
    {
       LcdSetBit(2,LCD_DISP_BIT_0);
    }
}

/**
 * �ֶ���ʾIP��ַ���ַ�����
 * 
 * @author Zzzzz (2014-12-11)
 * 
 * @param c 
 *          c=0 ��ʾ��һ�� �� 192.168.
 *          c=1 ��ʾ�ڶ��� �� 000.001
 * @param ip��ipֵ  ���磺"115.236.33.164"
 *          
 */
void OV_LcdDispIP_String(unsigned char c, char *ip)
{
    unsigned short ip0, ip1;
    
    if( c == 0 )
    {
        sscanf((char *)ip, "%d.%d.", &ip0, &ip1);
    }
    else
    {
        sscanf((char *)ip, "%*d.%*d.%d.%d", &ip0, &ip1);
    }
    OV_LcdDispIP(c, ip0, ip1);
}

void LCD(void)
{
   OV_LcdInit();
   LcdOn();
   OV_LcdDispAll();
   OV_DispHello();
   OV_LcdDispPara2(LCD_CHAR_A,LCD_CHAR_A,123);
   OV_LcdDispPara1(LCD_CHAR_P,65535);
   OV_LcdDispIP(0,192,168);
   OV_LcdDispIP(1,32,11);
   
    OV_DispEnd();
    OV_DispSucc();
    OV_DispFail();
    OV_DispBatt(0);
    OV_DispBatt(1);
    OV_DispBatt(2);
    OV_DispBatt(3);
    OV_DispBatt(2);
    OV_DispBatt(1);
    OV_DispBatt(0);
   //MCU_LcdAllSet();
   OV_LcdDispNumWithDot(345,3);
   
   OV_LcdDispNumWithDot(3450,3);
   
   OV_LcdDispNumWithDot(123456789l,3);
   OV_DispRemainGas(112,3);
   OV_DispTime(16,45,00);
//   OV_DispStepRemainMoney(-5635,4,13);
//   OV_DispFreezeGas(2345678,4);
   
//   OV_LcdClearNum();
//   OV_DispDate(14,11,25);
//   OV_DispPrice(75,3);
//   MCU_LcdClose();
}
