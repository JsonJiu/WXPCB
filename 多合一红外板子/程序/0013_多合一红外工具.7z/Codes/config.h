#ifndef __CONFIG_H__
#define __CONFIG_H__

#define DEF_ENABLE                      1
#define DEF_DISABLE                     0

#define DEBUG_TEST                      DEF_DISABLE

/********************���ذ����Ͷ���***********************/
#define DEF_FixTure            0               //���һ���⹤װ

//����
#define DEF_DOUBLEKEY                   0
#define DEF_SINGALEKY                   1

#define DEF_KEYCOUNT                DEF_SINGALEKY

#define DEF_BOARD_VERSION           DEF_FixTure

#endif