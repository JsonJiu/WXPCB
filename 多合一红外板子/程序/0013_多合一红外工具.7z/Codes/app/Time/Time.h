#ifndef __TIME_H__
#define __TIME_H__

extern void InitTime(void);

#endif
