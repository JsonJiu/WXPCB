#include "Time.h"
#include "lib_rs004.h"

unsigned short Time = 0;

void IRQ_Timer1(void)
{
    Time++;
}

extern void User_TimerCfg(unsigned char type, unsigned char len, IRQServerFT CallBack);
void InitTime(void)
{
    User_TimerCfg(0,1,IRQ_Timer1);  //1ms����һ��
}