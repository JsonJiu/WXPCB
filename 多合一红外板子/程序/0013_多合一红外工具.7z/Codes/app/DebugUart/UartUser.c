#include "bsp_rs004.h"
#include "config.h"
#include "UartUser.h"
#include "drv_uart.h"
#include "main.h"
#include "stdio.h"
#include "string.h"
#include "TaskTimer.h"
#include "timer_manage.h"

unsigned char COMOpened;
unsigned char IsUartRun = 1;
unsigned char CheckDebugFrameType(unsigned char * pIn)
{
    unsigned char type;
    
    if(pIn[7] == USER_WXPRO_HEAD)
    {
        DebugUart.FrameLen   = DebugUart.RecvBuf[10];
        DebugUart.FrameLen <<= 8;
        DebugUart.FrameLen  += DebugUart.RecvBuf[9];    //�����򳤶�
        DebugUart.FrameLen  += 13;                      //��֡��ʽ�̶�����
        type = 0;
    }
    else if(pIn[3] == 0x43)
    {
        DebugUart.FrameLen   = DebugUart.RecvBuf[3];
        DebugUart.FrameLen <<= 8;
        DebugUart.FrameLen  += DebugUart.RecvBuf[2];    //�����򳤶�
        DebugUart.FrameLen  += 13;                      //��֡��ʽ�̶�����
        type = 1;
    }
    else
      type = 0;//Ĭ�ϵ���˾��Э�鴦��
    
    return type;
}

/**
 * ��˾Э�飺
 * ��ʼ֡1�ֽ�68 + ���߱��6�ֽ� + ��ʼ��ʶ��1�ֽ�68 + ������1�ֽ� + ���ݳ���2�ֽ� + ����ʱ��6�ֽ� + �豸����1�ֽ� + ���ݱ�ʶ2�ֽ�+ ֡���1�ֽ� + ��������n�ֽ� + У���1�ֽ� + ������16
 * Զ����Э�飺
 * ��ʼ֡1�ֽ�68 + ������2�ֽ� + ������1�ֽ� + ��ַ��13�ֽ� + ֡ͷУ��2�ֽ� + AFN������3�ֽ� + ʱ��� + ����� + ֡���� + ֡βУ��2�ֽ� + ������1�ֽ�16
 * @param usart
 * @return
 */
unsigned short OM_ReceiveDebugUartData(void)
{
    unsigned char dat;
    
    while(DebugUart.pRxDataWrite != DebugUart.pRxDataRead)
    {
    	dat = DebugUart.RxDataBuff[DebugUart.pRxDataRead++];
        
    	if(DebugUart.pRxDataRead >= DebugUartRecvBufSize) 
        {
            DebugUart.pRxDataRead = 0;
        }

    	if(!DebugUart.RecvStart)
    	{
            if(dat == USER_WXPRO_HEAD)//����������������Э��
            {
                DebugUart.RecvBuf[0] = dat;
                DebugUart.RecvStart     = 1;                
                DebugUart.RecvLen       = 1;
            }
            else
            {
                DebugUart.RecvStart     = 0;
            }
    	}
    	else
    	{
            DebugUart.RecvBuf[DebugUart.RecvLen++] = dat;
            
            if(DebugUart.RecvLen <= USER_WXPRO_DATALEN_INDEX)
            {
                if(DebugUart.RecvLen == USER_WXPRO_DATALEN_INDEX)   //�ж������򳤶�
                {      
                    DebugUart.FrameType = CheckDebugFrameType(DebugUart.RecvBuf);
                    if(DebugUart.FrameLen > DebugUartDealBufSize)   //֡���ȳ�����������С
                    {
                        DebugUart.RecvStart = 0;
                        return ERR_LEN;
                    }
                }
            }
            else 
            {
                if(DebugUart.RecvLen == DebugUart.FrameLen)         //�ж�֡β
                {
                    if(dat == USER_WXPRO_TAIL)
                    {
                        DebugUart.RecvStart  = 0;
                        if(DebugUart.FrameType == 1)
                            return F_IR_PTR;
                        else if(DebugUart.FrameType == 0)
                            return F_USER_PTR;
                    }
                    else if(dat == USER_WXPRO_HEAD)                 //���¿�ʼ����
                    {
                        DebugUart.RecvBuf[0] = dat;               
                        DebugUart.RecvLen    = 1;
                    }
                    else                                            //֡β����
                    {
                        DebugUart.RecvStart  = 0;
                        return ERR_ENDCODE;
                    }
                }
                else if(DebugUart.RecvLen > DebugUart.FrameLen)     //���ճ���֡����
                {
                    DebugUart.RecvStart     = 0;
                    return ERR_LEN;
                }
                else
                {
                    ;
                }
            }
    	}
    }
    return FALSE_CMD;
}

/***************************************************************************/
/*                         Debug����                      */
/***************************************************************************/

/*
 * ���Դ������ݽ��մ�������
 */
void DebugUartDealProcess(void)
{
    unsigned char   fun;
    
    fun = OM_ReceiveDebugUartData();//��⴮��һ֡����
    
    if(fun == F_USER_PTR)
    {
        SendData(DebugUart.RecvBuf,DebugUart.RecvLen);
    }
}

void InitDebugUart(void)
{
//    DebugUartIntConfig(1,DebugUartIntWake);
//    User_StartTime(MAINTIMER, Timer_DebugUartProcess, 10, DebugUartDealProcess); 
    OpenDebugUart();
}

void InitNIRUart(UartBaud Band)
{
    SetNIRPower(0);
//    NIRUartIntConfig(1,NIRUartIntWake);
    OpenNIRUart(Band);
}

void InitFIRUart(void)
{
    SetFIRPower(0);
    PWM_TimerCfg_TO05(38000, 50);
    PWM_TimerStart_TO05();
    OpenFIRUart(PARITY_NONE);
}

void InitFIRUartEven(void)
{
    SetFIRPower(0);
    PWM_TimerCfg_TO05(38000, 50);
    PWM_TimerStart_TO05();
    OpenFIRUart(PARITY_EVEN);
}

void IrdaSwitch(void)
{
    CloseNIRUart();
    CloseFIRUart();
    PWM_TimerStop_TO05();
    switch(COMOpened)
    {
        case COM_Baud9600:    
            {
                IsUartRun = 1;
                InitDebugUart();
                InitNIRUart(UartBaud9600);
            }
            break;
        case COM_Baud2400:    
            {
                IsUartRun = 1;
                InitDebugUart();
                InitNIRUart(UartBaud2400);
            }
            break;
        case COM_FIR:         
            {
                IsUartRun = 1;
                InitDebugUart();
                InitFIRUart();
            }
            break;
        case COM_FIR_EVEN:
          {
                IsUartRun = 1;
                InitDebugUart();
                InitFIRUartEven();
          }
          break;
        case OFF_ALL:         
          {
              IsUartRun = 0;
              CloseDebugUart();
          }
          break;
    }
}

//���ݵ�ǰ�򿪵ĺ��⴮�ڷ�������
void SendData(unsigned char *buf, unsigned short len)
{
    switch(COMOpened)
    {
        case COM_Baud9600:
            {
                NIRSendData(buf,len);
            }
            break;
        case COM_Baud2400:
            {
                //ǰ����
//                SendPreamble();
                //����
                NIRSendData(buf,len);
            }
            break;
        case COM_FIR:
        case COM_FIR_EVEN:
            {
                unsigned char i = 0;
                while(len>0)
                {
                    FIRSendData(&buf[i],len > 150 ? 150 :len);
                    i += 150;
                    len = len > 150 ? len - 150 :0;
                    if(!len)
                        break;
                    DelayMs(30);
                }
            }
            break;
    }
}

unsigned char IsUARTRun(void)
{
    return IsUartRun;
}
