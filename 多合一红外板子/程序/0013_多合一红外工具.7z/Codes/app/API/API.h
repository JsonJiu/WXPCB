#ifndef __API_H__
#define __API_H__


extern void startGPRS(void);
#endif