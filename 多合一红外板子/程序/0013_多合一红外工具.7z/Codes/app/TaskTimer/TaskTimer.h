#ifndef __TASKTIMER_H__
#define __TASKTIMER_H__


extern unsigned char Timer_KeyCheck;
extern unsigned char Timer_DebugUartRcv;
extern unsigned char Timer_DebugUartProcess;
extern unsigned char Timer_IRUartRcv;
extern unsigned char Timer_LedProcess;

/*
 * ����ʱ������
 */
void InitTaskTimer(void);

#endif
