#include "Led.h"
#include "bsp_rs004.h"
#include "TaskTimer.h"
#include "timer_manage.h"

extern unsigned char COMOpened;

void LedProcess(void);

void InitLedModule()
{
    unsigned char i = 0;
    for(i=0; i<COM_COUNT; i++)
        LEDOff((COM_TypeDef)i);
//    LED_FIR_OUT;
//    LED_FIR_1;
    User_StartTime(SUBTIMER, Timer_LedProcess, 1, LedProcess);
}
extern unsigned char FIRSendData(unsigned char *buf, unsigned short len);
void LedProcess()
{
    unsigned char i = 0;
    for(i=0; i<COM_COUNT; i++)
        LEDOff((COM_TypeDef)i);
    LEDOn((COM_TypeDef)COMOpened);
}

void LEDSwitchStates()
{
    if(COMOpened < COM_COUNT - 1)
        COMOpened++;
    else
        COMOpened = 0;
}
