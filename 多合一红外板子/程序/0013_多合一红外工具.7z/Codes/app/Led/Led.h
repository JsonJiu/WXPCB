#ifndef __LED_H__
#define __LED_H__

extern void InitLedModule(void);
extern void LEDSwitchStates(void);

#endif