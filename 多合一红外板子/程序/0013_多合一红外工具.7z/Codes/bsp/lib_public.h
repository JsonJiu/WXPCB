#ifndef __LIB_PUBLIC_H__
#define __LIB_PUBLIC_H__

typedef void(*IRQServerRecvDataFT)(unsigned char Data);
typedef void(*IRQServerSendDataFT)(unsigned char Data);
typedef void(*IRQServerFT)(void);
typedef short (*IRQServerKeyFT)(unsigned char type);

typedef struct
{
    unsigned char	Year;	//BCD年份低位
    unsigned char	Mon;	//BCD
    unsigned char	Day;	//BCD
    unsigned char	Hour;	//BCD
    unsigned char	Min;	//BCD
    unsigned char	Sec;	//BCD
    unsigned char	Week;	//BCD
}RTC_T;

typedef enum UartBaud//表示波特�??
{
    UartBaud1200 = 0,
    UartBaud2400,
    UartBaud4800,
    UartBaud9600,
    UartBaud19200,
    UartBaud38400,
    UartBaud115200,
    UartBaud10753,
}UartBaud;

typedef struct
{
    UartBaud Baud;

    unsigned char Parity : 2;   // 0:无校�?? 1:Odd奇校�?? 2:Even偶检�??
    unsigned char StopBit : 2;   // 0:无停止位; 1:1位停止位; 2:2位停止位
    unsigned char DataBit : 2;   // 0:7位数据位; 1:8位数据位; 2:9位数据位
    unsigned char Sequence : 1;   // 0:LSB;  1:MSB
}UartMode, *pUartMode;

typedef enum
{
    DISABLE = 0,
    ENABLE = !DISABLE
}FunctionalState;

typedef struct ADCModeS
{
    unsigned char ADCModeOpt        : 2;    //ת��ģʽ,0:����,1:����
    unsigned char ADCModeResolution : 2;    //����ϵ��,0:8λ,1:10λ
    unsigned char ADCModeVREFU      : 2;    //0:VDD//1:�ⲿ��׼Vref//2:�ڲ�1.45V��׼
    unsigned char ADCModeVREFD      : 2;    //0:VSS//1:�ⲿVrefm
}ADCModeST;

typedef struct
{
    unsigned char ADCModeChannel;          //ת��ͨ��,0:��Դ��ѹ,1:�����ѹ
    unsigned char ADCRef;                  //������׼,0:�ڲ�1.45V,1:VDD
}ADC_InitTypeDef;


#define BIT0             0x01 /*Port Bit 0*/
#define BIT1             0x02 /*Port Bit 1*/
#define BIT2             0x04 /*Port Bit 2*/
#define BIT3             0x08 /*Port Bit 3*/
#define BIT4             0x10 /*Port Bit 4*/
#define BIT5             0x20 /*Port Bit 5*/
#define BIT6             0x40 /*Port Bit 6*/
#define BIT7             0x80 /*Port Bit 7*/

/*****************************************************************************/

#define PARITY_NONE     0
#define PARITY_ODD      1
#define PARITY_EVEN     2
#define STOP_NONE       0
#define STOP_1          1
#define STOP_2          2

#define DATA_7          0
#define DATA_8          1
#define DATA_9          2
#define LSB             0

#define MSB             1

#ifndef BOOL
    #ifndef FALSE
        #define FALSE   0
        #define TRUE    1
    #endif
#endif

void DelayUs(unsigned int Us);
void DelayMs(unsigned int Ms);
void MCU_SleepEnter(void);
void MCU_IntEn(void);
void CBB_NOP(void);


#endif

