/*-------------------------------------------------------------------------
 *      Declarations of extended SFR registers for RL78 microcontroller R5F10WMG.
 *
 *      This file can be used by both the RL78,
 *      Assembler, ARL78, and the C/C++ compiler, ICCRL78.
 *
 *      This header file is generated from the device file:
 *          DR5F10WMG.DVF
 *          Copyright(C) 2012 Renesas
 *          Format version V3.00, File version V1.00
 *-------------------------------------------------------------------------*/

#ifndef __IOR5F10WMG_EXT_H__
#define __IOR5F10WMG_EXT_H__

#if !defined(__ARL78__) && !defined(__ICCRL78__)
  #error "IOR5F10WMG_EXT.H file for use with RL78 Assembler or Compiler only"
#endif

#if defined(__ARL78__)
  #if __CORE__ != __RL78_1__
    #error "IOR5F10WMG_EXT.H file for use with ARL78 option --core rl78_1 only"
  #endif
#endif
#if defined(__ICCRL78__)
  #if __CORE__ != __RL78_1__
    #error "IOR5F10WMG_EXT.H file for use with ICCRL78 option --core rl78_1 only"
  #endif
#endif

#ifdef __IAR_SYSTEMS_ICC__

#pragma system_include

#pragma language=save
#pragma language=extended

/*----------------------------------------------
 * SFR bits (default names)
 *--------------------------------------------*/

#ifndef __RL78_BIT_STRUCTURE__
  #define __RL78_BIT_STRUCTURE__
  typedef struct
  {
    unsigned char no0:1;
    unsigned char no1:1;
    unsigned char no2:1;
    unsigned char no3:1;
    unsigned char no4:1;
    unsigned char no5:1;
    unsigned char no6:1;
    unsigned char no7:1;
  } __BITS8;
#endif

#ifndef __RL78_BIT_STRUCTURE2__
  #define __RL78_BIT_STRUCTURE2__
  typedef struct
  {
    unsigned short no0:1;
    unsigned short no1:1;
    unsigned short no2:1;
    unsigned short no3:1;
    unsigned short no4:1;
    unsigned short no5:1;
    unsigned short no6:1;
    unsigned short no7:1;
    unsigned short no8:1;
    unsigned short no9:1;
    unsigned short no10:1;
    unsigned short no11:1;
    unsigned short no12:1;
    unsigned short no13:1;
    unsigned short no14:1;
    unsigned short no15:1;
  } __BITS16;
#endif

/*----------------------------------------------
 *       Extended SFR declarations
 *--------------------------------------------*/

__near __no_init volatile union { unsigned char ADM2; __BITS8 ADM2_bit; } @ 0xF0010;
__near __no_bit_access __no_init volatile union { unsigned char ADUL; __BITS8 ADUL_bit; } @ 0xF0011;
__near __no_bit_access __no_init volatile union { unsigned char ADLL; __BITS8 ADLL_bit; } @ 0xF0012;
__near __no_bit_access __no_init volatile union { unsigned char ADTES; __BITS8 ADTES_bit; } @ 0xF0013;
__near __no_init volatile union { unsigned char PU0; __BITS8 PU0_bit; } @ 0xF0030;
__near __no_init volatile union { unsigned char PU1; __BITS8 PU1_bit; } @ 0xF0031;
__near __no_init volatile union { unsigned char PU2; __BITS8 PU2_bit; } @ 0xF0032;
__near __no_init volatile union { unsigned char PU3; __BITS8 PU3_bit; } @ 0xF0033;
__near __no_init volatile union { unsigned char PU4; __BITS8 PU4_bit; } @ 0xF0034;
__near __no_init volatile union { unsigned char PU5; __BITS8 PU5_bit; } @ 0xF0035;
__near __no_init volatile union { unsigned char PU7; __BITS8 PU7_bit; } @ 0xF0037;
__near __no_init volatile union { unsigned char PU12; __BITS8 PU12_bit; } @ 0xF003C;
__near __no_init volatile union { unsigned char PU13; __BITS8 PU13_bit; } @ 0xF003D;
__near __no_init volatile union { unsigned char PIM0; __BITS8 PIM0_bit; } @ 0xF0040;
__near __no_init volatile union { unsigned char PIM1; __BITS8 PIM1_bit; } @ 0xF0041;
__near __no_init volatile union { unsigned char PIM3; __BITS8 PIM3_bit; } @ 0xF0043;
__near __no_init volatile union { unsigned char PIM4; __BITS8 PIM4_bit; } @ 0xF0044;
__near __no_init volatile union { unsigned char PIM5; __BITS8 PIM5_bit; } @ 0xF0045;
__near __no_init volatile union { unsigned char POM0; __BITS8 POM0_bit; } @ 0xF0050;
__near __no_init volatile union { unsigned char POM1; __BITS8 POM1_bit; } @ 0xF0051;
__near __no_init volatile union { unsigned char POM3; __BITS8 POM3_bit; } @ 0xF0053;
__near __no_init volatile union { unsigned char POM4; __BITS8 POM4_bit; } @ 0xF0054;
__near __no_init volatile union { unsigned char POM5; __BITS8 POM5_bit; } @ 0xF0055;
__near __no_init volatile union { unsigned char POM13; __BITS8 POM13_bit; } @ 0xF005D;
__near __no_init volatile union { unsigned char PMC1; __BITS8 PMC1_bit; } @ 0xF0061;
__near __no_init volatile union { unsigned char PMC2; __BITS8 PMC2_bit; } @ 0xF0062;
__near __no_init volatile union { unsigned char PMC4; __BITS8 PMC4_bit; } @ 0xF0064;
__near __no_init volatile union { unsigned char NFEN0; __BITS8 NFEN0_bit; } @ 0xF0070;
__near __no_init volatile union { unsigned char NFEN1; __BITS8 NFEN1_bit; } @ 0xF0071;
__near __no_init volatile union { unsigned char ISC; __BITS8 ISC_bit; } @ 0xF0073;
__near __no_bit_access __no_init volatile union { unsigned char TIS0; __BITS8 TIS0_bit; } @ 0xF0074;
__near __no_bit_access __no_init volatile union { unsigned char ADPC; __BITS8 ADPC_bit; } @ 0xF0076;
__near __no_bit_access __no_init volatile union { unsigned char PIOR; __BITS8 PIOR_bit; } @ 0xF0077;
__near __no_bit_access __no_init volatile union { unsigned char IAWCTL; __BITS8 IAWCTL_bit; } @ 0xF0078;
__near __no_init volatile union { unsigned char TOS; __BITS8 TOS_bit; } @ 0xF0079;
__near __no_init volatile union { unsigned char PER1; __BITS8 PER1_bit; } @ 0xF007A;
__near __no_init volatile union { unsigned char PMS; __BITS8 PMS_bit; } @ 0xF007B;
__near __no_bit_access __no_init volatile union { unsigned char PWCTKB; __BITS8 PWCTKB_bit; } @ 0xF007C;
__near __no_init volatile union { unsigned char DFLCTL; __BITS8 DFLCTL_bit; } @ 0xF0090;
__near __no_bit_access __no_init volatile union { unsigned char HOCODIV; __BITS8 HOCODIV_bit; } @ 0xF00A8;
__near __no_bit_access __no_init volatile const union { unsigned char TEMPCAL0; __BITS8 TEMPCAL0_bit; } @ 0xF00AC;
__near __no_bit_access __no_init volatile const union { unsigned char TEMPCAL1; __BITS8 TEMPCAL1_bit; } @ 0xF00AD;
__near __no_bit_access __no_init volatile const union { unsigned char TEMPCAL2; __BITS8 TEMPCAL2_bit; } @ 0xF00AE;
__near __no_bit_access __no_init volatile const union { unsigned char TEMPCAL3; __BITS8 TEMPCAL3_bit; } @ 0xF00AF;
__near __no_bit_access __no_init volatile union { unsigned short MDCL; __BITS16 MDCL_bit; } @ 0xF00E0;
__near __no_bit_access __no_init volatile union { unsigned short MDCH; __BITS16 MDCH_bit; } @ 0xF00E2;
__near __no_init volatile union { unsigned char MDUC; __BITS8 MDUC_bit; } @ 0xF00E8;
__near __no_init volatile union { unsigned char PER0; __BITS8 PER0_bit; } @ 0xF00F0;
__near __no_bit_access __no_init volatile union { unsigned char OSMC; __BITS8 OSMC_bit; } @ 0xF00F3;
__near __no_init volatile union { unsigned char RMC; __BITS8 RMC_bit; } @ 0xF00F4;
__near __no_init volatile union { unsigned char RPECTL; __BITS8 RPECTL_bit; } @ 0xF00F5;
__near __no_init volatile union { unsigned char PORSR; __BITS8 PORSR_bit; } @ 0xF00F9;
__near __no_bit_access __no_init volatile const union { unsigned char BCDADJ; __BITS8 BCDADJ_bit; } @ 0xF00FE;
__near __no_bit_access __no_init volatile const union { unsigned short SSR00; __BITS16 SSR00_bit; struct { union { unsigned char SSR00L; __BITS8 SSR00L_bit; }; }; } @ 0xF0100;
__near __no_bit_access __no_init volatile const union { unsigned short SSR01; __BITS16 SSR01_bit; struct { union { unsigned char SSR01L; __BITS8 SSR01L_bit; }; }; } @ 0xF0102;
__near __no_bit_access __no_init volatile const union { unsigned short SSR02; __BITS16 SSR02_bit; struct { union { unsigned char SSR02L; __BITS8 SSR02L_bit; }; }; } @ 0xF0104;
__near __no_bit_access __no_init volatile const union { unsigned short SSR03; __BITS16 SSR03_bit; struct { union { unsigned char SSR03L; __BITS8 SSR03L_bit; }; }; } @ 0xF0106;
__near __no_bit_access __no_init volatile union { unsigned short SIR00; __BITS16 SIR00_bit; struct { union { unsigned char SIR00L; __BITS8 SIR00L_bit; }; }; } @ 0xF0108;
__near __no_bit_access __no_init volatile union { unsigned short SIR01; __BITS16 SIR01_bit; struct { union { unsigned char SIR01L; __BITS8 SIR01L_bit; }; }; } @ 0xF010A;
__near __no_bit_access __no_init volatile union { unsigned short SIR02; __BITS16 SIR02_bit; struct { union { unsigned char SIR02L; __BITS8 SIR02L_bit; }; }; } @ 0xF010C;
__near __no_bit_access __no_init volatile union { unsigned short SIR03; __BITS16 SIR03_bit; struct { union { unsigned char SIR03L; __BITS8 SIR03L_bit; }; }; } @ 0xF010E;
__near __no_bit_access __no_init volatile union { unsigned short SMR00; __BITS16 SMR00_bit; } @ 0xF0110;
__near __no_bit_access __no_init volatile union { unsigned short SMR01; __BITS16 SMR01_bit; } @ 0xF0112;
__near __no_bit_access __no_init volatile union { unsigned short SMR02; __BITS16 SMR02_bit; } @ 0xF0114;
__near __no_bit_access __no_init volatile union { unsigned short SMR03; __BITS16 SMR03_bit; } @ 0xF0116;
__near __no_bit_access __no_init volatile union { unsigned short SCR00; __BITS16 SCR00_bit; } @ 0xF0118;
__near __no_bit_access __no_init volatile union { unsigned short SCR01; __BITS16 SCR01_bit; } @ 0xF011A;
__near __no_bit_access __no_init volatile union { unsigned short SCR02; __BITS16 SCR02_bit; } @ 0xF011C;
__near __no_bit_access __no_init volatile union { unsigned short SCR03; __BITS16 SCR03_bit; } @ 0xF011E;
__near __no_init volatile const union { unsigned short SE0; struct { union { unsigned char SE0L; __BITS8 SE0L_bit; }; }; } @ 0xF0120;
__near __no_init volatile union { unsigned short SS0; struct { union { unsigned char SS0L; __BITS8 SS0L_bit; }; }; } @ 0xF0122;
__near __no_init volatile union { unsigned short ST0; struct { union { unsigned char ST0L; __BITS8 ST0L_bit; }; }; } @ 0xF0124;
__near __no_bit_access __no_init volatile union { unsigned short SPS0; __BITS16 SPS0_bit; struct { union { unsigned char SPS0L; __BITS8 SPS0L_bit; }; }; } @ 0xF0126;
__near __no_bit_access __no_init volatile union { unsigned short SO0; __BITS16 SO0_bit; } @ 0xF0128;
__near __no_init volatile union { unsigned short SOE0; struct { union { unsigned char SOE0L; __BITS8 SOE0L_bit; }; }; } @ 0xF012A;
__near __no_bit_access __no_init volatile union { unsigned short SOL0; __BITS16 SOL0_bit; struct { union { unsigned char SOL0L; __BITS8 SOL0L_bit; }; }; } @ 0xF0134;
__near __no_bit_access __no_init volatile union { unsigned short SSC0; __BITS16 SSC0_bit; struct { union { unsigned char SSC0L; __BITS8 SSC0L_bit; }; }; } @ 0xF0138;
__near __no_bit_access __no_init volatile const union { unsigned short SSR10; __BITS16 SSR10_bit; struct { union { unsigned char SSR10L; __BITS8 SSR10L_bit; }; }; } @ 0xF0140;
__near __no_bit_access __no_init volatile const union { unsigned short SSR11; __BITS16 SSR11_bit; struct { union { unsigned char SSR11L; __BITS8 SSR11L_bit; }; }; } @ 0xF0142;
__near __no_bit_access __no_init volatile const union { unsigned short SSR12; __BITS16 SSR12_bit; struct { union { unsigned char SSR12L; __BITS8 SSR12L_bit; }; }; } @ 0xF0144;
__near __no_bit_access __no_init volatile const union { unsigned short SSR13; __BITS16 SSR13_bit; struct { union { unsigned char SSR13L; __BITS8 SSR13L_bit; }; }; } @ 0xF0146;
__near __no_bit_access __no_init volatile union { unsigned short SIR10; __BITS16 SIR10_bit; struct { union { unsigned char SIR10L; __BITS8 SIR10L_bit; }; }; } @ 0xF0148;
__near __no_bit_access __no_init volatile union { unsigned short SIR11; __BITS16 SIR11_bit; struct { union { unsigned char SIR11L; __BITS8 SIR11L_bit; }; }; } @ 0xF014A;
__near __no_bit_access __no_init volatile union { unsigned short SIR12; __BITS16 SIR12_bit; struct { union { unsigned char SIR12L; __BITS8 SIR12L_bit; }; }; } @ 0xF014C;
__near __no_bit_access __no_init volatile union { unsigned short SIR13; __BITS16 SIR13_bit; struct { union { unsigned char SIR13L; __BITS8 SIR13L_bit; }; }; } @ 0xF014E;
__near __no_bit_access __no_init volatile union { unsigned short SMR10; __BITS16 SMR10_bit; } @ 0xF0150;
__near __no_bit_access __no_init volatile union { unsigned short SMR11; __BITS16 SMR11_bit; } @ 0xF0152;
__near __no_bit_access __no_init volatile union { unsigned short SMR12; __BITS16 SMR12_bit; } @ 0xF0154;
__near __no_bit_access __no_init volatile union { unsigned short SMR13; __BITS16 SMR13_bit; } @ 0xF0156;
__near __no_bit_access __no_init volatile union { unsigned short SCR10; __BITS16 SCR10_bit; } @ 0xF0158;
__near __no_bit_access __no_init volatile union { unsigned short SCR11; __BITS16 SCR11_bit; } @ 0xF015A;
__near __no_bit_access __no_init volatile union { unsigned short SCR12; __BITS16 SCR12_bit; } @ 0xF015C;
__near __no_bit_access __no_init volatile union { unsigned short SCR13; __BITS16 SCR13_bit; } @ 0xF015E;
__near __no_init volatile const union { unsigned short SE1; struct { union { unsigned char SE1L; __BITS8 SE1L_bit; }; }; } @ 0xF0160;
__near __no_init volatile union { unsigned short SS1; struct { union { unsigned char SS1L; __BITS8 SS1L_bit; }; }; } @ 0xF0162;
__near __no_init volatile union { unsigned short ST1; struct { union { unsigned char ST1L; __BITS8 ST1L_bit; }; }; } @ 0xF0164;
__near __no_bit_access __no_init volatile union { unsigned short SPS1; __BITS16 SPS1_bit; struct { union { unsigned char SPS1L; __BITS8 SPS1L_bit; }; }; } @ 0xF0166;
__near __no_bit_access __no_init volatile union { unsigned short SO1; __BITS16 SO1_bit; } @ 0xF0168;
__near __no_init volatile union { unsigned short SOE1; struct { union { unsigned char SOE1L; __BITS8 SOE1L_bit; }; }; } @ 0xF016A;
__near __no_bit_access __no_init volatile union { unsigned short SOL1; __BITS16 SOL1_bit; struct { union { unsigned char SOL1L; __BITS8 SOL1L_bit; }; }; } @ 0xF0174;
__near __no_bit_access __no_init volatile union { unsigned short SSC1; __BITS16 SSC1_bit; struct { union { unsigned char SSC1L; __BITS8 SSC1L_bit; }; }; } @ 0xF0178;
__near __no_bit_access __no_init volatile const union { unsigned short TCR00; __BITS16 TCR00_bit; } @ 0xF0180;
__near __no_bit_access __no_init volatile const union { unsigned short TCR01; __BITS16 TCR01_bit; } @ 0xF0182;
__near __no_bit_access __no_init volatile const union { unsigned short TCR02; __BITS16 TCR02_bit; } @ 0xF0184;
__near __no_bit_access __no_init volatile const union { unsigned short TCR03; __BITS16 TCR03_bit; } @ 0xF0186;
__near __no_bit_access __no_init volatile const union { unsigned short TCR04; __BITS16 TCR04_bit; } @ 0xF0188;
__near __no_bit_access __no_init volatile const union { unsigned short TCR05; __BITS16 TCR05_bit; } @ 0xF018A;
__near __no_bit_access __no_init volatile const union { unsigned short TCR06; __BITS16 TCR06_bit; } @ 0xF018C;
__near __no_bit_access __no_init volatile const union { unsigned short TCR07; __BITS16 TCR07_bit; } @ 0xF018E;
__near __no_bit_access __no_init volatile union { unsigned short TMR00; __BITS16 TMR00_bit; } @ 0xF0190;
__near __no_bit_access __no_init volatile union { unsigned short TMR01; __BITS16 TMR01_bit; } @ 0xF0192;
__near __no_bit_access __no_init volatile union { unsigned short TMR02; __BITS16 TMR02_bit; } @ 0xF0194;
__near __no_bit_access __no_init volatile union { unsigned short TMR03; __BITS16 TMR03_bit; } @ 0xF0196;
__near __no_bit_access __no_init volatile union { unsigned short TMR04; __BITS16 TMR04_bit; } @ 0xF0198;
__near __no_bit_access __no_init volatile union { unsigned short TMR05; __BITS16 TMR05_bit; } @ 0xF019A;
__near __no_bit_access __no_init volatile union { unsigned short TMR06; __BITS16 TMR06_bit; } @ 0xF019C;
__near __no_bit_access __no_init volatile union { unsigned short TMR07; __BITS16 TMR07_bit; } @ 0xF019E;
__near __no_bit_access __no_init volatile const union { unsigned short TSR00; __BITS16 TSR00_bit; struct { union { unsigned char TSR00L; __BITS8 TSR00L_bit; }; }; } @ 0xF01A0;
__near __no_bit_access __no_init volatile const union { unsigned short TSR01; __BITS16 TSR01_bit; struct { union { unsigned char TSR01L; __BITS8 TSR01L_bit; }; }; } @ 0xF01A2;
__near __no_bit_access __no_init volatile const union { unsigned short TSR02; __BITS16 TSR02_bit; struct { union { unsigned char TSR02L; __BITS8 TSR02L_bit; }; }; } @ 0xF01A4;
__near __no_bit_access __no_init volatile const union { unsigned short TSR03; __BITS16 TSR03_bit; struct { union { unsigned char TSR03L; __BITS8 TSR03L_bit; }; }; } @ 0xF01A6;
__near __no_bit_access __no_init volatile const union { unsigned short TSR04; __BITS16 TSR04_bit; struct { union { unsigned char TSR04L; __BITS8 TSR04L_bit; }; }; } @ 0xF01A8;
__near __no_bit_access __no_init volatile const union { unsigned short TSR05; __BITS16 TSR05_bit; struct { union { unsigned char TSR05L; __BITS8 TSR05L_bit; }; }; } @ 0xF01AA;
__near __no_bit_access __no_init volatile const union { unsigned short TSR06; __BITS16 TSR06_bit; struct { union { unsigned char TSR06L; __BITS8 TSR06L_bit; }; }; } @ 0xF01AC;
__near __no_bit_access __no_init volatile const union { unsigned short TSR07; __BITS16 TSR07_bit; struct { union { unsigned char TSR07L; __BITS8 TSR07L_bit; }; }; } @ 0xF01AE;
__near __no_init volatile const union { unsigned short TE0; struct { union { unsigned char TE0L; __BITS8 TE0L_bit; }; }; } @ 0xF01B0;
__near __no_init volatile union { unsigned short TS0; struct { union { unsigned char TS0L; __BITS8 TS0L_bit; }; }; } @ 0xF01B2;
__near __no_init volatile union { unsigned short TT0; struct { union { unsigned char TT0L; __BITS8 TT0L_bit; }; }; } @ 0xF01B4;
__near __no_bit_access __no_init volatile union { unsigned short TPS0; __BITS16 TPS0_bit; } @ 0xF01B6;
__near __no_bit_access __no_init volatile union { unsigned short TO0; __BITS16 TO0_bit; struct { union { unsigned char TO0L; __BITS8 TO0L_bit; }; }; } @ 0xF01B8;
__near __no_init volatile union { unsigned short TOE0; struct { union { unsigned char TOE0L; __BITS8 TOE0L_bit; }; }; } @ 0xF01BA;
__near __no_bit_access __no_init volatile union { unsigned short TOL0; __BITS16 TOL0_bit; struct { union { unsigned char TOL0L; __BITS8 TOL0L_bit; }; }; } @ 0xF01BC;
__near __no_bit_access __no_init volatile union { unsigned short TOM0; __BITS16 TOM0_bit; struct { union { unsigned char TOM0L; __BITS8 TOM0L_bit; }; }; } @ 0xF01BE;
__near __no_bit_access __no_init volatile union { unsigned char DSA2; __BITS8 DSA2_bit; } @ 0xF0200;
__near __no_bit_access __no_init volatile union { unsigned char DSA3; __BITS8 DSA3_bit; } @ 0xF0201;
__near __no_bit_access __no_init volatile union { unsigned short DRA2; __BITS16 DRA2_bit; struct { union { unsigned char DRA2L; __BITS8 DRA2L_bit; }; union { unsigned char DRA2H; __BITS8 DRA2H_bit; }; }; } @ 0xF0202;
__near __no_bit_access __no_init volatile union { unsigned short DRA3; __BITS16 DRA3_bit; struct { union { unsigned char DRA3L; __BITS8 DRA3L_bit; }; union { unsigned char DRA3H; __BITS8 DRA3H_bit; }; }; } @ 0xF0204;
__near __no_bit_access __no_init volatile union { unsigned short DBC2; __BITS16 DBC2_bit; struct { union { unsigned char DBC2L; __BITS8 DBC2L_bit; }; union { unsigned char DBC2H; __BITS8 DBC2H_bit; }; }; } @ 0xF0206;
__near __no_bit_access __no_init volatile union { unsigned short DBC3; __BITS16 DBC3_bit; struct { union { unsigned char DBC3L; __BITS8 DBC3L_bit; }; union { unsigned char DBC3H; __BITS8 DBC3H_bit; }; }; } @ 0xF0208;
__near __no_init volatile union { unsigned char DMC2; __BITS8 DMC2_bit; } @ 0xF020A;
__near __no_init volatile union { unsigned char DMC3; __BITS8 DMC3_bit; } @ 0xF020B;
__near __no_init volatile union { unsigned char DRC2; __BITS8 DRC2_bit; } @ 0xF020C;
__near __no_init volatile union { unsigned char DRC3; __BITS8 DRC3_bit; } @ 0xF020D;
__near __no_init volatile union { unsigned char IICCTL00; __BITS8 IICCTL00_bit; } @ 0xF0230;
__near __no_init volatile union { unsigned char IICCTL01; __BITS8 IICCTL01_bit; } @ 0xF0231;
__near __no_bit_access __no_init volatile union { unsigned char IICWL0; __BITS8 IICWL0_bit; } @ 0xF0232;
__near __no_bit_access __no_init volatile union { unsigned char IICWH0; __BITS8 IICWH0_bit; } @ 0xF0233;
__near __no_bit_access __no_init volatile union { unsigned char SVA0; __BITS8 SVA0_bit; } @ 0xF0234;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR00; __BITS8 ELSELR00_bit; } @ 0xF0240;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR01; __BITS8 ELSELR01_bit; } @ 0xF0241;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR02; __BITS8 ELSELR02_bit; } @ 0xF0242;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR03; __BITS8 ELSELR03_bit; } @ 0xF0243;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR04; __BITS8 ELSELR04_bit; } @ 0xF0244;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR05; __BITS8 ELSELR05_bit; } @ 0xF0245;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR06; __BITS8 ELSELR06_bit; } @ 0xF0246;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR07; __BITS8 ELSELR07_bit; } @ 0xF0247;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR08; __BITS8 ELSELR08_bit; } @ 0xF0248;
__near __no_bit_access __no_init volatile union { unsigned char ELSELR09; __BITS8 ELSELR09_bit; } @ 0xF0249;
__near __no_init volatile union { unsigned char CRC0CTL; __BITS8 CRC0CTL_bit; } @ 0xF02F0;
__near __no_bit_access __no_init volatile union { unsigned short PGCRCL; __BITS16 PGCRCL_bit; } @ 0xF02F2;
__near __no_bit_access __no_init volatile union { unsigned short CRCD; __BITS16 CRCD_bit; } @ 0xF02FA;
__near __no_init volatile union { unsigned char PFSEG0; __BITS8 PFSEG0_bit; } @ 0xF0300;
__near __no_init volatile union { unsigned char PFSEG1; __BITS8 PFSEG1_bit; } @ 0xF0301;
__near __no_init volatile union { unsigned char PFSEG2; __BITS8 PFSEG2_bit; } @ 0xF0302;
__near __no_init volatile union { unsigned char PFSEG3; __BITS8 PFSEG3_bit; } @ 0xF0303;
__near __no_init volatile union { unsigned char PFSEG4; __BITS8 PFSEG4_bit; } @ 0xF0304;
__near __no_init volatile union { unsigned char PFSEG5; __BITS8 PFSEG5_bit; } @ 0xF0305;
__near __no_init volatile union { unsigned char PFSEG6; __BITS8 PFSEG6_bit; } @ 0xF0306;
__near __no_init volatile union { unsigned char ISCLCD; __BITS8 ISCLCD_bit; } @ 0xF0308;
__near __no_bit_access __no_init volatile union { unsigned short SUBCUD; __BITS16 SUBCUD_bit; } @ 0xF0310;
//modify by hxx
__near __no_bit_access __no_init volatile union { unsigned char SCMR0; __BITS8 SCMR0_bit; } @ 0xF0322;
__near __no_bit_access __no_init volatile union { unsigned char SCCR0; __BITS8 SCCR0_bit; } @ 0xF0323;
__near __no_bit_access __no_init volatile union { unsigned char SCSR0; __BITS8 SCSR0_bit; } @ 0xF0324;
__near __no_bit_access __no_init volatile union { unsigned char SCBRR0; __BITS8 SCBRR0_bit; } @ 0xF0325;

__near __no_bit_access __no_init volatile union { unsigned char SCMR1; __BITS8 SCMR1_bit; } @ 0xF032A;
__near __no_bit_access __no_init volatile union { unsigned char SCCR1; __BITS8 SCCR1_bit; } @ 0xF032B;
__near __no_bit_access __no_init volatile union { unsigned char SCSR1; __BITS8 SCSR1_bit; } @ 0xF032C;
__near __no_bit_access __no_init volatile union { unsigned char SCBRR1; __BITS8 SCBRR1_bit; } @ 0xF032D;
//
__near __no_init volatile union { unsigned char COMPMDR; __BITS8 COMPMDR_bit; } @ 0xF0340;
__near __no_init volatile union { unsigned char COMPFIR; __BITS8 COMPFIR_bit; } @ 0xF0341;
__near __no_init volatile union { unsigned char COMPOCR; __BITS8 COMPOCR_bit; } @ 0xF0342;
__near __no_bit_access __no_init volatile union { unsigned char SEG0; __BITS8 SEG0_bit; } @ 0xF0400;
__near __no_bit_access __no_init volatile union { unsigned char SEG1; __BITS8 SEG1_bit; } @ 0xF0401;
__near __no_bit_access __no_init volatile union { unsigned char SEG2; __BITS8 SEG2_bit; } @ 0xF0402;
__near __no_bit_access __no_init volatile union { unsigned char SEG3; __BITS8 SEG3_bit; } @ 0xF0403;
__near __no_bit_access __no_init volatile union { unsigned char SEG4; __BITS8 SEG4_bit; } @ 0xF0404;
__near __no_bit_access __no_init volatile union { unsigned char SEG5; __BITS8 SEG5_bit; } @ 0xF0405;
__near __no_bit_access __no_init volatile union { unsigned char SEG6; __BITS8 SEG6_bit; } @ 0xF0406;
__near __no_bit_access __no_init volatile union { unsigned char SEG7; __BITS8 SEG7_bit; } @ 0xF0407;
__near __no_bit_access __no_init volatile union { unsigned char SEG8; __BITS8 SEG8_bit; } @ 0xF0408;
__near __no_bit_access __no_init volatile union { unsigned char SEG9; __BITS8 SEG9_bit; } @ 0xF0409;
__near __no_bit_access __no_init volatile union { unsigned char SEG10; __BITS8 SEG10_bit; } @ 0xF040A;
__near __no_bit_access __no_init volatile union { unsigned char SEG11; __BITS8 SEG11_bit; } @ 0xF040B;
__near __no_bit_access __no_init volatile union { unsigned char SEG12; __BITS8 SEG12_bit; } @ 0xF040C;
__near __no_bit_access __no_init volatile union { unsigned char SEG13; __BITS8 SEG13_bit; } @ 0xF040D;
__near __no_bit_access __no_init volatile union { unsigned char SEG14; __BITS8 SEG14_bit; } @ 0xF040E;
__near __no_bit_access __no_init volatile union { unsigned char SEG15; __BITS8 SEG15_bit; } @ 0xF040F;
__near __no_bit_access __no_init volatile union { unsigned char SEG16; __BITS8 SEG16_bit; } @ 0xF0410;
__near __no_bit_access __no_init volatile union { unsigned char SEG17; __BITS8 SEG17_bit; } @ 0xF0411;
__near __no_bit_access __no_init volatile union { unsigned char SEG18; __BITS8 SEG18_bit; } @ 0xF0412;
__near __no_bit_access __no_init volatile union { unsigned char SEG19; __BITS8 SEG19_bit; } @ 0xF0413;
__near __no_bit_access __no_init volatile union { unsigned char SEG20; __BITS8 SEG20_bit; } @ 0xF0414;
__near __no_bit_access __no_init volatile union { unsigned char SEG21; __BITS8 SEG21_bit; } @ 0xF0415;
__near __no_bit_access __no_init volatile union { unsigned char SEG22; __BITS8 SEG22_bit; } @ 0xF0416;
__near __no_bit_access __no_init volatile union { unsigned char SEG23; __BITS8 SEG23_bit; } @ 0xF0417;
__near __no_bit_access __no_init volatile union { unsigned char SEG24; __BITS8 SEG24_bit; } @ 0xF0418;
__near __no_bit_access __no_init volatile union { unsigned char SEG25; __BITS8 SEG25_bit; } @ 0xF0419;
__near __no_bit_access __no_init volatile union { unsigned char SEG26; __BITS8 SEG26_bit; } @ 0xF041B;
__near __no_bit_access __no_init volatile union { unsigned char SEG27; __BITS8 SEG27_bit; } @ 0xF041C;
__near __no_bit_access __no_init volatile union { unsigned char SEG28; __BITS8 SEG28_bit; } @ 0xF041D;
__near __no_bit_access __no_init volatile union { unsigned char SEG29; __BITS8 SEG29_bit; } @ 0xF041E;
__near __no_bit_access __no_init volatile union { unsigned char SEG30; __BITS8 SEG30_bit; } @ 0xF041F;
__near __no_bit_access __no_init volatile union { unsigned char SEG31; __BITS8 SEG31_bit; } @ 0xF0420;
__near __no_bit_access __no_init volatile union { unsigned char SEG32; __BITS8 SEG32_bit; } @ 0xF0421;
__near __no_bit_access __no_init volatile union { unsigned char SEG33; __BITS8 SEG33_bit; } @ 0xF0422;
__near __no_bit_access __no_init volatile union { unsigned char SEG34; __BITS8 SEG34_bit; } @ 0xF0423;
__near __no_bit_access __no_init volatile union { unsigned char SEG35; __BITS8 SEG35_bit; } @ 0xF0424;
__near __no_bit_access __no_init volatile union { unsigned char SEG36; __BITS8 SEG36_bit; } @ 0xF0425;
__near __no_bit_access __no_init volatile union { unsigned char SEG37; __BITS8 SEG37_bit; } @ 0xF0426;
__near __no_bit_access __no_init volatile union { unsigned char SEG38; __BITS8 SEG38_bit; } @ 0xF0427;
__near __no_bit_access __no_init volatile union { unsigned char SEG39; __BITS8 SEG39_bit; } @ 0xF0428;
__near __no_bit_access __no_init volatile union { unsigned char SEG40; __BITS8 SEG40_bit; } @ 0xF0429;
__near __no_bit_access __no_init volatile union { unsigned char SEG41; __BITS8 SEG41_bit; } @ 0xF042A;
__near __no_bit_access __no_init volatile union { unsigned char SEG42; __BITS8 SEG42_bit; } @ 0xF042B;
__near __no_bit_access __no_init volatile union { unsigned char SEG43; __BITS8 SEG43_bit; } @ 0xF042C;
__near __no_bit_access __no_init volatile union { unsigned char SEG44; __BITS8 SEG44_bit; } @ 0xF042D;
__near __no_bit_access __no_init volatile union { unsigned char SEG45; __BITS8 SEG45_bit; } @ 0xF042E;
__near __no_bit_access __no_init volatile union { unsigned char SEG46; __BITS8 SEG46_bit; } @ 0xF042F;
__near __no_bit_access __no_init volatile union { unsigned char SEG47; __BITS8 SEG47_bit; } @ 0xF0430;
__near __no_bit_access __no_init volatile union { unsigned char SEG48; __BITS8 SEG48_bit; } @ 0xF0431;
__near __no_bit_access __no_init volatile union { unsigned char SEG49; __BITS8 SEG49_bit; } @ 0xF0432;
__near __no_bit_access __no_init volatile union { unsigned char SEG50; __BITS8 SEG50_bit; } @ 0xF0433;
__near __no_bit_access __no_init volatile union { unsigned short TKBCR00; __BITS16 TKBCR00_bit; } @ 0xF0500;
__near __no_bit_access __no_init volatile union { unsigned short TKBCR01; __BITS16 TKBCR01_bit; } @ 0xF0502;
__near __no_bit_access __no_init volatile union { unsigned short TKBCR02; __BITS16 TKBCR02_bit; } @ 0xF0504;
__near __no_bit_access __no_init volatile union { unsigned short TKBCR03; __BITS16 TKBCR03_bit; } @ 0xF0506;
__near __no_bit_access __no_init volatile union { unsigned short TKBSIR00; __BITS16 TKBSIR00_bit; } @ 0xF050A;
__near __no_bit_access __no_init volatile union { unsigned short TKBSIR01; __BITS16 TKBSIR01_bit; } @ 0xF050C;
__near __no_bit_access __no_init volatile union { unsigned char TKBDNR00; __BITS8 TKBDNR00_bit; } @ 0xF050E;
__near __no_bit_access __no_init volatile union { unsigned char TKBSSR00; __BITS8 TKBSSR00_bit; } @ 0xF050F;
__near __no_bit_access __no_init volatile union { unsigned char TKBDNR01; __BITS8 TKBDNR01_bit; } @ 0xF0510;
__near __no_bit_access __no_init volatile union { unsigned char TKBSSR01; __BITS8 TKBSSR01_bit; } @ 0xF0511;
__near __no_init volatile union { unsigned char TKBTRG0; __BITS8 TKBTRG0_bit; } @ 0xF0512;
__near __no_init volatile const union { unsigned char TKBFLG0; __BITS8 TKBFLG0_bit; } @ 0xF0513;
__near __no_bit_access __no_init volatile union { unsigned short TKBCRLD00; __BITS16 TKBCRLD00_bit; } @ 0xF0514;
__near __no_bit_access __no_init volatile union { unsigned short TKBCRLD01; __BITS16 TKBCRLD01_bit; } @ 0xF0516;
__near __no_bit_access __no_init volatile const union { unsigned short TKBCNT0; __BITS16 TKBCNT0_bit; } @ 0xF0520;
__near __no_bit_access __no_init volatile union { unsigned short TKBCTL00; __BITS16 TKBCTL00_bit; } @ 0xF0522;
__near __no_bit_access __no_init volatile union { unsigned short TKBMFR0; __BITS16 TKBMFR0_bit; } @ 0xF0524;
__near __no_init volatile union { unsigned char TKBIOC00; __BITS8 TKBIOC00_bit; } @ 0xF0526;
__near __no_init volatile union { unsigned char TKBCLR0; __BITS8 TKBCLR0_bit; } @ 0xF0527;
__near __no_init volatile union { unsigned char TKBIOC01; __BITS8 TKBIOC01_bit; } @ 0xF0528;
__near __no_init volatile union { unsigned char TKBCTL01; __BITS8 TKBCTL01_bit; } @ 0xF0529;
__near __no_bit_access __no_init volatile union { unsigned char TKBPSCS0; __BITS8 TKBPSCS0_bit; } @ 0xF052A;
__near __no_bit_access __no_init volatile union { unsigned short TKBPACTL00; __BITS16 TKBPACTL00_bit; } @ 0xF0530;
__near __no_bit_access __no_init volatile union { unsigned short TKBPACTL01; __BITS16 TKBPACTL01_bit; } @ 0xF0532;
__near __no_init volatile union { unsigned char TKBPAHFS0; __BITS8 TKBPAHFS0_bit; } @ 0xF0534;
__near __no_init volatile union { unsigned char TKBPAHFT0; __BITS8 TKBPAHFT0_bit; } @ 0xF0535;
__near __no_init volatile const union { unsigned char TKBPAFLG0; __BITS8 TKBPAFLG0_bit; } @ 0xF0536;
__near __no_init volatile union { unsigned char TKBPACTL02; __BITS8 TKBPACTL02_bit; } @ 0xF0537;

/*----------------------------------------------
 *       Extended SFR bit declarations
 *--------------------------------------------*/

#define ADTYP             ADM2_bit.no0
#define AWC               ADM2_bit.no2
#define ADRCK             ADM2_bit.no3

#define TOS0              TOS_bit.no0

#define TKB2EN            PER1_bit.no4
#define CMPEN             PER1_bit.no5
#define TMKAEN            PER1_bit.no7

#define DFLEN             DFLCTL_bit.no0

#define DIVST             MDUC_bit.no0
#define MACSF             MDUC_bit.no1
#define MACOF             MDUC_bit.no2
#define MDSM              MDUC_bit.no3
#define MACMODE           MDUC_bit.no6
#define DIVMODE           MDUC_bit.no7

#define TAU0EN            PER0_bit.no0
#define SAU0EN            PER0_bit.no2
#define SAU1EN            PER0_bit.no3
#define IICA0EN           PER0_bit.no4
#define ADCEN             PER0_bit.no5
#define RTCWEN            PER0_bit.no7

#define WDVOL             RMC_bit.no7

#define RPEF              RPECTL_bit.no0
#define RPERDIS           RPECTL_bit.no7

#define DWAIT2            DMC2_bit.no4
#define DS2               DMC2_bit.no5
#define DRS2              DMC2_bit.no6
#define STG2              DMC2_bit.no7

#define DWAIT3            DMC3_bit.no4
#define DS3               DMC3_bit.no5
#define DRS3              DMC3_bit.no6
#define STG3              DMC3_bit.no7

#define DST2              DRC2_bit.no0
#define DEN2              DRC2_bit.no7

#define DST3              DRC3_bit.no0
#define DEN3              DRC3_bit.no7

#define SPT0              IICCTL00_bit.no0
#define STT0              IICCTL00_bit.no1
#define ACKE0             IICCTL00_bit.no2
#define WTIM0             IICCTL00_bit.no3
#define SPIE0             IICCTL00_bit.no4
#define WREL0             IICCTL00_bit.no5
#define LREL0             IICCTL00_bit.no6
#define IICE0             IICCTL00_bit.no7

#define PRS0              IICCTL01_bit.no0
#define DFC0              IICCTL01_bit.no2
#define SMC0              IICCTL01_bit.no3
#define DAD0              IICCTL01_bit.no4
#define CLD0              IICCTL01_bit.no5
#define WUP0              IICCTL01_bit.no7

#define CRC0EN            CRC0CTL_bit.no7

#define C0ENB             COMPMDR_bit.no0
#define C0MON             COMPMDR_bit.no3
#define C1ENB             COMPMDR_bit.no4
#define C1MON             COMPMDR_bit.no7

#define C0IE              COMPOCR_bit.no0
#define C0OE              COMPOCR_bit.no1
#define C0OP              COMPOCR_bit.no2
#define C1IE              COMPOCR_bit.no4
#define C1OE              COMPOCR_bit.no5
#define C1OP              COMPOCR_bit.no6
#define SPDMD             COMPOCR_bit.no7

#define TKBRDT0           TKBTRG0_bit.no0

#define TKBRSF0           TKBFLG0_bit.no0
#define TKBMFF0           TKBFLG0_bit.no1
#define TKBIEF0           TKBFLG0_bit.no2
#define TKBIRF0           TKBFLG0_bit.no3
#define TKBSEF00          TKBFLG0_bit.no4
#define TKBSEF01          TKBFLG0_bit.no5
#define TKBSSF00          TKBFLG0_bit.no6
#define TKBSSF01          TKBFLG0_bit.no7

#define TKBTOD00          TKBIOC00_bit.no0
#define TKBTOD01          TKBIOC00_bit.no1
#define TKBTOL00          TKBIOC00_bit.no2
#define TKBTOL01          TKBIOC00_bit.no3

#define TKBCLMF0          TKBCLR0_bit.no1
#define TKBCLIE0          TKBCLR0_bit.no2
#define TKBCLIR0          TKBCLR0_bit.no3
#define TKBCLSE00         TKBCLR0_bit.no4
#define TKBCLSE01         TKBCLR0_bit.no5

#define TKBTOE00          TKBIOC01_bit.no0
#define TKBTOE01          TKBIOC01_bit.no1

#define TKBCE0            TKBCTL01_bit.no7

#define TKBPAHTS00        TKBPAHFS0_bit.no0
#define TKBPAHTS01        TKBPAHFS0_bit.no1

#define TKBPAHTT00        TKBPAHFT0_bit.no0
#define TKBPAHTT01        TKBPAHFT0_bit.no1

#define TKBPAHIF00        TKBPAFLG0_bit.no0
#define TKBPAFIF00        TKBPAFLG0_bit.no1
#define TKBPAHIF01        TKBPAFLG0_bit.no2
#define TKBPAFIF01        TKBPAFLG0_bit.no3
#define TKBPAHSF00        TKBPAFLG0_bit.no4
#define TKBPAFSF00        TKBPAFLG0_bit.no5
#define TKBPAHSF01        TKBPAFLG0_bit.no6
#define TKBPAFSF01        TKBPAFLG0_bit.no7

#define TKBPACE00         TKBPACTL02_bit.no0
#define TKBPACE01         TKBPACTL02_bit.no1

#pragma language=restore

#endif /* __IAR_SYSTEMS_ICC__ */

#ifdef __IAR_SYSTEMS_ASM__

/*----------------------------------------------
 *       Extended SFR declarations
 *--------------------------------------------*/

ADM2       DEFINE  0xF0010
ADUL       DEFINE  0xF0011
ADLL       DEFINE  0xF0012
ADTES      DEFINE  0xF0013
PU0        DEFINE  0xF0030
PU1        DEFINE  0xF0031
PU2        DEFINE  0xF0032
PU3        DEFINE  0xF0033
PU4        DEFINE  0xF0034
PU5        DEFINE  0xF0035
PU7        DEFINE  0xF0037
PU12       DEFINE  0xF003C
PU13       DEFINE  0xF003D
PIM0       DEFINE  0xF0040
PIM1       DEFINE  0xF0041
PIM3       DEFINE  0xF0043
PIM4       DEFINE  0xF0044
PIM5       DEFINE  0xF0045
POM0       DEFINE  0xF0050
POM1       DEFINE  0xF0051
POM3       DEFINE  0xF0053
POM4       DEFINE  0xF0054
POM5       DEFINE  0xF0055
POM13      DEFINE  0xF005D
PMC1       DEFINE  0xF0061
PMC2       DEFINE  0xF0062
PMC4       DEFINE  0xF0064
NFEN0      DEFINE  0xF0070
NFEN1      DEFINE  0xF0071
ISC        DEFINE  0xF0073
TIS0       DEFINE  0xF0074
ADPC       DEFINE  0xF0076
PIOR       DEFINE  0xF0077
IAWCTL     DEFINE  0xF0078
TOS        DEFINE  0xF0079
PER1       DEFINE  0xF007A
PMS        DEFINE  0xF007B
PWCTKB     DEFINE  0xF007C
DFLCTL     DEFINE  0xF0090
HOCODIV    DEFINE  0xF00A8
TEMPCAL0   DEFINE  0xF00AC
TEMPCAL1   DEFINE  0xF00AD
TEMPCAL2   DEFINE  0xF00AE
TEMPCAL3   DEFINE  0xF00AF
MDCL       DEFINE  0xF00E0
MDCH       DEFINE  0xF00E2
MDUC       DEFINE  0xF00E8
PER0       DEFINE  0xF00F0
OSMC       DEFINE  0xF00F3
RMC        DEFINE  0xF00F4
RPECTL     DEFINE  0xF00F5
PORSR      DEFINE  0xF00F9
BCDADJ     DEFINE  0xF00FE
SSR00      DEFINE  0xF0100
SSR00L     DEFINE  0xF0100
SSR01      DEFINE  0xF0102
SSR01L     DEFINE  0xF0102
SSR02      DEFINE  0xF0104
SSR02L     DEFINE  0xF0104
SSR03      DEFINE  0xF0106
SSR03L     DEFINE  0xF0106
SIR00      DEFINE  0xF0108
SIR00L     DEFINE  0xF0108
SIR01      DEFINE  0xF010A
SIR01L     DEFINE  0xF010A
SIR02      DEFINE  0xF010C
SIR02L     DEFINE  0xF010C
SIR03      DEFINE  0xF010E
SIR03L     DEFINE  0xF010E
SMR00      DEFINE  0xF0110
SMR01      DEFINE  0xF0112
SMR02      DEFINE  0xF0114
SMR03      DEFINE  0xF0116
SCR00      DEFINE  0xF0118
SCR01      DEFINE  0xF011A
SCR02      DEFINE  0xF011C
SCR03      DEFINE  0xF011E
SE0        DEFINE  0xF0120
SE0L       DEFINE  0xF0120
SS0        DEFINE  0xF0122
SS0L       DEFINE  0xF0122
ST0        DEFINE  0xF0124
ST0L       DEFINE  0xF0124
SPS0       DEFINE  0xF0126
SPS0L      DEFINE  0xF0126
SO0        DEFINE  0xF0128
SOE0       DEFINE  0xF012A
SOE0L      DEFINE  0xF012A
SOL0       DEFINE  0xF0134
SOL0L      DEFINE  0xF0134
SSC0       DEFINE  0xF0138
SSC0L      DEFINE  0xF0138
SSR10      DEFINE  0xF0140
SSR10L     DEFINE  0xF0140
SSR11      DEFINE  0xF0142
SSR11L     DEFINE  0xF0142
SSR12      DEFINE  0xF0144
SSR12L     DEFINE  0xF0144
SSR13      DEFINE  0xF0146
SSR13L     DEFINE  0xF0146
SIR10      DEFINE  0xF0148
SIR10L     DEFINE  0xF0148
SIR11      DEFINE  0xF014A
SIR11L     DEFINE  0xF014A
SIR12      DEFINE  0xF014C
SIR12L     DEFINE  0xF014C
SIR13      DEFINE  0xF014E
SIR13L     DEFINE  0xF014E
SMR10      DEFINE  0xF0150
SMR11      DEFINE  0xF0152
SMR12      DEFINE  0xF0154
SMR13      DEFINE  0xF0156
SCR10      DEFINE  0xF0158
SCR11      DEFINE  0xF015A
SCR12      DEFINE  0xF015C
SCR13      DEFINE  0xF015E
SE1        DEFINE  0xF0160
SE1L       DEFINE  0xF0160
SS1        DEFINE  0xF0162
SS1L       DEFINE  0xF0162
ST1        DEFINE  0xF0164
ST1L       DEFINE  0xF0164
SPS1       DEFINE  0xF0166
SPS1L      DEFINE  0xF0166
SO1        DEFINE  0xF0168
SOE1       DEFINE  0xF016A
SOE1L      DEFINE  0xF016A
SOL1       DEFINE  0xF0174
SOL1L      DEFINE  0xF0174
SSC1       DEFINE  0xF0178
SSC1L      DEFINE  0xF0178
TCR00      DEFINE  0xF0180
TCR01      DEFINE  0xF0182
TCR02      DEFINE  0xF0184
TCR03      DEFINE  0xF0186
TCR04      DEFINE  0xF0188
TCR05      DEFINE  0xF018A
TCR06      DEFINE  0xF018C
TCR07      DEFINE  0xF018E
TMR00      DEFINE  0xF0190
TMR01      DEFINE  0xF0192
TMR02      DEFINE  0xF0194
TMR03      DEFINE  0xF0196
TMR04      DEFINE  0xF0198
TMR05      DEFINE  0xF019A
TMR06      DEFINE  0xF019C
TMR07      DEFINE  0xF019E
TSR00      DEFINE  0xF01A0
TSR00L     DEFINE  0xF01A0
TSR01      DEFINE  0xF01A2
TSR01L     DEFINE  0xF01A2
TSR02      DEFINE  0xF01A4
TSR02L     DEFINE  0xF01A4
TSR03      DEFINE  0xF01A6
TSR03L     DEFINE  0xF01A6
TSR04      DEFINE  0xF01A8
TSR04L     DEFINE  0xF01A8
TSR05      DEFINE  0xF01AA
TSR05L     DEFINE  0xF01AA
TSR06      DEFINE  0xF01AC
TSR06L     DEFINE  0xF01AC
TSR07      DEFINE  0xF01AE
TSR07L     DEFINE  0xF01AE
TE0        DEFINE  0xF01B0
TE0L       DEFINE  0xF01B0
TS0        DEFINE  0xF01B2
TS0L       DEFINE  0xF01B2
TT0        DEFINE  0xF01B4
TT0L       DEFINE  0xF01B4
TPS0       DEFINE  0xF01B6
TO0        DEFINE  0xF01B8
TO0L       DEFINE  0xF01B8
TOE0       DEFINE  0xF01BA
TOE0L      DEFINE  0xF01BA
TOL0       DEFINE  0xF01BC
TOL0L      DEFINE  0xF01BC
TOM0       DEFINE  0xF01BE
TOM0L      DEFINE  0xF01BE
DSA2       DEFINE  0xF0200
DSA3       DEFINE  0xF0201
DRA2       DEFINE  0xF0202
DRA2L      DEFINE  0xF0202
DRA2H      DEFINE  0xF0203
DRA3       DEFINE  0xF0204
DRA3L      DEFINE  0xF0204
DRA3H      DEFINE  0xF0205
DBC2       DEFINE  0xF0206
DBC2L      DEFINE  0xF0206
DBC2H      DEFINE  0xF0207
DBC3       DEFINE  0xF0208
DBC3L      DEFINE  0xF0208
DBC3H      DEFINE  0xF0209
DMC2       DEFINE  0xF020A
DMC3       DEFINE  0xF020B
DRC2       DEFINE  0xF020C
DRC3       DEFINE  0xF020D
IICCTL00   DEFINE  0xF0230
IICCTL01   DEFINE  0xF0231
IICWL0     DEFINE  0xF0232
IICWH0     DEFINE  0xF0233
SVA0       DEFINE  0xF0234
ELSELR00   DEFINE  0xF0240
ELSELR01   DEFINE  0xF0241
ELSELR02   DEFINE  0xF0242
ELSELR03   DEFINE  0xF0243
ELSELR04   DEFINE  0xF0244
ELSELR05   DEFINE  0xF0245
ELSELR06   DEFINE  0xF0246
ELSELR07   DEFINE  0xF0247
ELSELR08   DEFINE  0xF0248
ELSELR09   DEFINE  0xF0249
CRC0CTL    DEFINE  0xF02F0
PGCRCL     DEFINE  0xF02F2
CRCD       DEFINE  0xF02FA
PFSEG0     DEFINE  0xF0300
PFSEG1     DEFINE  0xF0301
PFSEG2     DEFINE  0xF0302
PFSEG3     DEFINE  0xF0303
PFSEG4     DEFINE  0xF0304
PFSEG5     DEFINE  0xF0305
PFSEG6     DEFINE  0xF0306
ISCLCD     DEFINE  0xF0308
SUBCUD     DEFINE  0xF0310
COMPMDR    DEFINE  0xF0340
COMPFIR    DEFINE  0xF0341
COMPOCR    DEFINE  0xF0342
SEG0       DEFINE  0xF0400
SEG1       DEFINE  0xF0401
SEG2       DEFINE  0xF0402
SEG3       DEFINE  0xF0403
SEG4       DEFINE  0xF0404
SEG5       DEFINE  0xF0405
SEG6       DEFINE  0xF0406
SEG7       DEFINE  0xF0407
SEG8       DEFINE  0xF0408
SEG9       DEFINE  0xF0409
SEG10      DEFINE  0xF040A
SEG11      DEFINE  0xF040B
SEG12      DEFINE  0xF040C
SEG13      DEFINE  0xF040D
SEG14      DEFINE  0xF040E
SEG15      DEFINE  0xF040F
SEG16      DEFINE  0xF0410
SEG17      DEFINE  0xF0411
SEG18      DEFINE  0xF0412
SEG19      DEFINE  0xF0413
SEG20      DEFINE  0xF0414
SEG21      DEFINE  0xF0415
SEG22      DEFINE  0xF0416
SEG23      DEFINE  0xF0417
SEG24      DEFINE  0xF0418
SEG25      DEFINE  0xF0419
SEG26      DEFINE  0xF041B
SEG27      DEFINE  0xF041C
SEG28      DEFINE  0xF041D
SEG29      DEFINE  0xF041E
SEG30      DEFINE  0xF041F
SEG31      DEFINE  0xF0420
SEG32      DEFINE  0xF0421
SEG33      DEFINE  0xF0422
SEG34      DEFINE  0xF0423
SEG35      DEFINE  0xF0424
SEG36      DEFINE  0xF0425
SEG37      DEFINE  0xF0426
SEG38      DEFINE  0xF0427
SEG39      DEFINE  0xF0428
SEG40      DEFINE  0xF0429
SEG41      DEFINE  0xF042A
SEG42      DEFINE  0xF042B
SEG43      DEFINE  0xF042C
SEG44      DEFINE  0xF042D
SEG45      DEFINE  0xF042E
SEG46      DEFINE  0xF042F
SEG47      DEFINE  0xF0430
SEG48      DEFINE  0xF0431
SEG49      DEFINE  0xF0432
SEG50      DEFINE  0xF0433
TKBCR00    DEFINE  0xF0500
TKBCR01    DEFINE  0xF0502
TKBCR02    DEFINE  0xF0504
TKBCR03    DEFINE  0xF0506
TKBSIR00   DEFINE  0xF050A
TKBSIR01   DEFINE  0xF050C
TKBDNR00   DEFINE  0xF050E
TKBSSR00   DEFINE  0xF050F
TKBDNR01   DEFINE  0xF0510
TKBSSR01   DEFINE  0xF0511
TKBTRG0    DEFINE  0xF0512
TKBFLG0    DEFINE  0xF0513
TKBCRLD00  DEFINE  0xF0514
TKBCRLD01  DEFINE  0xF0516
TKBCNT0    DEFINE  0xF0520
TKBCTL00   DEFINE  0xF0522
TKBMFR0    DEFINE  0xF0524
TKBIOC00   DEFINE  0xF0526
TKBCLR0    DEFINE  0xF0527
TKBIOC01   DEFINE  0xF0528
TKBCTL01   DEFINE  0xF0529
TKBPSCS0   DEFINE  0xF052A
TKBPACTL00 DEFINE  0xF0530
TKBPACTL01 DEFINE  0xF0532
TKBPAHFS0  DEFINE  0xF0534
TKBPAHFT0  DEFINE  0xF0535
TKBPAFLG0  DEFINE  0xF0536
TKBPACTL02 DEFINE  0xF0537

#endif /* __IAR_SYSTEMS_ASM__ */

#endif /* __IOR5F10WMG_EXT_H__ */
