#ifndef __BSP_RS004_H__
#define __BSP_RS004_H__

#include    "r_cg_macrodriver.h"
#include    "lib_rs004.h"
#include    "config.h"

//定义各个IO�?
#if DEF_BOARD_VERSION == DEF_FixTure
  /***********************************KEY***************************************/
    #define IO_KEY_USER_DIR_IN          PORT13InputConfig(BIT7)
    #define IO_KEY_USER_READ            PORT13ReadBit(BIT7)

  /***********************************led****************************************/
    #define LED_Baud2400_OUT            PORT7OutputConfig(BIT6);PFSEG2ClearBit(BIT2)
    #define LED_Baud2400_1              PORT7SetBit(BIT6)
    #define LED_Baud2400_0              PORT7ClearBit(BIT6)

    #define LED_Baud9600_OUT            PORT7OutputConfig(BIT7);PFSEG2ClearBit(BIT3)
    #define LED_Baud9600_1              PORT7SetBit(BIT7)
    #define LED_Baud9600_0              PORT7ClearBit(BIT7)

    #define LED_FIR_OUT                 PORT1OutputConfig(BIT6);POM1ClearBit(BIT6);PFSEG5ClearBit(BIT2);
    #define LED_FIR_1                   PORT1SetBit(BIT6) 
    #define LED_FIR_0                   PORT1ClearBit(BIT6)

  /***********************************UART***************************************/

    #define IO_TXD0_DIR_OUT             NOP()  // PORT0OutputConfig(BIT0);POM0ClearBit(BIT0);PFSEG5ClearBit(BIT4)
    #define IO_TXD0_1                   NOP()  // PORT0SetBit(BIT0)
    #define IO_TXD0_0                   NOP()  // PORT0ClearBit(BIT0)

    #define IO_RXD0_DIR_IN              PORT1InputConfig(BIT7);PIM1ClearBit(BIT7);PFSEG5ClearBit(BIT3)
    #define IO_RXD0_DIR_OUT             PORT1OutputConfig(BIT7);POM1ClearBit(BIT7);PFSEG5ClearBit(BIT3)
    #define IO_RXD0_1                   PORT1SetBit(BIT7)
    #define IO_RXD0_0                   PORT1ClearBit(BIT7)

    #define IO_TXD1_DIR_OUT             PORT4OutputConfig(BIT2);POM4ClearBit(BIT2);PMC4ClearBit(BIT2);
    #define IO_TXD1_1                   PORT4SetBit(BIT2)
    #define IO_TXD1_0                   PORT4ClearBit(BIT2)

    #define IO_RXD1_DIR_OUT             PORT4OutputConfig(BIT3);POM4ClearBit(BIT3);PMC4ClearBit(BIT3);
    #define IO_RXD1_1                   PORT4SetBit(BIT3)
    #define IO_RXD1_0                   PORT4ClearBit(BIT3)

    #define IO_TXD2_DIR_OUT             PORT0OutputConfig(BIT4);POM0ClearBit(BIT4);PFSEG6ClearBit(BIT0)
    #define IO_TXD2_1                   PORT0SetBit(BIT4)
    #define IO_TXD2_0                   PORT0ClearBit(BIT4)

    #define IO_RXD2_DIR_OUT             PORT0OutputConfig(BIT3);PFSEG5ClearBit(BIT7)
    #define IO_RXD2_1                   PORT0SetBit(BIT3)
    #define IO_RXD2_0                   PORT0ClearBit(BIT3)

    #define IO_TXD3_DIR_OUT             PORT3OutputConfig(BIT5);POM3ClearBit(BIT5);PFSEG3ClearBit(BIT1)
    #define IO_TXD3_1                   PORT3SetBit(BIT5)
    #define IO_TXD3_0                   PORT3ClearBit(BIT5)

    #define IO_RXD3_DIR_OUT             PORT3OutputConfig(BIT4);PFSEG3ClearBit(BIT0)
    #define IO_RXD3_1                   PORT3SetBit(BIT4)
    #define IO_RXD3_0                   PORT3ClearBit(BIT4)

  /***********************************DEBUG UART ********************************/
    #define IO_USBSET_DIR_IN            PORT1InputConfig(BIT2);PMC1ClearBit(BIT2);PFSEG4ClearBit(BIT6);PORT1PullUpBit(BIT2)
    #define IO_USBSET_READ              PORT1ReadBit(BIT2)

  /***********************************IR/BLUE TOOTH***************************************/
    #define IO_NIRCTL_OUT               PORT3OutputConfig(BIT0);PFSEG2ClearBit(BIT0)
    #define IO_NIRCTL_1                 PORT3SetBit(BIT0)
    #define IO_NIRCTL_0                 PORT3ClearBit(BIT0)

    #define IO_FIRCTL_OUT               PORT0OutputConfig(BIT5);POM0ClearBit(BIT5);PFSEG6ClearBit(BIT1)
    #define IO_FIRCTL_1                 PORT0SetBit(BIT5)
    #define IO_FIRCTL_0                 PORT0ClearBit(BIT5)

    #define IO_IR_PWM_OUT               PORT4OutputConfig(BIT2);POM4ClearBit(BIT2);PMC4ClearBit(BIT2)
    #define IO_IR_PWM_1                 PORT4SetBit(BIT2)
    #define IO_IR_PWM_0                 PORT4ClearBit(BIT2)

    #define IO_BLE_POWER_DIR_OUT        PORT12OutputConfig(BIT7);{ISCLCD |= BIT0;}
    #define IO_BLE_POWER_1              PORT12SetBit(BIT7)
    #define IO_BLE_POWER_0              PORT12ClearBit(BIT7)

/***********************************other*********************************/
    #define IO_TOOL_DIR_IN              PORT4InputConfig(BIT0)
    #define IO_TOOL_DIR_OUT             PORT4OutputConfig(BIT0)
    #define IO_TOOL_0                   PORT4ClearBit(BIT0)

#endif
//�����LED����˳��
typedef enum
{
    COM_Baud9600    = 0,
    COM_Baud2400    = 1,
    COM_FIR         = 2,
    COM_FIR_EVEN    = 3,
    OFF_ALL         = 4,
} COM_TypeDef;

#define COM_COUNT   	5

typedef enum
{
    BUTTON_USER = 0,    //�û�����
}Button_TypeDef;

typedef enum
{
    COM0 = 0,
    COM1 = 1,
    COM2 = 2,
    COM3 = 3
}USART_TypeDef;

typedef enum
{
    Dis = 0,
    En,
}EnDis;

typedef enum
{
    IODIR_Input = 0,    //����
    IODIR_Output,       //���
}IODIR;

void CBB_NOP(void);

extern unsigned char GetKeyStatus(Button_TypeDef key_type);
void OpenKeyInt(Button_TypeDef key_type, short(*fun)(unsigned char type));
extern void ConfigKeyDir(Button_TypeDef key_type);

extern void DelayMs(unsigned int Ms);

extern unsigned short OM_ReceiveGprsUartData(void);
extern void SetUsartIoTxOut(USART_TypeDef com, unsigned char fun);
extern void SetUsartIoRxOut(USART_TypeDef com, unsigned char fun);
extern void USBSetDirIn(void);
extern unsigned char GetUSBSetStatus(void);
extern void UsartConfig(unsigned char com, unsigned long baud, void(*fun)(unsigned char rxd), unsigned char parity);
extern unsigned char UsartSendData(unsigned char com,unsigned char *buf,unsigned short len);
extern void OpenUsart(unsigned char com);
extern void CloseUsart(unsigned char com);
extern void DebugUartIntConfig(unsigned c,void(*p)(void));
extern void NIRUartIntConfig(unsigned c,void(*p)(void));
extern void FIRUartIntConfig(unsigned c,void(*p)(void));
extern void SetUsartIoRxOut(USART_TypeDef com, unsigned char fun);

extern void LEDOff(COM_TypeDef type);
extern void LEDOn(COM_TypeDef type);

extern void SetNIRPower(unsigned char fun);
extern void SetFIRPower(unsigned char fun);
extern void SetInfraredPWMIO(unsigned char fun);
extern void SetInfraredModeCtl(unsigned char fun);
extern void SetInfraredConnStatusIn(void);
extern unsigned char GetInfraredConnStatus(void);
extern void SetInfraredBusyIn(void);
extern void SetInfraredConnStatusOut(unsigned char fun);
extern void SetInfraredBTBUSYOut(unsigned char fun);

extern unsigned char CmpString(unsigned char * dataA,unsigned char * dataB,unsigned short LenA, unsigned short LenB);

void SetUsartIoTxIn(USART_TypeDef com);
void SetUsartIoRxIn(USART_TypeDef com);
void CloseUsartRecvInterrupt(unsigned char com);

extern void LedOrBeepTick(COM_TypeDef type, unsigned short count, unsigned short time_on, unsigned short time_off);
#endif
