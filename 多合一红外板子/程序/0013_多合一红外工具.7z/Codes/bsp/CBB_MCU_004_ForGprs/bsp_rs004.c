#include "bsp_rs004.h"
#include "drv_uart.h"
#include "string.h"
#include "config.h"
/* Set option bytes */
#pragma location = "OPTBYTE"
__root const uint8_t opbyte0 = 0x7FU;
#pragma location = "OPTBYTE"
__root const uint8_t opbyte1 = 0xFFU;   //0xFF�������ø�λ��ѹ
#pragma location = "OPTBYTE"
__root const uint8_t opbyte2 = 0xEAU;
#pragma location = "OPTBYTE"
__root const uint8_t opbyte3 = 0x04U;

/* Set security ID */
#pragma location = "SECUID"
__root const uint8_t secuid[10] = 
    {0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U, 0x00U};

extern void IrqServerDefaultRS(unsigned char Data);
extern void IrqServerDefault(void);


/**********************************Timer**************************************/
/**
 * ��ʱ������
 */
void User_TimerCfg(unsigned char type, unsigned char len, IRQServerFT CallBack)
{
    if (type == 0)
    {
        switch(len)
        {
        case 0:
              MCU_TimerCfg(PortVmNum0, TimeSpMs1, CallBack);//MCU_TimerCfg(PortVmNum8, TimeSpMs100, CallBack);
          break;
        case 1:
              MCU_TimerCfg(PortVmNum1, TimeSpMs1, CallBack);
          break;
        case 2:
              MCU_TimerCfg(PortVmNum2, TimeSpMs1, CallBack);
          break;
        }
    }
    else if(type == 1)
    {
        MCU_TimerCfg(PortVmNum9, TimeSpMs1000, CallBack);
    }
    else if(type == 2)
    {
        MCU_TimerCfg(PortVmNum8, TimeSpMs10, CallBack);
    }
}

/**
 * ������ʱ��
 * @param type��0 ��ʱ�ӣ�1 ��Ƶʱ�ӣ�2 �����ʱ��
 */
void User_TimerStart(unsigned char type)
{
    if (type == 0)
        MCU_TimerStart(PortVmNum0);//MCU_TimerStart(PortVmNum8);
    else if(type == 1)
        MCU_TimerStart(PortVmNum9);
    else if(type == 2)
        MCU_TimerStart(PortVmNum8);
    else
      ;
}

/**
 * ֹͣ��ʱ��
 * @param type��0 ��ʱ�ӣ�1 ��Ƶʱ�ӣ�2 �����ʱ�� 
 */
void User_TimerStop(unsigned char type)
{
    if (type == 0)
        MCU_TimerStop(PortVmNum0);//MCU_TimerStop(PortVmNum8);
    else if(type == 1)
        MCU_TimerStop(PortVmNum9);
    else if(type == 2)
        MCU_TimerStop(PortVmNum8);
    else
      ;
}

/*===============================LED����==============================*/
/**
 * ����COM�ڵ���LED��
 * @param type :0-�����⣨2400��ָʾ�ƣ�1-�����⣨9600��ָʾ�ƣ�2-Զ����ָʾ��
 */
void LEDOn(COM_TypeDef type)
{
    switch(type)
    {
        case COM_Baud2400:
            LED_Baud2400_OUT;
            LED_Baud2400_0;
            break;
        case COM_Baud9600:
            LED_Baud9600_OUT;
            LED_Baud9600_0;
            break;
        case COM_FIR_EVEN:
            LED_FIR_OUT;
            LED_FIR_0;
            LED_Baud9600_OUT;
            LED_Baud9600_0;
            break;
        case COM_FIR:
            LED_FIR_OUT;
            LED_FIR_0;
            break;
        default:break;
    }
}

/**
 * ����COM�ر�LED
 * @param type��0-2400������ָʾ�ƣ�1-9600������ָʾ�ƣ�2-Զ����ָʾ��
 */
void LEDOff(COM_TypeDef type)
{
    switch(type)
    {
        case COM_Baud2400:
            LED_Baud2400_OUT;
            LED_Baud2400_1;
            break;
        case COM_Baud9600:
            LED_Baud9600_OUT;
            LED_Baud9600_1;
            break;
        case COM_FIR_EVEN:
            LED_FIR_OUT;
            LED_FIR_1;
            LED_Baud9600_OUT;
            LED_Baud9600_1;
            break;
        case COM_FIR:
            LED_FIR_OUT;
            LED_FIR_1;
            break;
        default:break;
    }
}

/*===============================KEY����==============================*/

/**
 * ������������Ϊ���뷽��
 * @param fun��
 */
void ConfigKeyDir(Button_TypeDef key_type)
{
    if(key_type == BUTTON_USER)
    {
        IO_KEY_USER_DIR_IN;;
    }
    else 
    {
    }
}

/**
 * ��ȡ�����ļ�ֵ
 * @return
 */
unsigned char GetKeyStatus(Button_TypeDef key_type)
{
    if(key_type == BUTTON_USER)
    {
        if (IO_KEY_USER_READ)
            return 1;
        else
            return 0;
    }
    else
    {
        return 0;
    }
}

/**
 * �����ж�����
 * @param key_type
 * @param fun:�жϷ�����
 */
void OpenKeyInt(Button_TypeDef key_type, short(*fun)(unsigned char type))
{
    if(key_type == BUTTON_USER)
    {
        INT0Config(FALLING_EDGE_INT, fun);
        EnableINT0;
    }
    else
    {

    }
}

/**
 * �رհ����ж�
 * @param key_type
 */
void CloseKeyInt(Button_TypeDef key_type)
{
    if(key_type == BUTTON_USER)
    {
        DisableINT0;
    }
    else
    {
    }
}

/***********************************��������*********************************/


/**
* �������ã�UART ��1 
* λ��ʼλ��1λֹͣλ��8λ����λ����У�� 
* ȫ����ʹ�ܽ����ж� 
* @author wb (2014-11-06)
*
* @param com :���ڶ˿�:0-USB;1-GPRS;2-���;3-Ĭ��
* @param baud 
*             :�����ʣ�0-1200��1-2400;2-4800;3-9600��4-19200;5-38400;6-115200
* @param fun �����ڽ����жϷ�����
*/
void UsartConfig(unsigned char com, unsigned long baud, void(*fun)(unsigned char rxd), unsigned char parity)//���
{
    UartMode Mode;
      
    switch (baud)
    {
    case 0:
        Mode.Baud = UartBaud1200;
        break;
    case 1:
        Mode.Baud = UartBaud2400;
        break;
    case 2:
        Mode.Baud = UartBaud4800;
        break;
    case 3:
        Mode.Baud = UartBaud9600;
        break;
    case 4:
        Mode.Baud = UartBaud19200;
        break;
    case 5:
        Mode.Baud = UartBaud38400;
        break;
    case 6:
        Mode.Baud = UartBaud115200;
        break;
    case 7:
        Mode.Baud = UartBaud10753;
        break;
    default:
        break;
    }
    switch (com)
    {
    case 0:
        Mode.Parity = parity;
        Mode.StopBit = STOP_1;
        Mode.DataBit = DATA_8;
        Mode.Sequence = LSB;
        Uart0Config(&Mode,0,fun);
        break;
    case 1:
        Mode.Parity = parity;
        Mode.StopBit = 1;
        Mode.DataBit = 1;
        Mode.Sequence = 0;
        Uart1Config(&Mode, 0, fun);
        break;
    case 2:
        Mode.Parity = parity;
        Mode.StopBit = 1;
        Mode.DataBit = 1;
        Mode.Sequence = 0;
        Uart2Config(&Mode, 0, fun);
        break;
    case 3:
        Mode.Parity = parity;
        Mode.StopBit = STOP_1;
        Mode.DataBit = DATA_8;
        Mode.Sequence = LSB;
        Uart3Config(&Mode, 0, fun);
        break;
    default:
        break;
    }
}

/**
* �������ã��򿪴���
*
* @author wb (2014-11-06)
*
* @param com �����ڶ˿�:0-USB;1-GPRS;2-���;3-Ĭ��
*/
void OpenUsart(unsigned char com)//���
{
    switch (com)
    {
    default:
    case 0:
        Uart0SendEnable();
        Uart0ReceiveEnable();
        break;
    case 1:
        Uart1SendEnable();
        Uart1ReceiveEnable(); 
        break;
    case 2:
        Uart2SendEnable();
        Uart2ReceiveEnable(); 
        break;
    case 3:
        Uart3SendEnable();
        Uart3ReceiveEnable(); 
        break;
    }
}

/**
* �������ã��رմ���
*
* @author wb (2014-11-06)
*
* @param com :���ڶ˿�:0-USB;1-GPRS;2-���;3-Ĭ��
*/
void CloseUsart(unsigned char com)//���
{
    switch (com)
    {
    default:
    case 0:
        Uart0SendDisable();
        Uart0ReceiveDisable();
        break;
    case 1:
        Uart1SendDisable();
        Uart1ReceiveDisable(); 
        break;
    case 2:
        Uart2SendDisable();
        Uart2ReceiveDisable(); 
        break;
    case 3:
        Uart3SendDisable();
        Uart3ReceiveDisable(); 
      break;
    }
}

/**
* �������ã��رմ��ڽ����ж�
*
* @author wb (2014-11-06)
*
* @param com :���ڶ˿�:0-USB;1-GPRS;2-���;3-Ĭ��
*/
void CloseUsartRecvInterrupt(unsigned char com)
{
    switch (com)
    {
    default:
    case 0:
        Uart0ReceiveINTDisable();
        break;
    case 1:
        Uart1ReceiveINTDisable(); 
        break;
    case 2:
        Uart2ReceiveINTDisable(); 
        break;
    case 3:
        Uart3ReceiveINTDisable(); 
      break;
    }
}

void DebugUartIntConfig(unsigned c,void(*p)(void))
{
    if(c == 0)
        INT7Config(RISING_EDGE_INT,p);
    else
        INT7Config(FALLING_EDGE_INT,p);
    EnableINT7;
}

void NIRUartIntConfig(unsigned c,void(*p)(void))
{
    if(c == 0)
        INT3Config(RISING_EDGE_INT,p);
    else
        INT3Config(FALLING_EDGE_INT,p);
    EnableINT3;
}

void FIRUartIntConfig(unsigned c,void(*p)(void))
{
    if(c == 0)
        INT5Config(RISING_EDGE_INT,p);
    else
        INT5Config(FALLING_EDGE_INT,p);
    EnableINT5;
}

/**
 * ���ô���TX IOΪ�����
 * @param com
 */
void SetUsartIoTxOut(USART_TypeDef com, unsigned char fun)//���
{
    switch (com)
    {
    default:
    case COM0:
        IO_TXD0_DIR_OUT;
        if (fun == 1)
        {
          IO_TXD0_1;
        }
        else
        {
          IO_TXD0_0;
        }
        break;
    case COM1:
        IO_TXD1_DIR_OUT;
        if (fun == 1)
        {
          IO_TXD1_1;
        }
        else
        {
          IO_TXD1_0;
        }
        break;
    case COM2:
        IO_TXD2_DIR_OUT;
        if (fun == 1)
        {
          IO_TXD2_1;
        }
        else
        {
          IO_TXD2_0;
        }
        break;
        break;
    case COM3:
        IO_TXD3_DIR_OUT;
        if (fun == 1)
        {
          IO_TXD3_1;
        }
        else
        {
          IO_TXD3_0;
        }
        break;
    }
}

/**
 * ���ô���RX IOΪ�����
 * @param com
 */
void SetUsartIoRxOut(USART_TypeDef com, unsigned char fun)
{
    switch(com)
    {
        case COM0:
            IO_RXD0_DIR_OUT;
            if (fun == 1)
            {
                IO_RXD0_1;
            }
            else
            {
                IO_RXD0_0;
            }
            break;
        case COM1:
            IO_RXD1_DIR_OUT;
            if (fun == 1)
            {
                IO_RXD1_1;
            }
            else
            {
                IO_RXD1_0;
            }
            break;
        case COM2:
            IO_RXD2_DIR_OUT;
            if (fun == 1)
            {
                IO_RXD2_1;
            }
            else
            {
                IO_RXD2_0;
            }
            break;
        case COM3:
            IO_RXD3_DIR_OUT;
            if (fun == 1)
            {
                IO_RXD3_1;
            }
            else
            {
                IO_RXD3_0;
            }
            break;
        default:break;
    }
}

/**
* ���ڷ�������
* 
* @author wb (2014-11-19)
* 
* @param com �����ڶ˿�:0-USB;1-GPRS;2-���;3-Ĭ��
* @param buf :�������ݻ�����
* @param len ���������ݳ���
* 
* @return unsigned char ������1-���ͳɹ�������0-����ʧ��
*/

unsigned char UsartSendData(unsigned char com,unsigned char *buf,unsigned short len)//���
{
    switch (com)
    {
    default:
    case 0:
        Uart0SendData(buf,len);
        DelayMs(20);
        break;
    case 1:
        Uart1SendData(buf, len);
        break;
    case 2:
        Uart2SendData(buf, len);
        break;
    case 3:
        SendPreamble();
        Uart3SendData(buf, len);
      break;
    }
    return 1;
}

/**
 * ����USB SET����Ϊ���뷽��
 */
void USBSetDirIn(void)
{   
    IO_USBSET_DIR_IN;
}

/**
 * ��ȡUSB SET��״̬
 * @return
 */
unsigned char GetUSBSetStatus(void)
{
  return IO_USBSET_READ;
}

/**
 * �򿪽������Դ
 * @param fun
 */
void SetNIRPower(unsigned char fun)
{
    IO_NIRCTL_OUT;
    if (fun == 1)
    {
        IO_NIRCTL_1;
    }
    else
    {
        IO_NIRCTL_0;
    }
}

/**
 * ��Զ�����Դ
 * @param fun
 */
void SetFIRPower(unsigned char fun)
{
    IO_FIRCTL_OUT;
    if (fun == 1)
    {
        IO_FIRCTL_1;
    }
    else
    {
        IO_FIRCTL_0;
    }
}

void SetInfraredPWMIO(unsigned char fun)
{
    IO_IR_PWM_OUT;
    if (fun == 1)
    {
        IO_IR_PWM_1;
    }else{
        IO_IR_PWM_0;
    }
}

/**
 * @brief �ж�A�Ƿ�ΪB���Ӵ�
 * 
 * @param dataA 
 * @param dataB 
 * @param LenA 
 * @param LenB 
 * @return 1 �� 0 ��
 */
unsigned char CmpString(unsigned char * dataA,unsigned char * dataB,unsigned short LenA ,unsigned short LenB)
{
    unsigned short i = 0;
    unsigned short cnt = 0;
    if(LenA > LenB)     return 0;
    while(cnt < LenA && i < LenB)
    {
        if(dataB[i] == dataA[cnt])
        {
            i++;
            cnt++;
        }else{
            i = i - cnt +1;//����a = "aaab" b = "aabcd" ��֤b���жϵ���3λʱ����ת�صڶ���a
            cnt = 0;
        }
    }
    if(cnt == LenA)
        return 1;
    else
        return 0;
}
