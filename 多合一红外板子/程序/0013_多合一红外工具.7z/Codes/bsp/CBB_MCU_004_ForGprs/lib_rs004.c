/*
                                                    ****************************
                                                            lib_rs004
                                                    ****************************

说明:       文件说明

        端口寄存器说明:
            • (PMxx):0 输出;1输入
            • (Pxx):端口电平寄存器
            • (PUxx):0不上拉,1上拉
            • (PIMxx):0 Normal input buffer//1 TTL input buffer
            • (POMxx):0 普通输出//1 N-ch open-drain 输出
            • (PMCxx):0 数字,1模拟
            • (ADPC):ANI0/P21, ANI1/P20 pins to digital I/O of port or analog input of A/D converter
            • (PIOR)
            • (PFSEG0 to PFSEG6):液晶端口
            • (ISCLCD)
            主频配置：
                2.4V-5.5V
                High-speedOCO(fiH)
                8MHz

需求:       对硬件或其它软件的需求
版本:       v0.0.0
版权:       威星智能仪表股份有限公司　版权所有，(c)2000-2050
修改记录:   --------------------------------------------------------------------
            日期:           负责人:     工作:           版本:
            XXXX-XX-XX      XXXX    创建/修改/增加/重写 v0.0.0
********************************************************************************
*/

#define     _lib_rs004_C_
#include 	"r_cg_macrodriver.h"
#include    "config.h"

#include    "bsp_rs004.h"

#include    "lib_rs004.h"

#include    "r_cg_cgc.h"
#include    "r_cg_lcd.h"
//#include    "r_cg_it.h"
#include    "r_cg_adc.h"
#include    "r_cg_rtc.h"
#include    "r_cg_tau.h"

static unsigned short Random;
void IrqServerDefaultRS(unsigned char Data){ ; }
void IrqServerDefault(void){ ; }
short IrqServerDefaukltKey(unsigned char type) {return -1;}

IRQServerKeyFT IRQServerINT0 = IrqServerDefaukltKey;
IRQServerFT IRQServerINT1 = IrqServerDefault;
IRQServerFT IRQServerINT2 = IrqServerDefault;
IRQServerFT IRQServerINT3 = IrqServerDefault;
IRQServerFT IRQServerINT4 = IrqServerDefault;
IRQServerFT IRQServerINT5 = IrqServerDefault;
IRQServerFT IRQServerINT6 = IrqServerDefault;
IRQServerFT IRQServerINT7 = IrqServerDefault;
#pragma vector = INTP0_vect
__interrupt static void r_intc0_interrupt(void)
{
    EI();
    IRQServerINT0(BUTTON_USER);
    Random++;
}

#pragma vector = INTP1_vect
__interrupt static void r_intc1_interrupt(void)
{
    EI();
    IRQServerINT1();
    Random++;
}

#pragma vector = INTP2_vect
__interrupt static void r_intc2_interrupt(void)
{
    EI();
    IRQServerINT2();
    Random++;
}

#pragma vector = INTP3_vect
__interrupt static void r_intc3_interrupt(void)
{
    EI();
    IRQServerINT3();
    Random++;
}

#pragma vector = INTP4_vect
__interrupt static void r_intc4_interrupt(void)
{
    EI();
    IRQServerINT4();
    Random++;
}

#pragma vector = INTP5_vect
__interrupt static void r_intc5_interrupt(void)
{
    EI();
    IRQServerINT5();
    Random++;
}

#pragma vector = INTP6_vect
__interrupt static void r_intc6_interrupt(void)
{
    EI();
    IRQServerINT6();
    Random++;
}

#pragma vector = INTP7_vect
__interrupt static void r_intc7_interrupt(void)
{
    EI();
    IRQServerINT7();
    Random++;
}

//Config: RISING_EDGE_INT/FALLING_EDGE_INT
void INT0Config(unsigned char Config, IRQServerKeyFT Fuc)
{
    PMK0 = 1U;    /* disable INTP0 operation */
    PIF0 = 0U;    /* clear INTP0 interrupt flag */
    /* Set INTP0 low priority */
    PPR10 = 1U;
    PPR00 = 1U;
    if(Config == RISING_EDGE_INT)
    {


        EGP0 |= BIT0;	//INTP0上升沿中断
        EGN0 &= ~BIT0;	
    }
    else
    {


        EGP0 &= ~BIT0;	
        EGN0 |= BIT0;	//INTP0下降沿中断
    }
	IRQServerINT0 = Fuc;
}

void INT1Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK1 = 1U;    /* disable INTP1 operation */
    PIF1 = 0U;    /* clear INTP1 interrupt flag */
    /* Set INTP1 low priority */
    PPR11 = 1U;
    PPR01 = 1U;
    if(Config == RISING_EDGE_INT)
    {
        

        EGP0 |= BIT1;	//INTP1上升沿中断
        EGN0 &= ~BIT1;	
    }
    else
    {


        EGP0 &= ~BIT1;	
        EGN0 |= BIT1;	//INTP1下降沿中断
    }
    /* Set INTP1 pin */
    PFSEG0 &= 0xBFU;
    PM5 |= 0x04U;
    IRQServerINT1 = Fuc;
}

void INT2Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK2 = 1U;    /* disable INTP2 operation */
    PIF2 = 0U;    /* clear INTP2 interrupt flag */
    /* Set INTP2 low priority */
    PPR12 = 1U;
    PPR02 = 1U;
    if(Config == RISING_EDGE_INT)
    {

        EGP0 |= BIT2;	//INTP2上升沿中断
        EGN0 &= ~BIT2;	
    }
    else
    {


        EGP0 &= ~BIT2;	
        EGN0 |= BIT2;	//INTP2下降沿中断
    }
    /* Set INTP2 pin */
    PFSEG0 &= 0x7FU;
    PM5 |= 0x08U;
    IRQServerINT2 = Fuc;
}

void INT3Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK3 = 1U;    /* disable INTP3 operation */
    PIF3 = 0U;    /* clear INTP3 interrupt flag */
    /* Set INTP3 low priority */
    PPR13 = 1U;
    PPR03 = 1U;
    if(Config == RISING_EDGE_INT)
    {


        EGP0 |= BIT3;	//INTP3上升沿中断
        EGN0 &= ~BIT3;	
    }
    else
    {


        EGP0 &= ~BIT3;	
        EGN0 |= BIT3;	//INTP3下降沿中断
    }
    /* Set INTP3 pin */
    PFSEG2 &= 0xDFU;
    PM3 |= 0x02U;
    IRQServerINT3 = Fuc;
}

void INT4Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK4 = 1U;    /* disable INTP4 operation */
    PIF4 = 0U;    /* clear INTP4 interrupt flag */
    /* Set INTP4 low priority */
    PPR14 = 1U;
    PPR04 = 1U;
    if(Config == RISING_EDGE_INT)
    {


        EGP0 |= BIT4;	//INTP4上升沿中断
        EGN0 &= ~BIT4;
    }
    else
    {


        EGP0 &= ~BIT4;
        EGN0 |= BIT4;	//INTP4下降沿中断
    }
    /* Set INTP4 pin */
    PFSEG2 &= 0x7FU;
    PM3 |= 0x08U;
    IRQServerINT4 = Fuc;
}

void INT5Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK5 = 1U;    /* disable INTP5 operation */
    PIF5 = 0U;    /* clear INTP5 interrupt flag */
    /* Set INTP5 low priority */
    PPR15 = 1U;
    PPR05 = 1U;
    if(Config == RISING_EDGE_INT)
    {
        EGP0 |= BIT5;	//INTP5上升沿中断
        EGN0 &= ~BIT5;
    }
    else
    {
        EGP0 &= ~BIT5;	
        EGN0 |= BIT5;	//INTP5下降沿中断
    }
    /* Set INTP5 pin */
//    PFSEG1 &= 0xFDU;//P55使用第二功能
//    PM5 |= 0x20U;
    PFSEG5 &= 0xDFU;    //端口第二功能
    PM0 |= 0x02U;       //端口第二功能
//    PIOR |= 0x1 << 4;
    IRQServerINT5 = Fuc;
}

void INT6Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK6 = 1U;    /* disable INTP6 operation */
    PIF6 = 0U;    /* clear INTP6 interrupt flag */
    /* Set INTP6 low priority */
    PPR16 = 1U;
    PPR06 = 1U;
    if(Config == RISING_EDGE_INT)
    {
        EGP0 |= BIT6;	//INTP6上升沿中断
        EGN0 &= ~BIT6;
    }
    else
    {
        EGP0 &= ~BIT6;
        EGN0 |= BIT6;	//INTP6下降沿中断
    }
    /* Set INTP6 pin */
    PFSEG1 &= 0xF7U;
    PM5 |= 0x80U;
    IRQServerINT6 = Fuc;
}

void INT7Config(unsigned char Config, IRQServerFT Fuc)
{
    PMK7 = 1U;    /* disable INTP7 operation */
    PIF7 = 0U;    /* clear INTP7 interrupt flag */
    /* Set INTP7 low priority */
    PPR17 = 1U;
    PPR07 = 1U;
    if(Config == RISING_EDGE_INT)
    {
        EGP0 |= BIT7;	//INTP7上升沿中断
        EGN0 &= ~BIT7;	
    }
    else
    {
        EGP0 &= ~BIT7;	
        EGN0 |= BIT7;	//INTP7下降沿中断
    }
    /* Set INTP7 pin */
    PFSEG5 &= 0xBFU;
    PM0 |= 0x04U;
//PM4 |= 0x08U;  //端口第二功能
    IRQServerINT7 = Fuc;
}

/**************************************************************************/

IRQServerRecvDataFT IRQServerUart0Receive = IrqServerDefaultRS;
IRQServerRecvDataFT IRQServerUart1Receive = IrqServerDefaultRS;
IRQServerRecvDataFT IRQServerUart2Receive = IrqServerDefaultRS;
IRQServerRecvDataFT IRQServerUart3Receive = IrqServerDefaultRS;
#pragma vector = INTST0_vect
__interrupt static void r_uart0_interrupt_send(void)
{
    EI();
    Random++;
}

#pragma vector = INTST1_vect
__interrupt static void r_uart1_interrupt_send(void)
{
    EI();
    Random++;
}

#pragma vector = INTST2_vect
__interrupt static void r_uart2_interrupt_send(void)
{
    EI();
    Random++;
}

#pragma vector = INTST3_vect
__interrupt static void r_uart3_interrupt_send(void)
{
    EI();
    Random++;
}

#pragma vector = INTSR0_vect
__interrupt static void r_uart0_interrupt_receive(void)
{  
    unsigned char rx_data;
    EI();
    rx_data = RXD0;
    IRQServerUart0Receive(rx_data);
    Random += rx_data;
}

#pragma vector = INTSR1_vect
__interrupt static void r_uart1_interrupt_receive(void)
{  
    unsigned char rx_data;
    EI();
    rx_data = RXD1;
    IRQServerUart1Receive(rx_data);
    Random += rx_data;
}

#pragma vector = INTSR2_vect
__interrupt static void r_uart2_interrupt_receive(void)
{  
    unsigned char rx_data;
    EI();
    rx_data = RXD2;
    IRQServerUart2Receive(rx_data);
    Random += rx_data;
}

#pragma vector = INTSR3_vect
__interrupt static void r_uart3_interrupt_receive(void)
{  
    unsigned char rx_data;
    EI();
    rx_data = RXD3;
    IRQServerUart3Receive(rx_data);
    Random += rx_data;
}

void Uart0Config(pUartMode Mode, IRQServerSendDataFT SendFun, IRQServerRecvDataFT RecvFun)
{
    SAU0EN = 1U;    /* supply SAU0 clock */
    NOP();
    NOP();
    NOP();
    NOP();
    switch(Mode->Baud)
    {
    case UartBaud1200:
        SPS0 = SPS0 & 0xF0 | _0005_SAU_CK00_FCLK_5;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud2400:
        SPS0 = SPS0 & 0xF0 | _0004_SAU_CK00_FCLK_4;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud4800:
        SPS0 = SPS0 & 0xF0 | _0003_SAU_CK00_FCLK_3;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud9600:
        SPS0 = SPS0 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud19200:
        SPS0 = SPS0 & 0xF0 | _0001_SAU_CK00_FCLK_1;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud38400:
        SPS0 = SPS0 & 0xF0 | _0000_SAU_CK00_FCLK_0;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud115200:
        SPS0 = SPS0 & 0xF0 | _0000_SAU_CK00_FCLK_0;
        SDR00 = _4400_UART0_TRANSMIT_DIVISOR;
        SDR01 = _4400_UART0_RECEIVE_DIVISOR;
        break;
    case UartBaud10753:
        SPS0 = SPS0 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR00 = _B800_UART0_TRANSMIT_DIVISOR;
        SDR01 = _B800_UART0_RECEIVE_DIVISOR;
        break;
    default:
        SPS0 = SPS0 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR00 = _CE00_UART0_TRANSMIT_DIVISOR;
        SDR01 = _CE00_UART0_RECEIVE_DIVISOR;
        break;
    }
    ST0 |= _0002_SAU_CH1_STOP_TRG_ON | _0001_SAU_CH0_STOP_TRG_ON;    /* disable UART0 receive and transmit */
    STMK0 = 1U;    /* disable INTST0 interrupt */
    STIF0 = 0U;    /* clear INTST0 interrupt flag */
    SRMK0 = 1U;    /* disable INTSR0 interrupt */
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
    SREMK0 = 1U;   /* disable INTSRE0 interrupt */
    SREIF0 = 0U;   /* clear INTSRE0 interrupt flag */
    /* Set INTST0 low priority */
    STPR10 = 1U;
    STPR00 = 1U;
    /* Set INTSR0 low priority */
    SRPR10 = 1U;
    SRPR00 = 1U;
    SMR00 = _0020_SAU_SMRMN_INITIALVALUE | _0000_SAU_CLOCK_SELECT_CK00 | _0000_SAU_TRIGGER_SOFTWARE | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    NFEN0 |= _01_SAU_RXD0_FILTER_ON;
    SIR01 = _0004_SAU_SIRMN_FECTMN | _0002_SAU_SIRMN_PECTMN | _0001_SAU_SIRMN_OVCTMN;    /* clear error flag */
    SMR01 = _0020_SAU_SMRMN_INITIALVALUE | _0000_SAU_CLOCK_SELECT_CK00 | _0100_SAU_TRIGGER_RXD | _0000_SAU_EDGE_FALL | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    SCR00 = _8000_SAU_TRANSMISSION | _0000_SAU_INTSRE_MASK;
    SCR01 = _4000_SAU_RECEPTION | _0000_SAU_INTSRE_MASK;
    //奇偶检验位
    if(Mode->Parity == PARITY_ODD)
    {
        SCR00 = SCR00 | _0300_SAU_PARITY_ODD;
        SCR01 = SCR01 | _0300_SAU_PARITY_ODD;
    }
    else if(Mode->Parity == PARITY_EVEN)
    {
        SCR00 = SCR00 | _0200_SAU_PARITY_EVEN;
        SCR01 = SCR01 | _0200_SAU_PARITY_EVEN;
    }
    else
    {
        SCR00 = SCR00 | _0000_SAU_PARITY_NONE;
        SCR01 = SCR01 | _0000_SAU_PARITY_NONE;
    }
    //停止位
    if(Mode->StopBit == STOP_NONE)
    {
        SCR00 = SCR00 | _0000_SAU_STOP_NONE;
        SCR01 = SCR01 | _0000_SAU_STOP_NONE;
    }
    else if(Mode->StopBit == STOP_2)
    {
        SCR00 = SCR00 | _0020_SAU_STOP_2;
        SCR01 = SCR01 | _0020_SAU_STOP_2;
    }
    else
    {
        SCR00 = SCR00 | _0010_SAU_STOP_1;
        SCR01 = SCR01 | _0010_SAU_STOP_1;
    }
    //数据位
    if(Mode->DataBit == DATA_7)
    {
        SCR00 = SCR00 | _0006_SAU_LENGTH_7;
        SCR01 = SCR01 | _0006_SAU_LENGTH_7;
    }
    else if(Mode->DataBit == DATA_9)
    {
        SCR00 = SCR00 | _0005_SAU_LENGTH_9;
        SCR01 = SCR01 | _0005_SAU_LENGTH_9;
    }
    else
    {
        SCR00 = SCR00 | _0007_SAU_LENGTH_8;
        SCR01 = SCR01 | _0007_SAU_LENGTH_8;
    }
    if(Mode->Sequence == MSB)
    {
        SCR00 = SCR00 | _0000_SAU_MSB;
        SCR01 = SCR01 | _0000_SAU_MSB;
    }
    else
    {
        SCR00 = SCR00 | _0080_SAU_LSB;
        SCR01 = SCR01 | _0080_SAU_LSB;
    } 
    /* Set RxD0 pin */
    PFSEG5 &= 0xF7U;
    PM1 |= 0x80U;
    /* Set TxD0 pin */
    PFSEG5 &= 0xEFU;
    P0 |= 0x01U;
    PM0 &= 0xFEU;
	IRQServerUart0Receive = RecvFun;
}

void Uart1Config(pUartMode Mode, IRQServerSendDataFT SendFun, IRQServerRecvDataFT RecvFun)
{
    SAU0EN = 1U;    /* supply SAU0 clock */
    NOP();
    NOP();
    NOP();
    NOP();
    switch(Mode->Baud)
    {
    case UartBaud1200:
        SPS0 = SPS0 & 0x0F | _0050_SAU_CK01_FCLK_5;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud2400:
        SPS0 = SPS0 & 0x0F | _0040_SAU_CK01_FCLK_4;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud4800:
        SPS0 = SPS0 & 0x0F | _0030_SAU_CK01_FCLK_3;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud9600:
        SPS0 = SPS0 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud19200:
        SPS0 = SPS0 & 0x0F | _0010_SAU_CK01_FCLK_1;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud38400:
        SPS0 = SPS0 & 0x0F | _0000_SAU_CK01_FCLK_0;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud115200:
        SPS0 = SPS0 & 0x0F | _0000_SAU_CK01_FCLK_0;
        SDR02 = _4400_UART1_TRANSMIT_DIVISOR;
        SDR03 = _4400_UART1_RECEIVE_DIVISOR;
        break;
    case UartBaud10753:
        SPS0 = SPS0 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR02 = _B800_UART1_TRANSMIT_DIVISOR;
        SDR03 = _B800_UART1_RECEIVE_DIVISOR;
        break;
    default:
        SPS0 = SPS0 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR02 = _CE00_UART1_TRANSMIT_DIVISOR;
        SDR03 = _CE00_UART1_RECEIVE_DIVISOR;
        break;
    }
    ST0 |= _0008_SAU_CH3_STOP_TRG_ON | _0004_SAU_CH2_STOP_TRG_ON;    /* disable UART1 receive and transmit */
    STMK1 = 1U;    /* disable INTST1 interrupt */
    STIF1 = 0U;    /* clear INTST1 interrupt flag */
    SRMK1 = 1U;    /* disable INTSR1 interrupt */
    SRIF1 = 0U;    /* clear INTSR1 interrupt flag */
    SREMK1 = 1U;   /* disable INTSRE1 interrupt */
    SREIF1 = 0U;   /* clear INTSRE1 interrupt flag */
    /* Set INTST1 low priority */
    STPR11 = 1U;
    STPR01 = 1U;
    /* Set INTSR1 low priority */
    SRPR11 = 1U;
    SRPR01 = 1U;
    SMR02 = _0020_SAU_SMRMN_INITIALVALUE | _8000_SAU_CLOCK_SELECT_CK01 | _0000_SAU_TRIGGER_SOFTWARE | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    NFEN0 |= _04_SAU_RXD1_FILTER_ON;
    SIR03 = _0004_SAU_SIRMN_FECTMN | _0002_SAU_SIRMN_PECTMN | _0001_SAU_SIRMN_OVCTMN;    /* clear error flag */
    SMR03 = _0020_SAU_SMRMN_INITIALVALUE | _8000_SAU_CLOCK_SELECT_CK01 | _0100_SAU_TRIGGER_RXD | _0000_SAU_EDGE_FALL | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    SCR02 = _8000_SAU_TRANSMISSION | _0000_SAU_INTSRE_MASK;
    SCR03 = _4000_SAU_RECEPTION | _0000_SAU_INTSRE_MASK;
    //奇偶检验位
    if(Mode->Parity == PARITY_ODD)
    {
        SCR02 = SCR02 | _0300_SAU_PARITY_ODD;
        SCR03 = SCR03 | _0300_SAU_PARITY_ODD;
    }
    else if(Mode->Parity == PARITY_EVEN)
    {
        SCR02 = SCR02 | _0200_SAU_PARITY_EVEN;
        SCR03 = SCR03 | _0200_SAU_PARITY_EVEN;
    }
    else
    {
        SCR02 = SCR02 | _0000_SAU_PARITY_NONE;
        SCR03 = SCR03 | _0000_SAU_PARITY_NONE;
    }
    //停止位
    if(Mode->StopBit == STOP_NONE)
    {
        SCR02 = SCR02 | _0000_SAU_STOP_NONE;
        SCR03 = SCR03 | _0000_SAU_STOP_NONE;
    }
    else if(Mode->StopBit == STOP_2)
    {
        SCR02 = SCR02 | _0020_SAU_STOP_2;
        SCR03 = SCR03 | _0020_SAU_STOP_2;
    }
    else
    {
        SCR02 = SCR02 | _0010_SAU_STOP_1;
        SCR03 = SCR03 | _0010_SAU_STOP_1;
    }
    //数据位
    if(Mode->DataBit == DATA_7)
    {
        SCR02 = SCR02 | _0006_SAU_LENGTH_7;
        SCR03 = SCR03 | _0006_SAU_LENGTH_7;
    }
    else if(Mode->DataBit == DATA_9)
    {
        SCR02 = SCR02 | _0005_SAU_LENGTH_9;
        SCR03 = SCR03 | _0005_SAU_LENGTH_9;
    }
    else
    {
        SCR02 = SCR02 | _0007_SAU_LENGTH_8;
        SCR03 = SCR03 | _0007_SAU_LENGTH_8;
    }
    if(Mode->Sequence == MSB)
    {
        SCR02 = SCR02 | _0000_SAU_MSB;
        SCR03 = SCR03 | _0000_SAU_MSB;
    }
    else
    {
        SCR02 = SCR02 | _0080_SAU_LSB;
        SCR03 = SCR03 | _0080_SAU_LSB;
    } 
//    /* Set RxD1 pin */
//    PFSEG6 &= 0xFBU;
//    PM0 |= 0x40U;
//    /* Set TxD1 pin */
//    PFSEG6 &= 0xF7U;
//    P0 |= 0x80U;
//    PM0 &= 0x7FU;
    
    /* Set RxD1 pin */
    PMC4 &= 0xF7U;
    PM4 |= 0x08U;
    PU4 |= (1 << 3);
    /* Set TxD1 pin */
    PMC4 &= 0xFBU;
    P4 |= 0x04U;
    PM4 &= 0xFBU;
    IRQServerUart1Receive = RecvFun;
}

void Uart2Config(pUartMode Mode, IRQServerSendDataFT SendFun, IRQServerRecvDataFT RecvFun)
{
    SAU1EN = 1U;    /* supply SAU1 clock */
    NOP();
    NOP();
    NOP();
    NOP();
    switch(Mode->Baud)
    {
    case UartBaud1200:
        SPS1 = SPS1 & 0xF0 | _0005_SAU_CK00_FCLK_5;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud2400:
        SPS1 = SPS1 & 0xF0 | _0004_SAU_CK00_FCLK_4;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud4800:
        SPS1 = SPS1 & 0xF0 | _0003_SAU_CK00_FCLK_3;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud9600:
        SPS1 = SPS1 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud19200:
        SPS1 = SPS1 & 0xF0 | _0001_SAU_CK00_FCLK_1;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud38400:
        SPS1 = SPS1 & 0xF0 | _0000_SAU_CK00_FCLK_0;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud115200:
        SPS1 = SPS1 & 0xF0 | _0000_SAU_CK00_FCLK_0;
        SDR10 = _4400_UART2_TRANSMIT_DIVISOR;
        SDR11 = _4400_UART2_RECEIVE_DIVISOR;
        break;
    case UartBaud10753:
        SPS1 = SPS1 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR10 = _B800_UART2_TRANSMIT_DIVISOR;
        SDR11 = _B800_UART2_RECEIVE_DIVISOR;
        break;
    default:
        SPS1 = SPS1 & 0xF0 | _0002_SAU_CK00_FCLK_2;
        SDR10 = _CE00_UART2_TRANSMIT_DIVISOR;
        SDR11 = _CE00_UART2_RECEIVE_DIVISOR;
        break;
    }
    ST1 |= _0002_SAU_CH1_STOP_TRG_ON | _0001_SAU_CH0_STOP_TRG_ON;    /* disable UART2 receive and transmit */
    STMK2 = 1U;    /* disable INTST2 interrupt */
    STIF2 = 0U;    /* clear INTST2 interrupt flag */
    SRMK2 = 1U;    /* disable INTSR2 interrupt */
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
    SREMK2 = 1U;   /* disable INTSRE2 interrupt */
    SREIF2 = 0U;   /* clear INTSRE2 interrupt flag */
    /* Set INTST2 low priority */
    STPR12 = 1U;
    STPR02 = 1U;
    /* Set INTSR2 low priority */
    SRPR12 = 1U;
    SRPR02 = 1U;
    SMR10 = _0020_SAU_SMRMN_INITIALVALUE | _0000_SAU_CLOCK_SELECT_CK00 | _0000_SAU_TRIGGER_SOFTWARE | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    NFEN0 |= _10_SAU_RXD2_FILTER_ON;
    SIR11 = _0004_SAU_SIRMN_FECTMN | _0002_SAU_SIRMN_PECTMN | _0001_SAU_SIRMN_OVCTMN;    /* clear error flag */
    SMR11 = _0020_SAU_SMRMN_INITIALVALUE | _0000_SAU_CLOCK_SELECT_CK00 | _0100_SAU_TRIGGER_RXD | _0000_SAU_EDGE_FALL | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    SCR10 = _8000_SAU_TRANSMISSION | _0000_SAU_INTSRE_MASK;
    SCR11 = _4000_SAU_RECEPTION | _0000_SAU_INTSRE_MASK;
    //奇偶检验位
    if(Mode->Parity == PARITY_ODD)
    {
        SCR10 = SCR10 | _0300_SAU_PARITY_ODD;
        SCR11 = SCR11 | _0300_SAU_PARITY_ODD;
    }
    else if(Mode->Parity == PARITY_EVEN)
    {
        SCR10 = SCR10 | _0200_SAU_PARITY_EVEN;
        SCR11 = SCR11 | _0200_SAU_PARITY_EVEN;
    }
    else
    {
        SCR10 = SCR10 | _0000_SAU_PARITY_NONE;
        SCR11 = SCR11 | _0000_SAU_PARITY_NONE;
    }
    //停止位
    if(Mode->StopBit == STOP_NONE)
    {
        SCR10 = SCR10 | _0000_SAU_STOP_NONE;
        SCR11 = SCR11 | _0000_SAU_STOP_NONE;
    }
    else if(Mode->StopBit == STOP_2)
    {
        SCR10 = SCR10 | _0020_SAU_STOP_2;
        SCR11 = SCR11 | _0020_SAU_STOP_2;
    }
    else
    {
        SCR10 = SCR10 | _0010_SAU_STOP_1;
        SCR11 = SCR11 | _0010_SAU_STOP_1;
    }
    //数据位
    if(Mode->DataBit == DATA_7)
    {
        SCR10 = SCR10 | _0006_SAU_LENGTH_7;
        SCR11 = SCR11 | _0006_SAU_LENGTH_7;
    }
    else if(Mode->DataBit == DATA_9)
    {
        SCR10 = SCR10 | _0005_SAU_LENGTH_9;
        SCR11 = SCR11 | _0005_SAU_LENGTH_9;
    }
    else
    {
        SCR10 = SCR10 | _0007_SAU_LENGTH_8;
        SCR11 = SCR11 | _0007_SAU_LENGTH_8;
    }
    if(Mode->Sequence == MSB)
    {
        SCR10 = SCR10 | _0000_SAU_MSB;
        SCR11 = SCR11 | _0000_SAU_MSB;
    }
    else
    {
        SCR10 = SCR10 | _0080_SAU_LSB;
        SCR11 = SCR11 | _0080_SAU_LSB;
    } 
    /* Set RxD2 pin */
    PFSEG5 &= ~(1 << 7);
    PM0    |=  (1 << 3);
    PIM0   &= ~(1 << 3);
    PU0    |=  (1 << 3);  //红外模块输出引脚也接到这里了、红外模块断电后的输出不定，所以我们最好上拉一下
    /* Set TxD2 pin */
    ///////////////////////////////////////
    PFSEG6 &= 0xFEU;
    P0     |= 0x10U;
    PM0    &= 0xEFU;
    //////////////////////////////////////
	IRQServerUart2Receive = RecvFun;
}

void Uart3Config(pUartMode Mode, IRQServerSendDataFT SendFun, IRQServerRecvDataFT RecvFun)
{
    SAU1EN = 1U;    /* supply SAU1 clock */
    NOP();
    NOP();
    NOP();
    NOP();
    switch(Mode->Baud)
    {
    case UartBaud1200:
        SPS1 = SPS1 & 0x0F | _0050_SAU_CK01_FCLK_5;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud2400:
        SPS1 = SPS1 & 0x0F | _0040_SAU_CK01_FCLK_4;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud4800:
        SPS1 = SPS1 & 0x0F | _0030_SAU_CK01_FCLK_3;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud9600:
        SPS1 = SPS1 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud19200:
        SPS1 = SPS1 & 0x0F | _0010_SAU_CK01_FCLK_1;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud38400:
        SPS1 = SPS1 & 0x0F | _0000_SAU_CK01_FCLK_0;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud115200:
        SPS1 = SPS1 & 0x0F | _0000_SAU_CK01_FCLK_0;
        SDR12 = _4400_UART3_TRANSMIT_DIVISOR;
        SDR13 = _4400_UART3_RECEIVE_DIVISOR;
        break;
    case UartBaud10753:
        SPS1 = SPS1 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR12 = _B800_UART3_TRANSMIT_DIVISOR;
        SDR13 = _B800_UART3_RECEIVE_DIVISOR;
        break;
    default:
        SPS1 = SPS1 & 0x0F | _0020_SAU_CK01_FCLK_2;
        SDR12 = _CE00_UART3_TRANSMIT_DIVISOR;
        SDR13 = _CE00_UART3_RECEIVE_DIVISOR;
        break;
    }
    ST1 |= _0008_SAU_CH3_STOP_TRG_ON | _0004_SAU_CH2_STOP_TRG_ON;    /* disable UART3 receive and transmit */
    STMK3 = 1U;    /* disable INTST3 interrupt */
    STIF3 = 0U;    /* clear INTST3 interrupt flag */
    SRMK3 = 1U;    /* disable INTSR3 interrupt */
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
    SREMK3 = 1U;   /* disable INTSRE3 interrupt */
    SREIF3 = 0U;   /* clear INTSRE3 interrupt flag */
    /* Set INTST3 low priority */
    STPR13 = 1U;
    STPR03 = 1U;
    /* Set INTSR3 low priority */
    SRPR13 = 1U;
    SRPR03 = 1U;
    SMR12 = _0020_SAU_SMRMN_INITIALVALUE | _8000_SAU_CLOCK_SELECT_CK01 | _0000_SAU_TRIGGER_SOFTWARE | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    NFEN0 |= _40_SAU_RXD3_FILTER_ON;
    SIR13 = _0004_SAU_SIRMN_FECTMN | _0002_SAU_SIRMN_PECTMN | _0001_SAU_SIRMN_OVCTMN;    /* clear error flag */
    SMR13 = _0020_SAU_SMRMN_INITIALVALUE | _8000_SAU_CLOCK_SELECT_CK01 | _0100_SAU_TRIGGER_RXD | _0000_SAU_EDGE_FALL | 
            _0002_SAU_MODE_UART | _0000_SAU_TRANSFER_END;
    SCR12 = _8000_SAU_TRANSMISSION | _0000_SAU_INTSRE_MASK;
    SCR13 = _4000_SAU_RECEPTION | _0000_SAU_INTSRE_MASK;
    //奇偶检验位
    if(Mode->Parity == PARITY_ODD)
    {
        SCR12 = SCR12 | _0300_SAU_PARITY_ODD;
        SCR13 = SCR13 | _0300_SAU_PARITY_ODD;
    }
    else if(Mode->Parity == PARITY_EVEN)
    {
        SCR12 = SCR12 | _0200_SAU_PARITY_EVEN;
        SCR13 = SCR13 | _0200_SAU_PARITY_EVEN;
    }
    else
    {
        SCR12 = SCR12 | _0000_SAU_PARITY_NONE;
        SCR13 = SCR13 | _0000_SAU_PARITY_NONE;
    }
    //停止位
    if(Mode->StopBit == STOP_NONE)
    {
        SCR12 = SCR12 | _0000_SAU_STOP_NONE;
        SCR13 = SCR13 | _0000_SAU_STOP_NONE;
    }
    else if(Mode->StopBit == STOP_2)
    {
        SCR12 = SCR12 | _0020_SAU_STOP_2;
        SCR13 = SCR13 | _0020_SAU_STOP_2;
    }
    else
    {
        SCR12 = SCR12 | _0010_SAU_STOP_1;
        SCR13 = SCR13 | _0010_SAU_STOP_1;
    }
    //数据位
    if(Mode->DataBit == DATA_7)
    {
        SCR12 = SCR12 | _0006_SAU_LENGTH_7;
        SCR13 = SCR13 | _0006_SAU_LENGTH_7;
    }
    else if(Mode->DataBit == DATA_9)
    {
        SCR12 = SCR12 | _0005_SAU_LENGTH_9;
        SCR13 = SCR13 | _0005_SAU_LENGTH_9;
    }
    else
    {
        SCR12 = SCR12 | _0007_SAU_LENGTH_8;
        SCR13 = SCR13 | _0007_SAU_LENGTH_8;
    }
    if(Mode->Sequence == MSB)
    {
        SCR12 = SCR12 | _0000_SAU_MSB;
        SCR13 = SCR13 | _0000_SAU_MSB;
    }
    else
    {
        SCR12 = SCR12 | _0080_SAU_LSB;
        SCR13 = SCR13 | _0080_SAU_LSB;
    } 
    /* Set RxD3 pin */
    PFSEG3 &= 0xFEU;
    PM3 |= 0x10U;
//    PIM3   &= ~(1 << 4);
    /* Set TxD3 pin */
    PFSEG3 &= 0xFDU;
    PM3 &= 0xDFU;
    P3 |= 0x20U;
    IRQServerUart3Receive = RecvFun;
}

void Uart0SendEnable(void)
{
    STIF0 = 0U;    /* clear INTST0 interrupt flag */
    STMK0 = 0U;    /* enable INTST0 interrupt */
    SO0 |= _0001_SAU_CH0_DATA_OUTPUT_1;    /* output level normal */
    SOE0 |= _0001_SAU_CH0_OUTPUT_ENABLE;    /* enable UART0 output */
    SS0 |= _0002_SAU_CH1_START_TRG_ON | _0001_SAU_CH0_START_TRG_ON;    /* enable UART0 receive and transmit */
}

void Uart0SendDisable(void)
{
    ST0 |= _0001_SAU_CH0_STOP_TRG_ON;    /* disable UART0 transmit */
    SOE0 &= ~_0001_SAU_CH0_OUTPUT_ENABLE;    /* disable UART0 output */
    STMK0 = 1U;    /* disable INTST0 interrupt */
    STIF0 = 0U;    /* clear INTST0 interrupt flag */
}

void Uart0ReceiveEnable(void)
{
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
    SRMK0 = 0U;    /* enable INTSR0 interrupt */
    SO0 |= _0001_SAU_CH0_DATA_OUTPUT_1;    /* output level normal */
    SOE0 |= _0001_SAU_CH0_OUTPUT_ENABLE;    /* enable UART0 output */
    SS0 |= _0002_SAU_CH1_START_TRG_ON | _0001_SAU_CH0_START_TRG_ON;    /* enable UART0 receive and transmit */
}

void Uart0ReceiveDisable(void)
{
    ST0 |= _0002_SAU_CH1_STOP_TRG_ON;    /* disable UART0 receive */
    SRMK0 = 1U;    /* disable INTSR0 interrupt */
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
}

void Uart0ReceiveINTDisable(void)
{
    SRMK0 = 1U;    /* disable INTSR0 interrupt */
    SRIF0 = 0U;    /* clear INTSR0 interrupt flag */
}

void Uart1SendEnable(void)
{
    STIF1 = 0U;    /* clear INTST1 interrupt flag */
    STMK1 = 0U;    /* enable INTST1 interrupt */
    SO0 |= _0004_SAU_CH2_DATA_OUTPUT_1;    /* output level normal */
    SOE0 |= _0004_SAU_CH2_OUTPUT_ENABLE;    /* enable UART1 output */
    SS0 |= _0008_SAU_CH3_START_TRG_ON | _0004_SAU_CH2_START_TRG_ON;    /* enable UART1 receive and transmit */
}

void Uart1SendDisable(void)
{
    ST0 |= _0004_SAU_CH2_STOP_TRG_ON;    /* disable UART1 transmit */
    SOE0 &= ~_0004_SAU_CH2_OUTPUT_ENABLE;    /* disable UART1 output */
    STMK1 = 1U;    /* disable INTST1 interrupt */
    STIF1 = 0U;    /* clear INTST1 interrupt flag */
}

void Uart1ReceiveEnable(void)
{
    SRIF1 = 0U;    /* clear INTSR1 interrupt flag */
    SRMK1 = 0U;    /* enable INTSR1 interrupt */
    SO0 |= _0004_SAU_CH2_DATA_OUTPUT_1;    /* output level normal */
    SOE0 |= _0004_SAU_CH2_OUTPUT_ENABLE;    /* enable UART1 output */
    SS0 |= _0008_SAU_CH3_START_TRG_ON | _0004_SAU_CH2_START_TRG_ON;    /* enable UART1 receive and transmit */
}

void Uart1ReceiveDisable(void)
{
    ST0 |= _0008_SAU_CH3_STOP_TRG_ON;    /* disable UART1 receive */
    SRMK1 = 1U;    /* disable INTSR1 interrupt */
    SRIF1 = 0U;    /* clear INTSR1 interrupt flag */
}

void Uart1ReceiveINTDisable(void)
{
    SRMK1 = 1U;    /* disable INTSR1 interrupt */
    SRIF1 = 0U;    /* clear INTSR1 interrupt flag */
}

void Uart2SendEnable(void)
{
    STIF2 = 0U;    /* clear INTST2 interrupt flag */
    STMK2 = 0U;    /* enable INTST2 interrupt */
    SO1 |= _0001_SAU_CH0_DATA_OUTPUT_1;    /* output level normal */
    SOE1 |= _0001_SAU_CH0_OUTPUT_ENABLE;    /* enable UART2 output */
    SS1 |= _0002_SAU_CH1_START_TRG_ON | _0001_SAU_CH0_START_TRG_ON;    /* enable UART2 receive and transmit */
}

void Uart2SendDisable(void)
{
    ST1 |= _0001_SAU_CH0_STOP_TRG_ON;    /* disable UART2 transmit */
    SOE1 &= ~_0001_SAU_CH0_OUTPUT_ENABLE;    /* disable UART2 output */
    STMK2 = 1U;    /* disable INTST2 interrupt */
    STIF2 = 0U;    /* clear INTST2 interrupt flag */
}

void Uart2ReceiveEnable(void)
{
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
    SRMK2 = 0U;    /* enable INTSR2 interrupt */
    SO1 |= _0001_SAU_CH0_DATA_OUTPUT_1;    /* output level normal */
    SOE1 |= _0001_SAU_CH0_OUTPUT_ENABLE;    /* enable UART2 output */
    SS1 |= _0002_SAU_CH1_START_TRG_ON | _0001_SAU_CH0_START_TRG_ON;    /* enable UART2 receive and transmit */
}

void Uart2ReceiveDisable(void)
{
    ST1 |= _0002_SAU_CH1_STOP_TRG_ON;    /* disable UART2 receive */
    SRMK2 = 1U;    /* disable INTSR2 interrupt */
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
}

void Uart2ReceiveINTDisable(void)
{
    SRMK2 = 1U;    /* disable INTSR2 interrupt */
    SRIF2 = 0U;    /* clear INTSR2 interrupt flag */
}

void Uart3SendEnable(void)
{
    STIF3 = 0U;    /* clear INTST3 interrupt flag */
    STMK3 = 0U;    /* enable INTST3 interrupt */
    SO1 |= _0004_SAU_CH2_DATA_OUTPUT_1;    /* output level normal */
    SOE1 |= _0004_SAU_CH2_OUTPUT_ENABLE;    /* enable UART3 output */
    SS1 |= _0008_SAU_CH3_START_TRG_ON | _0004_SAU_CH2_START_TRG_ON;    /* enable UART3 receive and transmit */
}

void Uart3SendDisable(void)
{
    ST1 |= _0004_SAU_CH2_STOP_TRG_ON;    /* disable UART3 transmit */
    SOE1 &= ~_0004_SAU_CH2_OUTPUT_ENABLE;    /* disable UART3 output */
    STMK3 = 1U;    /* disable INTST3 interrupt */
    STIF3 = 0U;    /* clear INTST3 interrupt flag */
}

void Uart3ReceiveEnable(void)
{
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
    SRMK3 = 0U;    /* enable INTSR3 interrupt */
    SO1 |= _0004_SAU_CH2_DATA_OUTPUT_1;    /* output level normal */
    SOE1 |= _0004_SAU_CH2_OUTPUT_ENABLE;    /* enable UART3 output */
    SS1 |= _0008_SAU_CH3_START_TRG_ON | _0004_SAU_CH2_START_TRG_ON;    /* enable UART3 receive and transmit */
}

void Uart3ReceiveDisable(void)
{
    ST1 |= _0008_SAU_CH3_STOP_TRG_ON;    /* disable UART3 receive */
    SRMK3 = 1U;    /* disable INTSR3 interrupt */
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
}

void Uart3ReceiveINTDisable(void)
{
    SRMK3 = 1U;    /* disable INTSR3 interrupt */
    SRIF3 = 0U;    /* clear INTSR3 interrupt flag */
}

int Uart0SendData(unsigned char*pSendBuf,unsigned int Len)
{
    unsigned short i;
    while(Len)
    {
        i = 0x1fff;


        while(SSR00L & 0x20)
        {
            i --;
            if(i == 0)
                return 0;
        }
        TXD0 = *pSendBuf ++;
        Len --;
        MCU_DogReset();
    }
    return 1;
}

int Uart1SendData(unsigned char*pSendBuf,unsigned int Len)
{
    unsigned short i;
    while(Len)
    {
        i = 0x1fff;


        while(SSR02L & 0x20)
        {
            i --;
            if(i == 0)
                return 0;
        }
        TXD1 = *pSendBuf ++;
        Len --;
        MCU_DogReset();
    }
    return 1;
}

int Uart2SendData(unsigned char*pSendBuf,unsigned int Len)
{
    unsigned short i;
    while(Len)
    {
        i = 0x1fff;


        while(SSR10L & 0x20)
        {
            i --;
            if(i == 0)
                return 0;
        }
        TXD2 = *pSendBuf ++;
        Len --;
        MCU_DogReset();
    }
    return 1;
}

int Uart3SendData(unsigned char*pSendBuf,unsigned int Len)
{
    unsigned short i;
    while(Len)
    {
        i = 0x1fff;


        while(SSR12L & 0x20)
        {
            i --;
            if(i == 0)
                return 0;
        }
        TXD3 = *pSendBuf ++;
        Len --;
        MCU_DogReset();
    }
    return 1;
}
/*
*******************************************************
*******************************************************
*******************************************************
*******************************************************完成
说    明:     进入睡眠
*/
void MCU_SleepEnter(void)
{
    NOP();  /* Add one instruction delay */
    STOP(); /* Enter STOP mode */
    NOP();  /* Add one instruction delay */
}
void MCU_IntEn(void)
{
    EI();//IE = 1;//
}

void MCU_IntDis(void)
{
    DI(); //IE = 0;//
}
/*
*******************************************************完成
说    明:     复位函数
*/
void MCU_Reset(void)
{
    WDTE = 0x00;
}
/*
*******************************************************完成
说    明:     看门狗
*/
void MCU_DogCfg(void)               //初始化
{
    //void R_WDT_Create(void)
    {
        WDTIMK = 1U;    /* disable INTWDTI interrupt */
        WDTIIF = 0U;    /* clear INTWDTI interrupt flag */
    }
}
void MCU_DogReset(void)             //喂狗
{
    //void R_WDT_Restart(void)
    {
        WDTE = 0xACU;     /* restart watchdog timer */
    }
}
/*
*******************************************************完成
说    明:     系统速度配置,仅支持8MHz模式
*/
void MCUPllCfg(void)
{
    //void R_CGC_Create(void)
    {
        volatile uint16_t w_count;

        /* Set fMX */
        CMC = _00_CGC_HISYS_PORT | _10_CGC_SUB_OSC | _00_CGC_SUBMODE_LOW;
        MSTOP = 1U;
        /* Set fMAIN */
        MCM0 = 0U;
        /* Set fSUB */
        XTSTOP = 0U;

        /* Change the waiting time according to the system */
        for (w_count = 0U; w_count <= CGC_SUBWAITTIME; w_count++)
        {
            NOP();
        }

        OSMC = _00_CGC_SUBINHALT_ON | _00_CGC_RTC_IT_LCD_CLK_FSUB;
        /* Set fCLK */
        CSS = 0U;
        /* Set fIH */
        HIOSTOP = 0U;
    }
    
//    PIOR = 0x0DU;   //第二功能端口(串口1，TO05，TO07)
    ADPC = 0x01;//P20、P21配置成数字口
    ISCLCD = 0x03;//VL3、CAPL、CAPH配置成数字口
}
/*
*******************************************************完成
说    明:     LCD驱动
MCU,SETG:	0	1	2	3	4	5	6	7	8	9	10	12	13	14	15	16	17	18	19	20	22	COM0	COM1	COM2	COM3
液晶SEG:    0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16	17	18	19	20	COM0	COM1	COM2	COM3
*/
void MCU_LcdCfg(void)   //液晶初始化
{
    LCDON = 0U;    /* disable LCD clock operation */
    LCDMK0 = 1U;    /* disable INTLCD0 interrupt */
    LCDIF0 = 0U;    /* clear INTLCD0 interrupt flag */
    LCDM0 = _00_LCD_DISPLAY_WAVEFORM_A | _0D_LCD_DISPLAY_MODE1;
    LCDM0 |= _00_LCD_VOLTAGE_MODE_EXTERNAL;
    LCDM1 |= _00_LCD_DISPLAY_PATTERN_A;
    LCDC0 = _06_LCD_CLOCK_FSUB_FIL_7;
}
void MCU_LcdOpen(void)  //打开液晶
{
    LCDON = 1U;
    SCOC = 1U;
}
void MCU_LcdClose(void) //关闭液晶
{
    SCOC = 0U;
    LCDON = 0U;
}
void MCU_LcdMemSet(unsigned char Reg)
{
    SEG0 = Reg;
    SEG1 = Reg;
    SEG2 = Reg;
    SEG3 = Reg;
    SEG4 = Reg;
    SEG5 = Reg;
    SEG6 = Reg;
    SEG12 = Reg;
    SEG13 = Reg;
    SEG14 = Reg;
    SEG15 = Reg;
    SEG16 = Reg;
    SEG17 = Reg;
    SEG18 = Reg;
    SEG19 = Reg;
    SEG20 = Reg;
    SEG21 = Reg;
    SEG22 = Reg;
    SEG41 = Reg;
    SEG43 = Reg;
    SEG44 = Reg;
}
void MCU_LcdAllSet(void) //关闭液晶
{
    MCU_LcdMemSet(0x0f);
}
void MCU_LcdAllClr(void) //关闭液晶
{
    MCU_LcdMemSet(0x00);
}

void MCU_LcdWriteReg(unsigned char Seg, unsigned char Reg)
{
    switch (Seg)
    {
    case 0:        SEG0 = Reg;    break;
    case 1:        SEG1 = Reg;    break;
    case 2:        SEG2 = Reg;    break;
    case 3:        SEG3 = Reg;    break;
    case 4:        SEG4 = Reg;    break;
    case 5:        SEG5 = Reg;    break;
    case 6:        SEG6 = Reg;    break;
    case 7:        SEG12 = Reg;   break;
    case 8:        SEG13= Reg;    break;
    case 9:        SEG14= Reg;    break;
    case 10:       SEG15 = Reg;   break;
    case 11:       SEG16 = Reg;   break;
    case 12:       SEG17 = Reg;   break;
    case 13:       SEG18 = Reg;   break;
    case 14:       SEG19 = Reg;   break;
    case 15:       SEG20 = Reg;   break;
    case 16:       SEG21 = Reg;   break;
    case 17:       SEG22 = Reg;   break;
    case 18:       SEG41 = Reg;   break;
    case 19:       SEG43 = Reg;   break;
    case 20:       SEG44 = Reg;   break;
    }
}
unsigned char MCU_LcdReadReg(unsigned char Seg)
{
    switch (Seg)
    {
    case 0:        return SEG0 ;
    case 1:        return SEG1 ;
    case 2:        return SEG2 ;
    case 3:        return SEG3 ;
    case 4:        return SEG4 ;
    case 5:        return SEG5 ;
    case 6:        return SEG6 ;
    case 7:        return SEG12 ;
    case 8:        return SEG13 ;
    case 9:        return SEG14 ;
    case 10:       return SEG15;
    case 11:       return SEG16;
    case 12:       return SEG17;
    case 13:       return SEG18;
    case 14:       return SEG19;
    case 15:       return SEG20;
    case 16:       return SEG21;
    case 17:       return SEG22;
    case 18:       return SEG41;
    case 19:       return SEG43;
    case 20:       return SEG44;
    default:       return SEG44;
    }
}
/*
*******************************************************完成
说    明:     定时器驱动
PortVmNum0:使用IntervalTimer时钟,支持1ms,100ms
PortVmNum8:使用IntervalTimer时钟,支持1ms,10ms,20ms,100ms
PortVmNum9:使用Real-time定时器,支持0.5秒,1秒.
*/

#if MESURETYPE == MESURETYPE_HALL

    extern void HallACountPay_Task(void);
    extern void HallBCountPay_Task(void);
    extern unsigned char GpioHallARead(void);
    extern unsigned char GpioHallBRead(void);
    
#endif
    
#define ServerIntervalNum   1
IRQServerFT IRQServerTM0[ServerIntervalNum] = { IrqServerDefault };
IRQServerFT IRQServerTM1[ServerIntervalNum] = { IrqServerDefault };
IRQServerFT IRQServerIntervalTimer[ServerIntervalNum] = { IrqServerDefault };
IRQServerFT IRQServerRealTime[ServerIntervalNum] = { IrqServerDefault };
#pragma vector = INTTM00_vect
__interrupt static void r_tau0_channel0_interrupt(void)
{
    char i;
    EI();
    for (i = 0; i < ServerIntervalNum; i++)
        IRQServerTM0[i]();
    Random++;
}
/***********************************************************************************************************************
* Function Name: r_tau0_channel1_interrupt
* Description  : This function INTTM01 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#pragma vector = INTTM01_vect
__interrupt static void r_tau0_channel1_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    char i;
    EI();
    for (i = 0; i < ServerIntervalNum; i++)
        IRQServerTM1[i]();
    Random++;
    /* End user code. Do not edit comment generated here */
}
/***********************************************************************************************************************
* Function Name: r_tau0_channel2_interrupt
* Description  : This function INTTM02 interrupt service routine.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#pragma vector = INTTM02_vect
__interrupt static void r_tau0_channel2_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
  	
    /* End user code. Do not edit comment generated here */
}

#pragma vector = INTIT_vect
__interrupt static void r_it_interrupt(void)
{
    char i;
    EI();
    for (i = 0; i < ServerIntervalNum; i++)
        IRQServerIntervalTimer[i]();
    Random++;
}
#pragma vector = INTRTC_vect
__interrupt static void r_rtc_interrupt(void)
{
    char i;
    EI();
    if (1U == WAFG)
    {
        RTCWEN = 1U;
        RTCC1 &= (uint8_t)~_10_RTC_ALARM_MATCH;        /* clear WAFG */
        RTCWEN = 0U;
    }

    if (1U == RIFG)
    {
        RTCWEN = 1U;
        RTCC1 &= (uint8_t)~_08_RTC_INTC_GENERATE_FLAG;    /* clear RIFG */
        RTCWEN = 0U;
    }
    for (i = 0; i < ServerIntervalNum; i++)
        IRQServerRealTime[i]();
    Random++;
}

void MCU_TimerCfg(PortNumET TimeNo, TimeSpET Sp, IRQServerFT TimeServer)
{
    char i;
    switch (TimeNo)
    {
    case PortVmNum0:
        for (i = 0; i < ServerIntervalNum; i++)
        {
            if (IRQServerTM0[i] == IrqServerDefault)
                IRQServerTM0[i] = TimeServer;
        }
        //void R_TAU0_Create(void)
        {
            TAU0EN = 1U;    /* supplies input clock */
            switch (Sp)
            {
            case TimeSpMs1:
                TPS0 = _0000_TAU_CKM0_fCLK_0 | _0000_TAU_CKM1_fCLK_0 | _0000_TAU_CKM2_fCLK_1 | _0000_TAU_CKM3_fCLK_8;
                break;
            case TimeSpMs100:
                TPS0 = _0004_TAU_CKM0_fCLK_4 | _0000_TAU_CKM1_fCLK_0 | _0000_TAU_CKM2_fCLK_1 | _0000_TAU_CKM3_fCLK_8;
                break;
            }
            /* Stop all channels */
            TT0 = _0001_TAU_CH0_STOP_TRG_ON | _0002_TAU_CH1_STOP_TRG_ON | _0004_TAU_CH2_STOP_TRG_ON |
                _0008_TAU_CH3_STOP_TRG_ON | _0010_TAU_CH4_STOP_TRG_ON | _0020_TAU_CH5_STOP_TRG_ON |
                _0040_TAU_CH6_STOP_TRG_ON | _0080_TAU_CH7_STOP_TRG_ON | _0200_TAU_CH1_H8_STOP_TRG_ON |
                _0800_TAU_CH3_H8_STOP_TRG_ON;
            /* Mask channel 0 interrupt */
            TMMK00 = 1U;    /* disable INTTM00 interrupt */
            TMIF00 = 0U;    /* clear INTTM00 interrupt flag */
            /* Mask channel 1 interrupt */
            TMMK01 = 1U;    /* disable INTTM01 interrupt */
            TMIF01 = 0U;    /* clear INTTM01 interrupt flag */
            /* Mask channel 1 higher 8 bits interrupt */
            TMMK01H = 1U;    /* disable INTTM01H interrupt */
            TMIF01H = 0U;    /* clear INTTM01H interrupt flag */
            /* Mask channel 2 interrupt */
            TMMK02 = 1U;    /* disable INTTM02 interrupt */
            TMIF02 = 0U;    /* clear INTTM02 interrupt flag */
            /* Mask channel 3 interrupt */
            TMMK03 = 1U;    /* disable INTTM03 interrupt */
            TMIF03 = 0U;    /* clear INTTM03 interrupt flag */
            /* Mask channel 3 higher 8 bits interrupt */
            TMMK03H = 1U;    /* disable INTTM03H interrupt */
            TMIF03H = 0U;    /* clear INTTM03H interrupt flag */
            /* Mask channel 4 interrupt */
            TMMK04 = 1U;    /* disable INTTM04 interrupt */
            TMIF04 = 0U;    /* clear INTTM04 interrupt flag */
            /* Mask channel 5 interrupt */
            TMMK05 = 1U;    /* disable INTTM05 interrupt */
            TMIF05 = 0U;    /* clear INTTM05 interrupt flag */
            /* Mask channel 6 interrupt */
            TMMK06 = 1U;    /* disable INTTM06 interrupt */
            TMIF06 = 0U;    /* clear INTTM06 interrupt flag */
            /* Mask channel 7 interrupt */
            TMMK07 = 1U;    /* disable INTTM07 interrupt */
            TMIF07 = 0U;    /* clear INTTM07 interrupt flag */
            /* Set INTTM00 low priority */
            TMPR100 = 1U;
            TMPR000 = 1U;
            /* Channel 0 used as interval timer */
            TMR00 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0000_TAU_COMBINATION_SLAVE |
                _0000_TAU_TRIGGER_SOFTWARE | _0000_TAU_MODE_INTERVAL_TIMER | _0000_TAU_START_INT_UNUSED;
            switch (Sp)
            {
            case TimeSpMs1:
                TDR00 = (0x1F3FU);
                break;
            case TimeSpMs100:
                TDR00 = (0xC34FU);
                break;
            }
            TO0 &= ~_0001_TAU_CH0_OUTPUT_VALUE_1;
            TOE0 &= ~_0001_TAU_CH0_OUTPUT_ENABLE;
        }
        break;
    case PortVmNum1:
        for (i = 0; i < ServerIntervalNum; i++)
        {
            if (IRQServerTM1[i] == IrqServerDefault)
                IRQServerTM1[i] = TimeServer;
        }
        /* Set INTTM01 low priority */
        TMPR101 = 1U;
        TMPR001 = 1U;
        
    /* Channel 1 used as interval timer */
        TMR01 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0000_TAU_16BITS_MODE | 
                _0000_TAU_TRIGGER_SOFTWARE | _0000_TAU_MODE_INTERVAL_TIMER | _0001_TAU_START_INT_USED;
        TDR01 = (0x1F3FU);
        TOM0 &= ~_0002_TAU_CH1_OUTPUT_COMBIN;
        TOL0 &= ~_0002_TAU_CH1_OUTPUT_LEVEL_L;
        TO0 &= ~_0002_TAU_CH1_OUTPUT_VALUE_1;
        TOE0 &= ~_0002_TAU_CH1_OUTPUT_ENABLE;
        break;
    case PortVmNum2:
        /* Set INTTM02 low priority */
        TMPR102 = 1U;
        TMPR002 = 1U;
        /* Channel 2 used as interval timer */
        TMR02 = _8000_TAU_CLOCK_SELECT_CKM1 | _0000_TAU_CLOCK_MODE_CKS | _0000_TAU_COMBINATION_SLAVE | 
                _0000_TAU_TRIGGER_SOFTWARE | _0000_TAU_MODE_INTERVAL_TIMER | _0000_TAU_START_INT_UNUSED;
        TDR02 = (0x1F3FU);//_C34F_TAU_TDR02_VALUE;
        TOM0 &= ~_0004_TAU_CH2_OUTPUT_COMBIN;
        TOL0 &= ~_0004_TAU_CH2_OUTPUT_LEVEL_L;
        TO0 &= ~_0004_TAU_CH2_OUTPUT_VALUE_1;
        TOE0 &= ~_0004_TAU_CH2_OUTPUT_ENABLE;
        break;
        
    case PortVmNum8://使用IntervalTimer定时器
        for (i = 0; i < ServerIntervalNum; i++)
        {
            if (IRQServerIntervalTimer[i] == IrqServerDefault)
                IRQServerIntervalTimer[i] = TimeServer;
        }
    //void R_IT_Create(void)
    {
                        TMKAEN = 1U;    /* supply IT clock */
                        ITMC = _0000_IT_OPERATION_DISABLE;    /* disable IT operation */
                        TMKAMK = 1U;    /* disable INTIT interrupt */
                        TMKAIF = 0U;    /* clear INTIT interrupt flag */
                        /* Set INTIT low priority */
                        TMKAPR1 = 1U;
                        TMKAPR0 = 1U;

                        switch (Sp)
                        {
                        case TimeSpMs1:
                            ITMC = _0020_ITMCMP_VALUE;
                            break;
                        case TimeSpMs10:
                            ITMC = _0147_ITMCMP_VALUE;
                            break;
                        case TimeSpMs20:
                            ITMC = _028E_ITMCMP_VALUE;
                            break;
                        case TimeSpMs50:
                            ITMC = (0x0665U);
                            break;
                        case TimeSpMs100:
                            ITMC = (0x0CCCU);
                            break;
                        }
    }
        break;
    case PortVmNum9://使用Real-time定时器
        for (i = 0; i < ServerIntervalNum; i++)
        {
            if (IRQServerRealTime[i] == IrqServerDefault)
                IRQServerRealTime[i] = TimeServer;
        }
        //void R_RTC_Create(void)
        {
            RTCWEN = 1U;   /* enables input clock supply */
            RTCE = 0U;     /* disable RTC clock operation */
            RTCMK = 1U;    /* disable INTRTC interrupt */
            RTCIF = 0U;    /* clear INTRTC interrupt flag */
            RTITMK = 1U;   /* disable INTRTIT interrupt */
            RTITIF = 0U;   /* clear INTRTIT interrupt flag */
            /* Set INTRTC low priority */
            RTCPR1 = 1U;
            RTCPR0 = 1U;
            switch (Sp)
            {
            case TimeSpMs500:
                RTCC0 = _00_RTC_RTC1HZ_DISABLE | _08_RTC_24HOUR_SYSTEM | _01_RTC_INTRTC_CLOCK_0;
                break;
            case TimeSpMs1000:
                RTCC0 = _00_RTC_RTC1HZ_DISABLE | _08_RTC_24HOUR_SYSTEM | _02_RTC_INTRTC_CLOCK_1;
                break;
            case TimeSpMs2000:
                break;
            }
            /* Set real-time clock */
    //                        SEC = _00_RTC_COUNTER_SEC;
    //                        MIN = _00_RTC_COUNTER_MIN;
    //                        HOUR = _00_RTC_COUNTER_HOUR;
    //                        WEEK = _02_RTC_COUNTER_WEEK;
    //                        DAY = _11_RTC_COUNTER_DAY;
    //                        MONTH = _11_RTC_COUNTER_MONTH;
    //                        YEAR = _14_RTC_COUNTER_YEAR;
            /* Set alarm function */
            WALE = 0U;     /* invalidate alarm match operation */
            WALIE = 1U;    /* generate INTRTC on matching of alarm */
            RTCWEN = 0U;    /* stops input clock supply */
        }
        break;
    }
}
void MCU_TimerStart(PortNumET TimeNo)
{
    switch (TimeNo)
    {
    case PortVmNum0:
        //void R_TAU0_Channel0_Start(void)
        {
            TMIF00 = 0U;    /* clear INTTM00 interrupt flag */
            TMMK00 = 0U;    /* enable INTTM00 interrupt */
            TS0 |= _0001_TAU_CH0_START_TRG_ON;
        }
        break;
    case PortVmNum1:
        {
            TMIF01 = 0U;    /* clear INTTM01 interrupt flag */
            TMMK01 = 0U;    /* enable INTTM01 interrupt */
            TS0 |= _0002_TAU_CH1_START_TRG_ON;
        }
      break;
    case PortVmNum2:
        //void R_TAU0_Channel2_Start(void)
        {
            TMIF02 = 0U;    /* clear INTTM02 interrupt flag */
            TMMK02 = 0U;    /* enable INTTM02 interrupt */
            TS0 |= _0004_TAU_CH2_START_TRG_ON;
        }
        break;
    case PortVmNum8:
        //void R_IT_Start(void)
        {
            TMKAIF = 0U;    /* clear INTIT interrupt flag */
            TMKAMK = 0U;    /* enable INTIT interrupt */
            ITMC |= _8000_IT_OPERATION_ENABLE;    /* enable IT operation */
        }
        break;
    case PortVmNum9:
        //void R_RTC_Operation_Start(void)
        {
            unsigned int WaitCnt = 0;
            //void R_RTC_Start(void)
            {
                RTCWEN = 1U;   /* enables input clock supply */
                RTCIF = 0U;    /* clear INTRTC interrupt flag */
                RTCMK = 0U;    /* enable INTRTC interrupt */
                RTCE = 1U;     /* enable RTC clock operation */
                RTCWEN = 0U;   /* stops input clock supply */
            }

            RTCWEN = 1U;    /* enables input clock supply */

            /* ---- Wait after a RTCE bit setup ---- */
            RWAIT = 1;

            while (RWST != 1)
            {
                WaitCnt++;
                if (WaitCnt > 5000)
                {
                    WaitCnt++;
                    break;
                }
                /* Do Nothing */
            }

            RWAIT = 0;
            WaitCnt = 0;
            while (RWST != 0)
            {
                WaitCnt++;
                if (WaitCnt > 5000)
                {
                    WaitCnt++;
                    break;
                }
                /* Do Nothing */
            }

            RTCWEN = 0U;    /* stops input clock supply */
        }
        break;
    }
}
void MCU_TimerStop(PortNumET TimeNo)
{
    switch (TimeNo)
    {
    case PortVmNum0:
        //void R_TAU0_Channel0_Stop(void)
        {
            TT0 |= _0001_TAU_CH0_STOP_TRG_ON;
            /* Mask channel 0 interrupt */
            TMMK00 = 1U;    /* disable INTTM00 interrupt */
            TMIF00 = 0U;    /* clear INTTM00 interrupt flag */
        }
        break;
    case PortVmNum1:
        {
            TT0 |= _0002_TAU_CH1_STOP_TRG_ON;
            /* Mask channel 1 interrupt */
            TMMK01 = 1U;    /* disable INTTM01 interrupt */
            TMIF01 = 0U;    /* clear INTTM01 interrupt flag */
        }
      break;
    case PortVmNum2:
        //void R_TAU0_Channel2_Stop(void)
        {
            TT0 |= _0004_TAU_CH2_STOP_TRG_ON;
            /* Mask channel 2 interrupt */
            TMMK02 = 1U;    /* disable INTTM02 interrupt */
            TMIF02 = 0U;    /* clear INTTM02 interrupt flag */
        }
        break;
    case PortVmNum8:
        //void R_IT_Stop(void)
        {
            TMKAMK = 1U;    /* disable INTIT interrupt */
            TMKAIF = 0U;    /* clear INTIT interrupt flag */
            ITMC &= (uint16_t)~_8000_IT_OPERATION_ENABLE;    /* disable IT operation */
        }
        break;
    case PortVmNum9:
        //void R_RTC_Stop(void)
        {
            RTCWEN = 1U;  /* enables input clock supply */
            RTCE = 0U;    /* disable RTC clock operation */
            RTCMK = 1U;   /* disable INTRTC interrupt */
            RTCIF = 0U;   /* clear INTRTC interrupt flag */
            RTCWEN = 0U;  /* stops input clock supply */
        }
        break;
    }
}

#pragma vector = INTTM04_vect
__interrupt static void r_tau0_channel4_interrupt(void)
{
    // static unsigned char LED_IO = 0;
    EI();
    Random++;
    // 输出频率测试：应输出38KHz(IR_PWM)
    // if(LED_IO)
    // {
    //     LED_IO = 0;
    //     LEDOff(RED_LED);
    // }else{
    //     LED_IO = 1;
    //     LEDOn(RED_LED);
    // }
}

#pragma vector = INTTM05_vect
__interrupt static void r_tau0_channel5_interrupt(void)
{
    // static unsigned char BEEP_IO = 0;
    EI();
    Random++;


    // 输出频率测试：应输出38KHz(IR_PWM)
    // 可在Debug下看到：TDR05为0xFFFF时、TO05输出0；TDR05不为0xFFFF时、TO05输出1
    // if(BEEP_IO)
    // {
    //     BEEP_IO = 0;
    //     LEDOff(BEEP_LED);
    // }else{
    //     BEEP_IO = 1;
    //     LEDOn(BEEP_LED);
    // }
}
//配置PWM(TO05)
void PWM_TimerCfg_TO05(unsigned short Frequency, unsigned char Duty)
{
    if(Frequency == 0)
    {
        return;
    }
    // ===== 主控通道[通道4] =====
    // 周期
    TDR04 = 8000000UL / Frequency;
    if(TDR04 > 0)
    {
        TDR04 -= 1;
    }
    // 中断优先级：最低
    TMPR104 = 1U;
    TMPR004 = 1U;
    TMR04 = (0x00 << 14) | // [15 14]  选择CKm0作为通道时钟源
            (0x00 << 13) | // [13]     固定为0
            (0x00 << 12) | // [12]     计数时钟 = CKSmn0 位和 CKSmn1 位指定的运行时钟(CKm0)
            (0x01 << 11) | // [11]     PWM输出 （主控通道）
            (0x00 <<  8) | // [10 9 8] 仅可通过软件触发
            (0x00 <<  6) | // [7 6]    不使用 TImn 引脚输入
            (0x00 <<  4) | // [5 4]    固定为0
            (0x00 <<  1) | // [3 2 1]  间隔定时器模式运行
            (0x01 <<  0) ; // [0]      计数开始时产生中断
    TOM0 &= ~_0010_TAU_CH4_OUTPUT_COMBIN;  // 主控通道输出模式（通过定时器中断请求信号（INTTMmn）进行交替输出）
    TOE0 &= ~_0010_TAU_CH4_OUTPUT_ENABLE;  // 定时器的运行不反映到 TOmn 位

    // ===== 从属通道[通道5] =====
    // 占空比[递减计数、满值FFFFH]
    if(Duty >= 100)
    {
        TDR05 = (TDR04 == 0xFFFF) ? 0xFFFF : (TDR04 + 1);
    }else{
        TDR05 = TDR04 * Duty / 100U;
    }
    // 中断优先级：最低
    TMPR105 = 1U;
    TMPR005 = 1U;
    /* Channel 5 used as PWM timer */
    TMR05 = (0x00 << 14) | // [15 14]  选择CKm0作为通道时钟源
            (0x00 << 13) | // [13]     固定为0
            (0x00 << 12) | // [12]     计数时钟 = CKSmn0 位和 CKSmn1 位指定的运行时钟(CKm0)
            (0x00 << 11) | // [11]     PWM输出 （从属通道）
            (0x04 <<  8) | // [10 9 8] 使用主控通道的中断信号用作触发
            (0x00 <<  6) | // [7 6]    不使用 TImn 引脚输入
            (0x00 <<  4) | // [5 4]    固定为0
            (0x04 <<  1) | // [3 2 1]  单次计数模式
            (0x01 <<  0) ; // [0]      计数运行中的开始触发有效
    TOM0 |=  _0020_TAU_CH5_OUTPUT_COMBIN;   // 从属通道输出模式（通过主控通道的定时器中断请求信号（ INTTMmn）将输出置位，并且通过从属通道的定时器中断请求信号 （ INTTMmp）对输出进行复位）
    TOL0 &=  _0020_TAU_CH5_OUTPUT_LEVEL_L;  // 正逻辑(高电平有效)[不反相]
    TO0  &= ~_0020_TAU_CH5_OUTPUT_VALUE_1;  // TOE05 = 0 状态下可以设置TO05引脚的电平
    TOE0 |=  _0020_TAU_CH5_OUTPUT_ENABLE;   // 定时器的运行反映到 TOmn 位，产生输出波形
    PIOR &= ~(0x01 << 0);  // TO05映射到P42
}
void PWM_TimerStart_TO05(void)
{
    TMMK05 = 0U;    /* disable INTTM05 interrupt */
    TMIF05 = 0U;    /* clear INTTM05 interrupt flag */ 
    TMMK04 = 0U;    /* disable INTTM05 interrupt */
    TMIF04 = 0U;    /* clear INTTM05 interrupt flag */
    TS0   |= _0010_TAU_CH4_START_TRG_ON | // 允许运行（主控通道）
             _0020_TAU_CH5_START_TRG_ON;  // 允许运行（从属通道）
}
void PWM_TimerStop_TO05(void)
{
    TT0   |= _0010_TAU_CH4_STOP_TRG_ON |  // 停止运行（主控通道）
             _0020_TAU_CH5_STOP_TRG_ON;   // 停止运行（从属通道）
    TOE0  &= ~_0020_TAU_CH5_OUTPUT_ENABLE;// 禁止后才可以设置TOmp引脚的电平值
    TO0  &= ~_0020_TAU_CH5_OUTPUT_VALUE_1;
    TMMK05 = 1U;    /* disable INTTM05 interrupt */
    TMIF05 = 0U;    /* clear INTTM05 interrupt flag */ 
    TMMK04 = 1U;    /* disable INTTM05 interrupt */
    TMIF04 = 0U;    /* clear INTTM05 interrupt flag */
}

/*
*******************************************************完成
说    明:     AD采样
如果采用8bit精度,使用内部基准
如果采用10bit精度,使用VDD基准
*/
unsigned short AdcRefVolt = 1450;//3300;//ADC采集基准,单位mV
unsigned char ADCStaIsBusy = FALSE;
unsigned int ADCResult; //保存最近一次ADC结果
void MCU_ADCCfg(PortNumET ADCNum, ADCModeST Mode)   //
{
    //void R_ADC_Create(void)
    {
        ADCEN = 1U;  /* supply AD clock */
        ADM0 = _00_AD_ADM0_INITIALVALUE;  /* disable AD conversion and clear ADM0 register */
        ADMK = 1U;  /* disable INTAD interrupt */
        ADIF = 0U;  /* clear INTAD interrupt flag */
        /* Set INTAD low priority */
        ADPR1 = 1U;
        ADPR0 = 1U;
//        switch (ADCNum)
//        {
//        case PortVmNum0:
//        {
//                           /* Set ANI0 pin */
//                           PM2 |= 0x02U;
//        }
//            break;
//        case PortVmNum1:
//        {
//                           /* Set ANI0 - ANI1 pin */
//                           PM2 |= 0x03U;
//        }
//            break;
//        case PortVmNum16:
//        {
//                            /* Set ANI16 pin */
//                            PFSEG3 |= 0x40U;
//                            PMC2 |= 0x04U;
//                            PM2 |= 0x04U;
//        }
//            break;
//        case PortVmNum17:
//        {
//                            /* Set ANI17 pin */
//                            PFSEG3 |= 0x80U;
//                            PMC2 |= 0x08U;
//                            PM2 |= 0x08U;
//        }
//            break;
//        }
//        if (Mode.ADCModeOpt == 0)
//        {   //单次模式
            ADM1 = _00_AD_TRIGGER_SOFTWARE | _20_AD_CONVMODE_ONESELECT;
//        }
//        else
//        {
//            //多次模式
//            ADM1 = _00_AD_TRIGGER_SOFTWARE | _00_AD_CONVMODE_CONSELECT;
//        }
        if (Mode.ADCModeResolution == 0)
        {   //8bit,内部基准
            ADM0 = _38_AD_CONVERSION_CLOCK_2 | _06_AD_TIME_MODE_LOWVOLTAGE_2;
            ADM2 = _80_AD_POSITIVE_INTERVOLT | _00_AD_NEGATIVE_VSS | _00_AD_AREA_MODE_1 | _01_AD_RESOLUTION_8BIT;
        }
        else
        {//10bit,VDD基准
            ADM0 = _38_AD_CONVERSION_CLOCK_2 | _06_AD_TIME_MODE_LOWVOLTAGE_2;
            ADM2 = _00_AD_POSITIVE_VDD | _00_AD_NEGATIVE_VSS | _00_AD_AREA_MODE_1 | _00_AD_RESOLUTION_10BIT;
        }
        ADUL = _FF_AD_ADUL_VALUE;
        ADLL = _00_AD_ADLL_VALUE;
        switch (ADCNum)
        {
        case PortVmNum0:
            //ANI0
            ADS = _00_AD_INPUT_CHANNEL_0; break;
        case PortVmNum1:
            //ANI1
            ADS = _01_AD_INPUT_CHANNEL_1; break;
        case PortVmNum16:
            //ANI16
            ADS = _10_AD_INPUT_CHANNEL_16; break;
        case PortVmNum17:
            //ANI17
            ADS = _11_AD_INPUT_CHANNEL_17; break;
        }
    }
}
void MCU_ADCStart(PortNumET ADCNum)
{
    ADCStaIsBusy = TRUE;
        ADCE = 1U;  /* enable AD comparator */
        ADIF = 0U;  /* clear INTAD interrupt flag */
        ADMK = 0U;  /* enable INTAD interrupt */
        __no_operation();__no_operation();__no_operation();
        __no_operation();__no_operation();__no_operation();
}
void MCU_ADCStop(PortNumET ADCNum)
{
    ADCStaIsBusy = FALSE;
    
    ADCS = 0U;  /* disable AD conversion */
    ADMK = 1U;  /* disable INTAD interrupt */
    ADIF = 0U;  /* clear INTAD interrupt flag */
    ADCE = 0U;  /* disable AD comparator */
}
unsigned short OverCnt = 0;
unsigned int MCU_ADCRead(void)
{
    //unsigned short OverCnt = 0;
    while (ADCStaIsBusy == TRUE)
    {
        OverCnt++;
        if (OverCnt >= 15000)
        {
            OverCnt = 0;
            return 0;
        }
    }
    OverCnt = 0;
    return ADCResult;
}
#pragma vector = INTAD_vect
__interrupt static void r_adc_interrupt(void)
{
    EI();
    /* Start user code. Do not edit comment generated here */
    if((ADM2 & _01_AD_RESOLUTION_8BIT) == _01_AD_RESOLUTION_8BIT)  //8位AD
    {
        ADCResult = (unsigned int)ADCRH;
    }
    else    
    {
        ADCResult = (unsigned int)ADCR >> 6;
    }
    /* End user code. Do not edit comment generated here */
    ADCStaIsBusy = FALSE;
    Random += ADCResult;
}
/*
*******************************************************完成
说    明:     实时时钟
*/
MD_STATUS R_RTC_Get_CounterValuemy(rtc_counter_value_t * const counter_read_val)
{
    MD_STATUS status = MD_OK;
    volatile uint32_t  w_count;
    
    RTCWEN = 1U;    /* enables input clock supply */
    RTCC1 |= _01_RTC_COUNTER_PAUSE;

    /* Change the waiting time according to the system */
    for (w_count = 0U; w_count < RTC_WAITTIME; w_count++)
    {
        NOP();
        NOP();
        NOP();
    }

    if (0U == RWST)
    {
        status = MD_BUSY1;
    }
    else
    {
        counter_read_val->sec = SEC;
        counter_read_val->min = MIN;
        counter_read_val->hour = HOUR;
        counter_read_val->week = WEEK;
        counter_read_val->day = DAY;
        counter_read_val->month = MONTH;
        counter_read_val->year = YEAR;
    }                   //change by LYT@20180521, REF from wangbing, for RTC stop quetion
        RTCC1 &= (uint8_t)~_01_RTC_COUNTER_PAUSE;

        /* Change the waiting time according to the system */
        for (w_count = 0U; w_count < RTC_WAITTIME; w_count++)
        {
            NOP();
        }

        if (1U == RWST)
        {
            status = MD_BUSY2;
        }
    //}                 //change by LYT@20180521, REF from wangbing, for RTC stop quetion

    RTCWEN = 0U;    /* stops input clock supply */

    return (status);
}

int RTCCfg(void)                //返回TRUE/FALSE
{
    //void R_RTC_Create(void)
    {
        RTCWEN = 1U;   /* enables input clock supply */
        RTCE = 0U;     /* disable RTC clock operation */
        RTCMK = 1U;    /* disable INTRTC interrupt */
        RTCIF = 0U;    /* clear INTRTC interrupt flag */
        RTITMK = 1U;   /* disable INTRTIT interrupt */
        RTITIF = 0U;   /* clear INTRTIT interrupt flag */
        /* Set INTRTC low priority */
        RTCPR1 = 1U;
        RTCPR0 = 1U;
        //switch (Sp)
        //{
        //case TimeSpMs500:
        //    RTCC0 = _00_RTC_RTC1HZ_DISABLE | _08_RTC_24HOUR_SYSTEM | _01_RTC_INTRTC_CLOCK_0;
        //    break;
        //case TimeSpMs1000:
            RTCC0 = _00_RTC_RTC1HZ_DISABLE | _08_RTC_24HOUR_SYSTEM | _02_RTC_INTRTC_CLOCK_1;
        //    break;
        //case TimeSpMs2000:
        //}
        /* Set real-time clock */
        //SEC = _00_RTC_COUNTER_SEC;
        //MIN = _00_RTC_COUNTER_MIN;
        //HOUR = _00_RTC_COUNTER_HOUR;
        //WEEK = _02_RTC_COUNTER_WEEK;
        //DAY = _11_RTC_COUNTER_DAY;
        //MONTH = _11_RTC_COUNTER_MONTH;
        //YEAR = _14_RTC_COUNTER_YEAR;
        /* Set alarm function */
        WALE = 0U;     /* invalidate alarm match operation */
        WALIE = 1U;    /* generate INTRTC on matching of alarm */
        RTCWEN = 0U;    /* stops input clock supply */
    }
    MCU_TimerStart(PortVmNum9);
    return 0;
}
MD_STATUS R_RTC_Set_CounterValuemy(rtc_counter_value_t counter_write_val)
{
    MD_STATUS status = MD_OK;
    volatile uint32_t  w_count;
    
    RTCWEN = 1U;    /* enables input clock supply */
    RTCC1 |= _01_RTC_COUNTER_PAUSE;

    /* Change the waiting time according to the system */
    for (w_count = 0U; w_count < RTC_WAITTIME; w_count++)
    {
        NOP();
        NOP();
        NOP();
    }

    if (0U == RWST)
    {
        status = MD_BUSY1;
    }
    else
    {
        SEC = counter_write_val.sec;
        MIN = counter_write_val.min;
        HOUR = counter_write_val.hour;
        WEEK = counter_write_val.week;
        DAY = counter_write_val.day;
        MONTH = counter_write_val.month;
        YEAR = counter_write_val.year;
     }                   //change by LYT@20180521, REF from wangbing, for RTC stop quetion    
        RTCC1 &= (uint8_t)~_01_RTC_COUNTER_PAUSE;
   
        /* Change the waiting time according to the system */
        for (w_count = 0U; w_count < RTC_WAITTIME; w_count++)
        {
            NOP();
        }

        if (1U == RWST)
        {
            status = MD_BUSY2;
        }
    //}                 //change by LYT@20180521, REF from wangbing

    RTCWEN = 0U;    /* stops input clock supply */

    return (status);
}

int RTCReadTime(RTC_T* Rtc)     //返回TRUE/FALSE
{
    rtc_counter_value_t InterRtc;
    if (R_RTC_Get_CounterValuemy(&InterRtc) == MD_OK)//需要多尝试
    {
        Rtc->Year = InterRtc.year;
        Rtc->Mon = InterRtc.month;
        Rtc->Day = InterRtc.day;
        Rtc->Week = InterRtc.week;
        Rtc->Hour = InterRtc.hour;// & 0x3f;
        Rtc->Min = InterRtc.min;
        Rtc->Sec = InterRtc.sec;
        return TRUE;
    }
    return FALSE;
}
int RTCWriteTime(RTC_T* Rtc)    //返回TRUE/FALSE
{
    rtc_counter_value_t InterRtc;
    InterRtc.year = Rtc->Year;
    InterRtc.month = Rtc->Mon;
    InterRtc.day = Rtc->Day;
    InterRtc.week = Rtc->Week;
    InterRtc.hour = Rtc->Hour;
    InterRtc.min = Rtc->Min;
    InterRtc.sec = Rtc->Sec;
    if (R_RTC_Set_CounterValuemy(InterRtc) == MD_OK)
        return TRUE;
    return FALSE;
}

void DelayUs(unsigned int Us)
{
    while (Us--)
    {
        NOP();  //4M:for( char i = 0; i < 2; i++ );
        //8M:NOP();
    }
}

void DelayMs(unsigned int Ms)
{
    int i;
    while (Ms)
    {
        for (i = 0; i < 940; i++)  //4M:400.8M:800
            ;
        Ms--;
    }
}
void CBB_NOP(void)
{
    NOP();
}
unsigned short GetRandom(void)
{
    return Random;
}


void R_TAU0_Channe4_Init(void)
{
    //CPU卡CLK初始化
	/* Channel 4 is used as master channel for PWM output function */
    TMR04 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0800_TAU_COMBINATION_MASTER | 
            _0000_TAU_TRIGGER_SOFTWARE | _0001_TAU_MODE_PWM_MASTER;
    TDR04 = _0001_TAU_TDR04_VALUE;
    TOM0 &= ~_0010_TAU_CH4_OUTPUT_COMBIN;
    TOL0 &= ~_0010_TAU_CH4_OUTPUT_LEVEL_L;
    TO0 &= ~_0010_TAU_CH4_OUTPUT_VALUE_1;
    TOE0 &= ~_0010_TAU_CH4_OUTPUT_ENABLE;
    /* Channel 5 is used as slave channel for PWM output function */
    TMR05 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0000_TAU_COMBINATION_SLAVE | 
            _0400_TAU_TRIGGER_MASTER_INT | _0009_TAU_MODE_PWM_SLAVE;
    TDR05 = _0001_TAU_TDR05_VALUE;
    TOM0 |= _0020_TAU_CH5_OUTPUT_COMBIN;
    TOL0 &= ~_0020_TAU_CH5_OUTPUT_LEVEL_L;
    TO0 &= ~_0020_TAU_CH5_OUTPUT_VALUE_1;
    TOE0 |= _0020_TAU_CH5_OUTPUT_ENABLE;
    	
	/* Set TO05 pin */
    PFSEG5 &= 0xDFU;
    P0 &= 0xFDU;
    PM0 &= 0xFDU;
}
void R_TAU0_Channe6_Init(void)
{
	/* Channel 6 is used as master channel for PWM output function */
    TMR06 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0800_TAU_COMBINATION_MASTER | 
            _0000_TAU_TRIGGER_SOFTWARE | _0001_TAU_MODE_PWM_MASTER;
    TDR06 = _0001_TAU_TDR06_VALUE;
    TOM0 &= ~_0040_TAU_CH6_OUTPUT_COMBIN;
    TOL0 &= ~_0040_TAU_CH6_OUTPUT_LEVEL_L;
    TO0 &= ~_0040_TAU_CH6_OUTPUT_VALUE_1;
    TOE0 &= ~_0040_TAU_CH6_OUTPUT_ENABLE;
    /* Channel 7 is used as slave channel for PWM output function */
    TMR07 = _0000_TAU_CLOCK_SELECT_CKM0 | _0000_TAU_CLOCK_MODE_CKS | _0000_TAU_COMBINATION_SLAVE | 
            _0400_TAU_TRIGGER_MASTER_INT | _0009_TAU_MODE_PWM_SLAVE;
    TDR07 = _0001_TAU_TDR07_VALUE;
    TOM0 |= _0080_TAU_CH7_OUTPUT_COMBIN;
    TOL0 &= ~_0080_TAU_CH7_OUTPUT_LEVEL_L;
    TO0 &= ~_0080_TAU_CH7_OUTPUT_VALUE_1;
    TOE0 |= _0080_TAU_CH7_OUTPUT_ENABLE;
	
	/* Set TO07 pin */
    P4 &= 0xFDU;
    PM4 &= 0xFDU;
}


void  R_TAU0_Channe6_Start(void)
{
    TOE0 |= _0080_TAU_CH7_OUTPUT_ENABLE;
    TS0 |= _0040_TAU_CH6_START_TRG_ON | _0080_TAU_CH7_START_TRG_ON;
}

void R_TAU0_Channe6_Stop(void)
{
    TT0 |= _0040_TAU_CH6_STOP_TRG_ON | _0080_TAU_CH7_STOP_TRG_ON;
    TOE0 &= ~_0080_TAU_CH7_OUTPUT_ENABLE;
    TO0 &= ~_0080_TAU_CH7_OUTPUT_VALUE_1;
    TO0 &= ~_0040_TAU_CH6_OUTPUT_VALUE_1;
}

void R_TAU0_Channe4_Start(void)
{	
    TOE0 |= _0020_TAU_CH5_OUTPUT_ENABLE;
    TS0 |= _0010_TAU_CH4_START_TRG_ON | _0020_TAU_CH5_START_TRG_ON;
}

void R_TAU0_Channe4_Stop(void)
{
    TT0 |= _0010_TAU_CH4_STOP_TRG_ON | _0020_TAU_CH5_STOP_TRG_ON;
    TOE0 &= ~_0020_TAU_CH5_OUTPUT_ENABLE;
    TOL0 &= ~_0010_TAU_CH4_OUTPUT_LEVEL_L;
    TO0 &= ~_0020_TAU_CH5_OUTPUT_VALUE_1;
}
