
#include "bsp_rs004.h"
#include "UartUser.h"
#include "drv_board.h"
#include "drv_uart.h"
#include "KeyUser.h"
#include "Led.h"
#include "Time.h"
#include "main.h"
#include "stdarg.h"
#include "stdlib.h"
#include "stdio.h"
#include "task_manage.h"
#include "TaskTimer.h"
#include "timer_manage.h"
#include "user_manage.h"

extern unsigned char COMOpened;

/**
 * �͹�������
 */
void Init_LowConsumeCfg(void)
{
    MCUAllIOSetLow();
    MCULowConsumeConfig();
}

/**
 * MCUӲ����ʼ��
 */
void Init_Periphera(void)
{
    InitKey();                  //����
    InitLedModule();            //LED
    COMOpened = 1;
    switch(COMOpened)
    {
        case 0:  InitNIRUart(UartBaud9600); break;  
        case 1:  InitNIRUart(UartBaud2400); break;  
        case 2:  InitFIRUart(); break;
        case 3:  InitFIRUartEven(); break; 
        default: break;
    }
    InitDebugUart();            //���Դ���
    InitTime();               //ǰ���붨ʱ����ʼ��
}

/**
 * MCU��ʼ��
 */
void MCU_Init(void)
{
    Init_LowConsumeCfg();
    Init_Periphera();
}

/**
 * ��������ڣ�main
 * @return
 */
int main(void)
{      
    MCUPllCfg();
    MCU_IntEn();
    User_Init();
    InitTaskTimer();                        //�����������ʱ�����  
    
    MCU_Init();
    

    while (1U)
    {
        User_TimerManage();
        User_TaskManage();
        if(!IsUARTRun())
            LowPowerConsManage();
        MCU_DogReset();
    }
}
