#include "user_manage.h"
#include "task_manage.h"
#include "timer_manage.h"
#include "config.h"

unsigned char test1ms, test1s;

void User_Init(void)
{
   User_InitTimerManage();
   User_InitTaskManage();
   User_TimerCfg(MAINTIMER, TIME_1_MS,   MAINTIMERADDONCE);             //����ʱ�� 1ms  
   User_TimerCfg(SUBTIMER,  TIME_1_S, SUBTIMERADDONCE);
   User_TimerStart(MAINTIMER);
   User_TimerStart(SUBTIMER);
}

//ʹ��User_Add_Task��������      
//ʹ��User_StartTime��������   
void LowPowerConsManage(void)
{
    MCU_SleepEnter();  
}



